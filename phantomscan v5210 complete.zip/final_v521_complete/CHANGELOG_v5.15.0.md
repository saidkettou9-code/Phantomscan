# PhantomScan v5.15.0 — Changelog

## Nouveaux modules Bug Bounty (v5.15)

### HostHeaderInjectionScanner
Spécialisé sur l'injection du header Host — distinct du scanner générique `headers.py`.

**Vecteurs couverts :**
- **Password Reset Poisoning** : injection de `Host` / `X-Forwarded-Host` / `X-Original-Host`
  sur les endpoints `/forgot-password`, `/password/reset`, etc. Détecte la réflexion
  du domaine attaquant dans la réponse → finding HIGH (souvent P2 en BB).
- **Host Header Reflection** : réflexion générale dans body/headers, avec détection
  d'open redirect via Location.
- **Localhost Bypass** : teste `Host: localhost`, `Host: 127.0.0.1`, `Host: admin.internal`
  et détecte les réponses significativement différentes (vhost interne exposé).
- **Port Reflection** : port arbitraire réfléchi dans les liens → cache poisoning potentiel.
- **Absolute-URI Smuggling** : requête avec URI absolue vers domaine attaquant.

**Flags CLI :**
```
--no-host-header    Désactiver Host Header Injection scanner
```

**Tokens --only-vulns :** `host_header`, `host_header_injection`, `reset_poison`, `hostheader`

---

### DependencyConfusionScanner
Détecte les artefacts exposés permettant d'identifier des packages internes
susceptibles d'être squattés sur des registries publics (npm, PyPI, Maven, Go…).
**Une des vulnérabilités les mieux payées en BB ($5k–$30k+).**

**Fichiers sondés (30+) :**
- npm : `package.json`, `package-lock.json`, `yarn.lock`, `pnpm-lock.yaml`, `.npmrc`, `.yarnrc`
- Python : `requirements.txt`, `Pipfile`, `pyproject.toml`, `setup.py`, `pip.conf`
- Java/Kotlin : `pom.xml`, `build.gradle`, `settings.gradle`
- Go : `go.mod`, `go.sum`
- Ruby : `Gemfile`, `Gemfile.lock`
- Rust : `Cargo.toml`
- PHP : `composer.json`, `composer.lock`
- .NET : `nuget.config`

**Détections :**
- Scopes npm privés (`@company/*`)
- URLs de registries privés (Artifactory, Nexus, Verdaccio, JFrog…)
- Directives Go `replace` pointant vers des modules internes
- Noms de packages avec préfixes internes (`internal-`, `core-`, `lib-`…)

**Flags CLI :**
```
--no-dep-confusion   Désactiver Dependency Confusion scanner
```

**Tokens --only-vulns :** `dep_confusion`, `dependency_confusion`, `depcnf`, `supply_chain`

---

### MassAssignmentScanner
Test complet des endpoints API REST/JSON pour les vulnérabilités de Mass Assignment
(OWASP API6:2023). Envoie des payloads PUT/PATCH avec des champs sensibles et
analyse la réponse pour détecter l'absence de validation.

**Catégories de champs testés :**
- **Privilege** (CRITICAL/HIGH) : `is_admin`, `role`, `permissions`, `plan`, `tier`, `scope`…
- **Financier** (HIGH/MEDIUM) : `balance`, `credits`, `price`, `discount`, `amount`…
- **Vérification** (HIGH/MEDIUM) : `email_verified`, `kyc_status`, `mfa_enabled`…
- **Metadata** (LOW) : `id`, `user_id`, `created_at`, `deleted_at`…
- **Nested injection** : `{"user": {"role": "admin"}}`, JSON:API `data.attributes`…

**Endpoints testés (20+) :**
`/api/v1/user`, `/api/v1/profile`, `/api/me`, `/me`, `/profile`, `/v1/user`…

**Flags CLI :**
```
--no-mass-assignment   Désactiver Mass Assignment scanner
```

**Tokens --only-vulns :** `mass_assign`, `mass_assignment`, `massassign`, `over_posting`

---

## Mise à jour globale

- `config.py` : 3 nouveaux attributs `ScanConfig` (défaut ON), RPS overrides ajoutés
- `engine.py` : 3 entrées dans `module_map` avec lazy-import
- `cli/main.py` : 3 flags `--no-*`, `_VULN_MAP` et `_ALL_VULN_ATTRS` mis à jour,
  preset `bb` et `full` mis à jour, `list_modules()` mis à jour
- `VERSION` → 5.15.0
