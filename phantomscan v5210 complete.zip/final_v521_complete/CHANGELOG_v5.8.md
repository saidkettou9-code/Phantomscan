# PhantomScan — CHANGELOG v5.8.0

## Résumé des changements

---

### 1. CLI — Refonte complète

**Fichier modifié :** `cli/main.py` (réécrit)

#### Presets de scan
`--preset fast|full|stealth|api|recon`

Profils prédéfinis qui configurent automatiquement les modules, rate, concurrence, et profondeur :
- **fast** : scan rapide ~5-10 min, modules véloces uniquement, no-fuzz
- **full** : tous les modules, profondeur 5, bruteforce DNS
- **stealth** : rate 1 req/s, concurrence 3, profil discret, no-fuzz
- **api** : orienté REST/GraphQL/JSON/OpenAPI, sans crawler ni subdomains
- **recon** : recon pur, zéro attaque

#### Rate presets
`--rate-preset low|medium|high|aggressive`

Ajuste concurrent, rate et module_timeout en une seule option.

#### Flags manquants v5.4-5.7 (désormais exposés)
Tous les modules existants n'étaient pas contrôlables depuis le CLI :
- `--no-http-smuggling` : désactive HTTPSmugglingScanner
- `--no-deserialization` : désactive DeserializationScanner
- `--no-s3` : désactive S3EnumScanner
- `--no-cors` : désactive CORSScanner
- `--no-forbidden-bypass` : désactive ForbiddenBypassScanner
- `--no-rate-limit` : désactive RateLimitScanner
- `--no-dom-xss` : désactive DOMXSSAnalyzer
- `--no-json-api` : désactive JSONAPIScanner

#### Flags v5.8 (nouveaux modules)
- `--no-nosql` : désactive NoSQLInjectionScanner
- `--no-openapi` : désactive OpenAPIReconScanner
- `--no-takeover` : désactive SubdomainTakeoverScanner
- `--no-otp` : désactive OTPBypassScanner

#### --only-vulns étendu
Désormais reconnaît tous les nouveaux tokens :
`nosql`, `nosql_injection`, `openapi`, `swagger`, `open_api_recon`,
`takeover`, `subdomain_takeover`, `otp`, `2fa`, `mfa`, `otp_bypass`,
`smuggling`, `http_smuggling`, `deser`, `deserialization`, `s3`, `s3_enum`,
`cors`, `forbidden`, `forbidden_bypass`, `domxss`, `dom_xss`,
`jsonapi`, `json_api`, `rate_limit`, `ratelimit`

#### Scope CLI
`--scope example.com,api.example.com`

Filtre les findings et requêtes aux domaines spécifiés. Précédemment uniquement
configurable dans le code Python via `ScanConfig.scope_domains`.

#### --module-concurrency
`--module-concurrency N`

Nombre de modules vulns exécutés en parallèle (précédemment hardcodé à 4).

#### Formats de rapport multiples
`--format json|html|markdown|all`

- **json** : export JSON existant (inchangé)
- **html** : rapport HTML autonome dark-mode avec filtres par sévérité, cartes cliquables
- **markdown** : rapport Markdown compatible GitHub/Obsidian avec tables et badges emoji
- **all** : génère les 3 formats simultanément

#### --output-dir
`--output-dir ./results/`

Génère automatiquement un nom de fichier horodaté :
`phantomscan_example.com_20240425_143022.json`

Crée le dossier si inexistant.

#### --dry-run
Affiche les modules qui seraient lancés (recon, vulns, fuzz) avec leur statut
activé/désactivé, sans exécuter le scan.

#### --list-modules
Liste tous les modules disponibles par catégorie avec les versions d'introduction.

#### --save-profile / --load-profile
Sauvegarde et charge la configuration CLI en JSON pour réutilisation :
```bash
phantomscan https://target.com --preset api --scope target.com --save-profile api_target.json
phantomscan https://target2.com --load-profile api_target.json
```

#### Verbosité granulaire
`-v` (verbose), `-vv` (très verbeux avec tracebacks), `-vvv` (debug).
Précédemment `-v` était un booléen.

#### --user-agent
User-Agent fixe (désactive la rotation automatique).

#### --crawl-depth
`--crawl-depth N` : nombre max de pages à crawler (précédemment hardcodé à 200).

---

### 2. Reporter — Exports HTML et Markdown

**Fichier modifié :** `output/reporter.py`

#### write_html()
Rapport HTML autonome dark-mode :
- Stats par sévérité avec badges colorés
- Fingerprint table
- Cards de findings triés CRITICAL → INFO, avec filtres par sévérité
- Cards cliquables (expand/collapse le détail)
- Erreurs de scan en bas de page
- Aucune dépendance externe (CSS + JS inline)

#### write_markdown()
Rapport Markdown structuré :
- Table résumé avec emojis couleur (🔴🟠🟡🔵⚪)
- Fingerprint table
- Sections finding avec badges, URL, description, evidence en bloc code
- Compatible GitHub, GitLab, Obsidian, Notion

---

### 3. Config — PhantomConfig étendu

**Fichier modifié :** `config.py`

Nouveaux champs :
- `report_format: str = "json"` — format(s) de rapport
- `output_dir: str | None = None` — dossier de sortie horodaté
- `verbosity: int = 0` — niveau de verbosité 0-3
- `user_agent: str | None = None` — User-Agent fixe

---

## Fichiers modifiés

| Fichier | Action | Description |
|---------|--------|-------------|
| `cli/main.py` | **réécrit** | CLI complet avec presets, formats, scope, dry-run, profiles |
| `output/reporter.py` | **étendu** | Ajout `write_html()` et `write_markdown()` |
| `config.py` | **étendu** | `PhantomConfig` + 4 champs, `VERSION` → 5.8.0 |


---

## v5.9 — Nouveaux modules

### CSRFScanner (`modules/vulns/csrf.py`)
- Détection SameSite absent/None-sans-Secure sur cookies de session
- Scan des forms POST pour l'absence de token CSRF (50+ noms de tokens reconnus)
- Probe POST direct sans token → vérifie si le serveur accepte sans protection
- Détection d'actions sensibles via GET (delete, confirm, approve...)
- Validation Origin/Referer : compare réponse avec origin légitime vs evil
- Flags : `--no-csrf`

### ClickjackingScanner (`modules/vulns/clickjacking.py`)
- Vérifie X-Frame-Options et CSP frame-ancestors sur 20+ paths sensibles
- Détecte : absent, ALLOWALL, ALLOW-FROM obsolète, frame-ancestors wildcard
- Détecte CSP présent mais sans frame-ancestors (oubli fréquent)
- Double-frame bypass possible via SAMEORIGIN sans CSP
- Sévérité adaptée selon la sensibilité de la page (form POST, actions critiques)
- Flags : `--no-clickjacking`

### RaceConditionScanner (`modules/vulns/race_condition.py`)
- 20 requêtes simultanées (last-byte sync via asyncio.gather)
- 22 endpoints cibles : financial, coupon, vote, register, confirm, privilege, points
- Détecte : multi-success 2xx (double-spend, coupon reuse), TOCTOU (mix 2xx+409)
- Détecte : duplicate account creation, multiple financial transactions
- Evidence détaillée : timing par requête, distribution des statuts
- Flags : `--no-race`
