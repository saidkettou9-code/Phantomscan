"""
PhantomScan — Reporter
Output terminal coloré + export JSON.
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from phantomscan.core.engine import ScanResult
    from phantomscan.core.fingerprint import Fingerprint
    from phantomscan.config import PhantomConfig

from phantomscan.config import VERSION


# ─────────────────────────── ANSI Colors ────────────────────────────────────

class C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    RED     = "\033[91m"
    ORANGE  = "\033[38;5;208m"
    YELLOW  = "\033[93m"
    GREEN   = "\033[92m"
    CYAN    = "\033[96m"
    BLUE    = "\033[94m"
    MAGENTA = "\033[95m"
    WHITE   = "\033[97m"
    GREY    = "\033[90m"

    @staticmethod
    def strip(text: str) -> str:
        import re
        return re.sub(r'\033\[[0-9;]*m', '', text)


def _supports_color() -> bool:
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


# ─────────────────────────── Finding ────────────────────────────────────────

class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH     = "HIGH"
    MEDIUM   = "MEDIUM"
    LOW      = "LOW"
    INFO     = "INFO"


_SEV_COLOR = {
    Severity.CRITICAL: C.RED,
    Severity.HIGH:     C.ORANGE,
    Severity.MEDIUM:   C.YELLOW,
    Severity.LOW:      C.CYAN,
    Severity.INFO:     C.GREY,
}

_SEV_ICON = {
    Severity.CRITICAL: "[CRIT]",
    Severity.HIGH:     "[HIGH]",
    Severity.MEDIUM:   "[MED] ",
    Severity.LOW:      "[LOW] ",
    Severity.INFO:     "[i]   ",
}


@dataclass
class Finding:
    title: str
    severity: Severity
    url: str
    module: str
    description: str
    evidence: str = ""
    remediation: str = ""
    cwe: str = ""
    cvss: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    extra: dict = field(default_factory=dict)


# ─────────────────────────── Reporter ───────────────────────────────────────

class Reporter:
    LOGO = r"""
 ██████╗ ██╗  ██╗ █████╗ ███╗   ██╗████████╗ ██████╗ ███╗   ███╗
 ██╔══██╗██║  ██║██╔══██╗████╗  ██║╚══██╔══╝██╔═══██╗████╗ ████║
 ██████╔╝███████║███████║██╔██╗ ██║   ██║   ██║   ██║██╔████╔██║
 ██╔═══╝ ██╔══██║██╔══██║██║╚██╗██║   ██║   ██║   ██║██║╚██╔╝██║
 ██║     ██║  ██║██║  ██║██║ ╚████║   ██║   ╚██████╔╝██║ ╚═╝ ██║
 ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝    ╚═════╝ ╚═╝     ╚═╝
                                          ███████╗ ██████╗ █████╗ ███╗   ██╗
                                          ██╔════╝██╔════╝██╔══██╗████╗  ██║
                                          ███████╗██║     ███████║██╔██╗ ██║
                                          ╚════██║██║     ██╔══██║██║╚██╗██║
                                          ███████║╚██████╗██║  ██║██║ ╚████║
                                          ╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝"""

    def __init__(self, config: "PhantomConfig") -> None:
        self._cfg = config
        self._color = _supports_color()

    def _c(self, color: str, text: str) -> str:
        if not self._color:
            return text
        return f"{color}{text}{C.RESET}"

    def _print(self, *args, **kwargs) -> None:
        if not self._cfg.scan.silent:
            print(*args, **kwargs)

    # ── Public interface ──────────────────────────────────────────────────────

    def banner(self, target: str) -> None:
        self._print(self._c(C.CYAN, self.LOGO))
        self._print()
        self._print(self._c(C.DIM, f"  Version {VERSION}  |  Target: ") + self._c(C.WHITE + C.BOLD, target))
        self._print(self._c(C.DIM, f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"))
        self._print()

    def phase(self, name: str) -> None:
        self._print()
        line = f"  ┌─ {name} "
        self._print(self._c(C.MAGENTA, line + "─" * max(0, 60 - len(line))))

    def fingerprint(self, fp: "Fingerprint") -> None:
        self._print(self._c(C.DIM, "  │"))
        lines = [
            ("WAF",    fp.waf or "None detected",     C.YELLOW if fp.waf else C.GREEN),
            ("Server", fp.server or "Unknown",         C.WHITE),
            ("Tech",   ", ".join(fp.technologies) or "Unknown", C.WHITE),
            ("CMS",    fp.cms or "None",               C.WHITE),
            ("CDN",    fp.cdn or "None",               C.WHITE),
        ]
        for key, val, color in lines:
            self._print(
                self._c(C.DIM, "  │  ") +
                self._c(C.GREY, f"{key:<10}") +
                self._c(color, val)
            )

    def finding(self, f: Finding) -> None:
        if self._cfg.scan.silent and f.severity == Severity.INFO:
            return
        icon = _SEV_ICON[f.severity]
        color = _SEV_COLOR[f.severity]
        sev_tag = self._c(color + C.BOLD, f"[{f.severity.value}]")
        self._print(
            f"\n  {icon}  {sev_tag} "
            + self._c(C.WHITE + C.BOLD, f.title)
        )
        self._print(self._c(C.DIM, f"       Module: {f.module}"))
        self._print(self._c(C.DIM, f"       URL:    ") + self._c(C.CYAN, f.url))
        if f.description:
            self._print(self._c(C.DIM, f"       Desc:   {f.description}"))
        if f.evidence:
            # FIX: evidence toujours affichee (etait cachee sans --verbose)
            self._print(self._c(C.DIM, f"       Evid:   {f.evidence[:200]}"))
        if f.cwe:
            self._print(self._c(C.DIM, f"       CWE:    {f.cwe}"))
        if f.remediation:
            # FIX: remediation n'etait jamais affichee dans le terminal
            self._print(self._c(C.DIM, f"       Fix:    {f.remediation[:200]}"))

    def summary(self, result: "ScanResult") -> None:
        from phantomscan.core.engine import ScanResult
        findings = result.findings
        sev_counts = {s: sum(1 for f in findings if f.severity == s) for s in Severity}

        self._print()
        self._print(self._c(C.MAGENTA, "  " + "═" * 60))
        self._print(self._c(C.WHITE + C.BOLD, "  SCAN SUMMARY"))
        self._print(self._c(C.MAGENTA, "  " + "═" * 60))
        self._print(f"  Target   : {self._c(C.CYAN, result.target)}")
        self._print(f"  Duration : {self._c(C.WHITE, f'{result.duration_s:.1f}s')}")
        self._print(f"  Requests : {self._c(C.WHITE, str(getattr(result, 'total_requests', '—')))}")
        self._print(f"  Findings : {self._c(C.WHITE, str(len(findings)))}")
        self._print()
        for sev in Severity:
            count = sev_counts[sev]
            color = _SEV_COLOR[sev]
            bar = "#" * count + "." * max(0, 10 - count)
            self._print(f"  {_SEV_ICON[sev]}  {self._c(color, f'{sev.value:<10}')}  {self._c(color, bar)}  {count}")
        self._print()
        if result.errors:
            self._print(self._c(C.ORANGE, f"  Errors: {len(result.errors)}"))
            if self._cfg.scan.verbose:
                for e in result.errors:
                    self._print(self._c(C.DIM, f"    • {e}"))
        self._print(self._c(C.MAGENTA, "  " + "═" * 60))
        self._print()

    def write_json(self, result: "ScanResult", path: str) -> None:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        data = {
            "target": result.target,
            "duration_s": result.duration_s,
            "fingerprint": asdict(result.fingerprint) if result.fingerprint else None,
            "findings": [asdict(f) for f in result.findings],
            "errors": result.errors,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, default=str)
        if not self._cfg.scan.silent:
            print(self._c(C.GREEN, f"\n  [+] JSON report saved → {path}"))


    # ── Multi-format export ───────────────────────────────────────────────────

    def write_html(self, result: "ScanResult", path: str) -> None:
        """Export HTML autonome avec mise en forme, filtres, tri par sévérité."""
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

        from dataclasses import asdict
        from datetime import datetime, timezone

        sev_order = {
            Severity.CRITICAL: 0,
            Severity.HIGH: 1,
            Severity.MEDIUM: 2,
            Severity.LOW: 3,
            Severity.INFO: 4,
        }
        sev_color = {
            Severity.CRITICAL: "#e74c3c",
            Severity.HIGH: "#e67e22",
            Severity.MEDIUM: "#f1c40f",
            Severity.LOW: "#3498db",
            Severity.INFO: "#95a5a6",
        }

        findings_sorted = sorted(
            result.findings, key=lambda f: sev_order.get(f.severity, 99)
        )

        def _sev_badge(sev: Severity) -> str:
            color = sev_color.get(sev, "#999")
            return f'<span class="badge" style="background:{color}">{sev.value}</span>'

        def _esc(s: str) -> str:
            return (
                s.replace("&", "&amp;")
                 .replace("<", "&lt;")
                 .replace(">", "&gt;")
                 .replace('"', "&quot;")
            )

        fp = result.fingerprint
        fp_rows = ""
        if fp:
            rows = [
                ("WAF", fp.waf or "None"),
                ("Server", fp.server or "Unknown"),
                ("Technologies", ", ".join(fp.technologies) or "Unknown"),
                ("CMS", fp.cms or "None"),
                ("CDN", fp.cdn or "None"),
            ]
            fp_rows = "\n".join(
                f'<tr><td class="label">{k}</td><td>{_esc(str(v))}</td></tr>'
                for k, v in rows
            )

        finding_cards = ""
        for f in findings_sorted:
            finding_cards += f"""
            <div class="finding sev-{f.severity.value.lower()}">
              <div class="finding-header">
                {_sev_badge(f.severity)}
                <span class="finding-title">{_esc(f.title)}</span>
                <span class="finding-module">{_esc(f.module)}</span>
              </div>
              <div class="finding-body">
                <div><strong>URL:</strong> <code>{_esc(f.url)}</code></div>
                {f'<div><strong>Description:</strong> {_esc(f.description)}</div>' if f.description else ''}
                {f'<div><strong>Evidence:</strong> <pre>{_esc(f.evidence[:500])}</pre></div>' if f.evidence else ''}
                {f'<div><strong>CWE:</strong> {_esc(f.cwe)}</div>' if f.cwe else ''}
                {f'<div><strong>Remediation:</strong> {_esc(f.remediation)}</div>' if f.remediation else ''}
              </div>
            </div>"""

        sev_stats = {s: sum(1 for f in result.findings if f.severity == s) for s in Severity}
        stats_html = " ".join(
            f'<span class="stat-badge" style="background:{sev_color[s]}">'
            f'{s.value}: {sev_stats[s]}</span>'
            for s in Severity
        )

        html = f"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PhantomScan Report — {_esc(result.target)}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
         background: #0d1117; color: #c9d1d9; min-height: 100vh; }}
  header {{ background: #161b22; border-bottom: 1px solid #30363d;
           padding: 24px 32px; }}
  header h1 {{ color: #58a6ff; font-size: 1.4rem; }}
  header .meta {{ color: #8b949e; font-size: 0.85rem; margin-top: 6px; }}
  .container {{ max-width: 1100px; margin: 0 auto; padding: 24px 32px; }}
  .card {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px;
          padding: 20px; margin-bottom: 20px; }}
  .card h2 {{ color: #f0f6fc; font-size: 1rem; margin-bottom: 12px; }}
  table {{ width: 100%; border-collapse: collapse; }}
  td {{ padding: 6px 10px; border-bottom: 1px solid #21262d; font-size: 0.9rem; }}
  td.label {{ color: #8b949e; width: 130px; }}
  .badge {{ padding: 2px 8px; border-radius: 4px; font-size: 0.75rem;
           font-weight: 700; color: #fff; text-transform: uppercase; }}
  .stat-badge {{ padding: 4px 10px; border-radius: 4px; font-size: 0.8rem;
                font-weight: 600; color: #fff; }}
  .stats {{ display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 20px; }}
  .finding {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px;
             margin-bottom: 12px; overflow: hidden; }}
  .finding.sev-critical {{ border-left: 3px solid #e74c3c; }}
  .finding.sev-high {{ border-left: 3px solid #e67e22; }}
  .finding.sev-medium {{ border-left: 3px solid #f1c40f; }}
  .finding.sev-low {{ border-left: 3px solid #3498db; }}
  .finding.sev-info {{ border-left: 3px solid #95a5a6; }}
  .finding-header {{ display: flex; align-items: center; gap: 10px;
                    padding: 12px 16px; background: #0d1117;
                    cursor: pointer; }}
  .finding-title {{ flex: 1; font-weight: 600; color: #f0f6fc; }}
  .finding-module {{ font-size: 0.75rem; color: #8b949e; }}
  .finding-body {{ padding: 14px 16px; font-size: 0.88rem; line-height: 1.6;
                  display: none; border-top: 1px solid #21262d; }}
  .finding-body > div {{ margin-bottom: 8px; }}
  .finding-body code {{ background: #0d1117; padding: 2px 6px; border-radius: 3px;
                       font-family: monospace; font-size: 0.85rem; word-break: break-all; }}
  .finding-body pre {{ background: #0d1117; padding: 8px; border-radius: 4px;
                      font-size: 0.8rem; overflow-x: auto; white-space: pre-wrap;
                      word-break: break-all; }}
  .filters {{ display: flex; gap: 8px; margin-bottom: 16px; flex-wrap: wrap; }}
  .filter-btn {{ padding: 5px 14px; border-radius: 4px; border: 1px solid #30363d;
                background: #21262d; color: #c9d1d9; cursor: pointer;
                font-size: 0.8rem; transition: background 0.15s; }}
  .filter-btn.active {{ background: #388bfd22; border-color: #388bfd; color: #58a6ff; }}
  .info-row {{ display: flex; gap: 24px; font-size: 0.85rem; color: #8b949e; }}
</style>
</head>
<body>
<header>
  <h1>🔍 PhantomScan v{VERSION} — Rapport de sécurité</h1>
  <div class="meta">
    Cible: <strong style="color:#58a6ff">{_esc(result.target)}</strong> &nbsp;|&nbsp;
    Généré: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')} &nbsp;|&nbsp;
    Durée: {result.duration_s:.1f}s &nbsp;|&nbsp;
    Requêtes: {result.total_requests}
  </div>
</header>
<div class="container">

  <div class="stats">{stats_html}</div>

  {"" if not fp_rows else f'<div class="card"><h2>Fingerprint</h2><table>{fp_rows}</table></div>'}

  <div class="card">
    <h2>Findings ({len(result.findings)})</h2>
    <div class="filters">
      <button class="filter-btn active" onclick="filterSev('all')">Tous</button>
      <button class="filter-btn" onclick="filterSev('critical')" style="border-color:#e74c3c">CRITICAL</button>
      <button class="filter-btn" onclick="filterSev('high')" style="border-color:#e67e22">HIGH</button>
      <button class="filter-btn" onclick="filterSev('medium')" style="border-color:#f1c40f">MEDIUM</button>
      <button class="filter-btn" onclick="filterSev('low')" style="border-color:#3498db">LOW</button>
      <button class="filter-btn" onclick="filterSev('info')" style="border-color:#95a5a6">INFO</button>
    </div>
    {finding_cards if finding_cards else '<p style="color:#8b949e">Aucun finding.</p>'}
  </div>

  {f'<div class="card"><h2>Erreurs ({len(result.errors)})</h2><ul style="padding-left:16px">' + "".join(f"<li style='font-size:.85rem;color:#f85149'>{_esc(e)}</li>" for e in result.errors) + "</ul></div>" if result.errors else ""}

</div>
<script>
  function filterSev(sev) {{
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    event.target.classList.add('active');
    document.querySelectorAll('.finding').forEach(el => {{
      if (sev === 'all' || el.classList.contains('sev-' + sev)) {{
        el.style.display = '';
      }} else {{
        el.style.display = 'none';
      }}
    }});
  }}
  document.querySelectorAll('.finding-header').forEach(h => {{
    h.addEventListener('click', () => {{
      const body = h.nextElementSibling;
      body.style.display = body.style.display === 'block' ? 'none' : 'block';
    }});
  }});
</script>
</body>
</html>"""

        with open(path, "w", encoding="utf-8") as fh:
            fh.write(html)

        if not self._cfg.scan.silent:
            print(self._c(C.GREEN, f"\n  [+] HTML report saved → {path}"))

    def write_markdown(self, result: "ScanResult", path: str) -> None:
        """Export Markdown compatible GitHub/Obsidian."""
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

        from datetime import datetime, timezone

        sev_order = {
            Severity.CRITICAL: 0,
            Severity.HIGH: 1,
            Severity.MEDIUM: 2,
            Severity.LOW: 3,
            Severity.INFO: 4,
        }
        findings_sorted = sorted(
            result.findings, key=lambda f: sev_order.get(f.severity, 99)
        )

        sev_emoji = {
            Severity.CRITICAL: "🔴",
            Severity.HIGH: "🟠",
            Severity.MEDIUM: "🟡",
            Severity.LOW: "🔵",
            Severity.INFO: "⚪",
        }

        sev_stats = {s: sum(1 for f in result.findings if f.severity == s) for s in Severity}

        lines = [
            f"# PhantomScan v{VERSION} — Rapport de sécurité",
            "",
            f"**Cible :** `{result.target}`  ",
            f"**Généré :** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}  ",
            f"**Durée :** {result.duration_s:.1f}s | **Requêtes :** {result.total_requests}",
            "",
            "---",
            "",
            "## Résumé",
            "",
            "| Sévérité | Nombre |",
            "|----------|--------|",
        ]
        for sev in Severity:
            lines.append(f"| {sev_emoji[sev]} {sev.value} | {sev_stats[sev]} |")

        fp = result.fingerprint
        if fp:
            lines += [
                "",
                "## Fingerprint",
                "",
                "| Champ | Valeur |",
                "|-------|--------|",
                f"| WAF | {fp.waf or 'None'} |",
                f"| Server | {fp.server or 'Unknown'} |",
                f"| Technologies | {', '.join(fp.technologies) or 'Unknown'} |",
                f"| CMS | {fp.cms or 'None'} |",
                f"| CDN | {fp.cdn or 'None'} |",
            ]

        lines += [
            "",
            f"## Findings ({len(result.findings)})",
            "",
        ]

        for i, f in enumerate(findings_sorted, 1):
            lines += [
                f"### {i}. {sev_emoji[f.severity]} {f.title}",
                "",
                f"- **Sévérité :** `{f.severity.value}`",
                f"- **Module :** `{f.module}`",
                f"- **URL :** `{f.url}`",
            ]
            if f.description:
                lines.append(f"- **Description :** {f.description}")
            if f.evidence:
                lines += [
                    "",
                    "**Evidence :**",
                    "```",
                    f.evidence[:500],
                    "```",
                ]
            if f.cwe:
                lines.append(f"- **CWE :** {f.cwe}")
            if f.remediation:
                lines.append(f"- **Remediation :** {f.remediation}")
            lines.append("")

        if result.errors:
            lines += [
                "## Erreurs",
                "",
            ]
            for e in result.errors:
                lines.append(f"- `{e}`")

        with open(path, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines))

        if not self._cfg.scan.silent:
            print(self._c(C.GREEN, f"\n  [+] Markdown report saved → {path}"))

    # ── v5.13 — Bug Bounty helpers ───────────────────────────────────────────

    # CVSS 3.1 base scores approximatifs par type de vuln
    # Utilisés quand finding.cvss == 0.0
    _CVSS_MAP: dict[str, float] = {
        # Critiques
        "rce": 9.8, "remote code execution": 9.8, "command injection": 9.8,
        "deserialization": 9.0, "log4shell": 10.0, "xxe": 8.8,
        "sqli": 9.8, "sql injection": 9.8, "nosql injection": 8.1,
        # Élevés
        "ssrf": 8.6, "ssti": 8.8, "lfi": 7.5, "local file inclusion": 7.5,
        "path traversal": 7.5, "file upload": 8.8, "idor": 8.1,
        "jwt": 8.1, "jwt advanced": 8.1, "auth bypass": 8.1,
        "oauth": 7.5, "oauth misconfig": 7.5, "http smuggling": 8.1,
        "race condition": 7.5, "business logic": 7.5,
        # Moyens
        "xss": 6.1, "cross-site scripting": 6.1, "dom xss": 6.1,
        "cors": 6.5, "open redirect": 6.1, "crlf": 6.1,
        "csrf": 6.5, "cache poison": 7.2, "prototype pollution": 6.5,
        "graphql": 6.5, "subdomain takeover": 6.5, "s3": 6.1,
        "api security": 5.4, "otp bypass": 6.8, "rate limit": 5.3,
        # Faibles
        "clickjacking": 4.3, "tls": 5.9, "headers": 4.3,
        "information disclosure": 5.3, "waf fingerprint": 3.1,
        "actuator": 5.8,
    }

    def _auto_cvss(self, finding: "Finding") -> float:
        """Retourne un score CVSS 3.1 estimé basé sur le titre/module du finding."""
        if finding.cvss and finding.cvss > 0.0:
            return finding.cvss
        text = (finding.title + " " + finding.module).lower()
        best = 0.0
        for keyword, score in self._CVSS_MAP.items():
            if keyword in text:
                best = max(best, score)
        # Fallback par sévérité si aucun keyword ne matche
        if best == 0.0:
            best = {
                Severity.CRITICAL: 9.0,
                Severity.HIGH: 7.5,
                Severity.MEDIUM: 5.0,
                Severity.LOW: 3.0,
                Severity.INFO: 1.0,
            }.get(finding.severity, 1.0)
        return best

    def write_bb_report(self, result: "ScanResult", path: str) -> None:
        """
        v5.13 — Génère un rapport Markdown format Bug Bounty.
        Compatible HackerOne / Bugcrowd / Intigriti.
        Chaque finding HIGH/CRITICAL est présenté comme un rapport
        soumettable séparé, avec CVSS auto-calculé, steps to reproduce
        et preuve d'exploitation.

        Findings INFO sont exclus (peu de valeur en BB).
        """
        import os
        from datetime import datetime, timezone

        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

        sev_order = {Severity.CRITICAL: 0, Severity.HIGH: 1, Severity.MEDIUM: 2,
                     Severity.LOW: 3, Severity.INFO: 4}
        bb_findings = [
            f for f in result.findings
            if f.severity not in (Severity.INFO,)
        ]
        bb_findings.sort(key=lambda f: sev_order.get(f.severity, 99))

        sev_emoji = {
            Severity.CRITICAL: "🔴", Severity.HIGH: "🟠",
            Severity.MEDIUM: "🟡", Severity.LOW: "🔵", Severity.INFO: "⚪",
        }

        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        fp = result.fingerprint
        tech_str = ", ".join(fp.technologies) if fp and fp.technologies else "Unknown"

        lines = [
            f"# Bug Bounty Report — {result.target}",
            "",
            f"> Generated by PhantomScan v{VERSION} on {now}",
            f"> Target: `{result.target}` | Duration: {result.duration_s:.0f}s "
            f"| Requests: {result.total_requests}",
            "",
            "---",
            "",
            "## Executive Summary",
            "",
            f"PhantomScan discovered **{len(bb_findings)}** actionable "
            f"finding(s) on `{result.target}`:",
            "",
            "| Severity | Count |",
            "|----------|-------|",
        ]
        for sev in (Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW):
            n = sum(1 for f in bb_findings if f.severity == sev)
            if n:
                lines.append(f"| {sev_emoji[sev]} **{sev.value}** | {n} |")

        if fp:
            lines += [
                "",
                "**Target fingerprint:**",
                f"- Server: `{fp.server or 'Unknown'}`",
                f"- Technologies: `{tech_str}`",
                f"- WAF: `{fp.waf or 'None detected'}`",
                f"- CMS: `{fp.cms or 'None detected'}`",
            ]

        lines += ["", "---", ""]

        for idx, f in enumerate(bb_findings, 1):
            cvss = self._auto_cvss(f)
            cvss_str = f"{cvss:.1f}"

            lines += [
                f"## Report #{idx} — {f.title}",
                "",
                f"| Field | Value |",
                f"|-------|-------|",
                f"| **Severity** | {sev_emoji[f.severity]} {f.severity.value} |",
                f"| **CVSS 3.1** | `{cvss_str}` |",
                f"| **Endpoint** | `{f.url}` |",
                f"| **Module** | `{f.module}` |",
            ]
            if f.cwe:
                lines.append(f"| **CWE** | [{f.cwe}](https://cwe.mitre.org/data/definitions/"
                             f"{f.cwe.replace('CWE-','')}.html) |")

            lines += ["", "### Description", "", f.description or "_No description provided._", ""]

            if f.evidence:
                lines += [
                    "### Proof of Concept / Evidence",
                    "",
                    "```",
                    f.evidence[:800],
                    "```",
                    "",
                ]

            lines += [
                "### Steps to Reproduce",
                "",
                f"1. Navigate to: `{f.url}`",
                f"2. Trigger the vulnerability as described above.",
                f"3. Observe the response confirming the issue (see evidence above).",
                "",
            ]

            if f.remediation:
                lines += [
                    "### Remediation",
                    "",
                    f.remediation,
                    "",
                ]

            lines += ["---", ""]

        if not bb_findings:
            lines += [
                "> No HIGH/MEDIUM/CRITICAL/LOW findings were identified.",
                "> This does not guarantee the absence of vulnerabilities.",
                "",
            ]

        with open(path, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines))

        if not self._cfg.scan.silent:
            print(self._c(C.GREEN, f"\n  [BB] Bug Bounty report saved → {path}"))
            print(self._c(C.CYAN, f"       {len(bb_findings)} finding(s) | "
                                   f"{sum(1 for f in bb_findings if f.severity in (Severity.CRITICAL, Severity.HIGH))} "
                                   f"HIGH/CRITICAL"))
