"""
PhantomScan — Bug Bounty Markdown Reporter (v5.19)
====================================================
Génère un rapport Markdown au format attendu par les programmes BB
(HackerOne, Bugcrowd, Intigriti).

Chaque finding produit une section avec :
  - Title + Severity + CVSS Score & Vector
  - Summary
  - Steps to Reproduce (numéroté, copiable)
  - Proof of Concept (curl + Burp request)
  - Impact (basé sur CWE + business logic)
  - Suggested Fix
  - References (CWE, OWASP)

Le rapport peut être exporté comme un seul fichier global ou un fichier
par finding (mode --md-per-finding) pour les soumissions séparées.
"""

from __future__ import annotations

import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING
from urllib.parse import urlparse

if TYPE_CHECKING:
    from phantomscan.core.engine import ScanResult
    from phantomscan.output.reporter import Finding


# Mapping CWE → URL OWASP-friendly
_CWE_REFERENCES: dict[str, str] = {
    "CWE-79":  "https://owasp.org/www-community/attacks/xss/",
    "CWE-89":  "https://owasp.org/www-community/attacks/SQL_Injection",
    "CWE-78":  "https://owasp.org/www-community/attacks/Command_Injection",
    "CWE-94":  "https://owasp.org/www-community/attacks/Code_Injection",
    "CWE-918": "https://owasp.org/www-community/attacks/Server_Side_Request_Forgery",
    "CWE-22":  "https://owasp.org/www-community/attacks/Path_Traversal",
    "CWE-611": "https://owasp.org/www-community/vulnerabilities/XML_External_Entity_(XXE)_Processing",
    "CWE-639": "https://owasp.org/www-project-api-security/", # IDOR / BOLA
    "CWE-352": "https://owasp.org/www-community/attacks/csrf",
    "CWE-601": "https://cwe.mitre.org/data/definitions/601.html",  # Open Redirect
    "CWE-287": "https://cwe.mitre.org/data/definitions/287.html",  # Auth Bypass
    "CWE-863": "https://cwe.mitre.org/data/definitions/863.html",  # AuthZ
    "CWE-502": "https://owasp.org/www-community/vulnerabilities/Deserialization_of_untrusted_data",
    "CWE-200": "https://cwe.mitre.org/data/definitions/200.html",  # Info Exposure
    "CWE-915": "https://cwe.mitre.org/data/definitions/915.html",  # Mass Assignment
    "CWE-1395":"https://cwe.mitre.org/data/definitions/1395.html", # Dependency
    "CWE-444": "https://owasp.org/www-community/attacks/HTTP_Smuggling",
    "CWE-269": "https://cwe.mitre.org/data/definitions/269.html",  # Privilege escalation
    "CWE-345": "https://cwe.mitre.org/data/definitions/345.html",  # Insufficient Verification
    "CWE-98":  "https://cwe.mitre.org/data/definitions/98.html",   # Remote File Inclusion
}


def _sanitize_filename(s: str, max_len: int = 80) -> str:
    """Nettoie une chaîne pour utilisation dans un nom de fichier."""
    s = re.sub(r"[^\w\-.]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s[:max_len] if s else "finding"


def _build_curl(method: str, url: str, headers: dict | None = None,
                body: str | None = None) -> str:
    """Construit une commande curl reproductible."""
    parts = [f"curl -i -X {method.upper()}"]
    parts.append(f"  '{url}'")
    if headers:
        for k, v in headers.items():
            # Échapper les single-quotes pour la copie shell
            v_safe = str(v).replace("'", "'\\''")
            parts.append(f"  -H '{k}: {v_safe}'")
    if body:
        body_safe = body.replace("'", "'\\''")
        parts.append(f"  --data-raw '{body_safe}'")
    return " \\\n".join(parts)


def _build_burp_request(method: str, url: str, headers: dict | None = None,
                        body: str | None = None) -> str:
    """Construit une raw HTTP request façon Burp."""
    parsed = urlparse(url)
    path = parsed.path or "/"
    if parsed.query:
        path = f"{path}?{parsed.query}"
    lines = [f"{method.upper()} {path} HTTP/1.1"]
    lines.append(f"Host: {parsed.netloc}")
    if headers:
        for k, v in headers.items():
            if k.lower() != "host":
                lines.append(f"{k}: {v}")
    lines.append("")
    if body:
        lines.append(body)
    return "\n".join(lines)


def _extract_request_components(finding: "Finding") -> tuple[str, str, dict, str | None]:
    """
    Tente d'extraire (method, url, headers, body) depuis l'evidence du finding.
    L'evidence n'est pas standardisée → fallback minimal.
    """
    method = "GET"
    url = finding.url
    headers: dict[str, str] = {}
    body: str | None = None

    evidence = finding.evidence or ""
    # Chercher "POST <url>" ou "method=POST" dans l'evidence
    m = re.search(r'\b(POST|PUT|PATCH|DELETE|GET|OPTIONS|HEAD)\b', evidence)
    if m:
        method = m.group(1)

    # Si l'evidence contient "Header: X-Foo: bar"
    for line in evidence.splitlines():
        m2 = re.match(r'\s*Header:\s*([\w-]+):\s*(.+)', line)
        if m2:
            headers[m2.group(1)] = m2.group(2)

    # Si l'evidence mentionne "body=..." ou "field=..."
    m3 = re.search(r'(?:body|payload)[=:]\s*(.+?)(?:\s*\||$)', evidence)
    if m3:
        body = m3.group(1).strip()

    return method, url, headers, body


def _impact_blurb(finding: "Finding") -> str:
    """Génère un paragraphe d'impact basé sur le CWE / module."""
    sev = finding.severity.value if hasattr(finding.severity, "value") else str(finding.severity)
    module = finding.module.lower()
    cwe = finding.cwe or ""

    if "sqli" in module:
        return (
            "Exécution de requêtes SQL arbitraires sur la base de données. "
            "Permet l'extraction de données utilisateurs, l'élévation de privilèges, "
            "et potentiellement l'exécution de commandes (xp_cmdshell, COPY FROM PROGRAM)."
        )
    if "cmdi" in module or "log4shell" in module or "ssti" in module:
        return (
            "Exécution de code à distance (RCE) sur le serveur web. "
            "Compromission complète : lecture/écriture du système de fichiers, "
            "pivot interne, vol de credentials, persistance."
        )
    if "ssrf" in module:
        return (
            "Le serveur peut être forcé à émettre des requêtes vers des services internes "
            "(IMDS cloud, base de données, services backend). Risque d'exfiltration de "
            "tokens IAM/AWS, de scan du réseau interne et de pivot."
        )
    if "lfi" in module or "path_traversal" in module:
        return (
            "Lecture arbitraire de fichiers sur le serveur : config, clés privées, "
            "secrets, source code. Selon le contexte (PHP, log poisoning) peut "
            "escalader vers une RCE."
        )
    if "idor" in module or "bola" in finding.title.lower():
        return (
            "Accès à des ressources d'autres utilisateurs sans autorisation. "
            "Selon la nature de la ressource : fuite de données personnelles (RGPD), "
            "lecture/modification de comptes tiers, fraude."
        )
    if "xxe" in module:
        return (
            "Lecture de fichiers locaux via entités XML externes, voire SSRF. "
            "Dans certaines configurations Java/Xerces : exécution de code."
        )
    if "deserialization" in module:
        return (
            "Désérialisation de données non fiables → exécution de code arbitraire "
            "via gadget chains (Java/Spring, PHP, .NET, Python pickle)."
        )
    if "xss" in module:
        return (
            "Exécution de JavaScript dans le navigateur des utilisateurs. "
            "Vol de cookies de session, hijacking de comptes, clickjacking, "
            "actions à la place de la victime."
        )
    if "auth" in module or "jwt" in module:
        return (
            "Contournement du contrôle d'authentification ou usurpation d'identité "
            "via manipulation de tokens. Permet l'accès à des comptes arbitraires."
        )
    if "open_redirect" in module:
        return (
            "Redirection contrôlée par l'attaquant vers un domaine externe. "
            "Vecteur de phishing crédible (le lien initial est légitime). "
            "Chaînable avec OAuth pour vol de tokens."
        )
    if "subdomain_takeover" in module:
        return (
            "Prise de contrôle d'un sous-domaine pointant vers un service tiers "
            "non revendiqué. Permet l'hébergement de contenus malveillants sur le "
            "domaine officiel, potentiellement l'envoi d'emails ou la délivrance de cookies."
        )
    if "mass_assignment" in module:
        return (
            "Modification de champs sensibles non exposés par l'API "
            "(role, is_admin, balance). Permet l'élévation de privilèges et "
            "des manipulations de données critiques."
        )
    return (
        f"Impact sécurité de severity {sev}. Voir la description du finding pour "
        f"les détails et la chaîne d'exploitation potentielle."
    )


def _format_finding_md(finding: "Finding", index: int = 1) -> str:
    """Formatte un finding en Markdown BB-ready."""
    sev = finding.severity.value if hasattr(finding.severity, "value") else str(finding.severity)
    cvss_score = finding.cvss
    cvss_vector = (finding.extra or {}).get("cvss_vector", "")

    method, url, headers, body = _extract_request_components(finding)
    curl_cmd = _build_curl(method, url, headers, body)
    burp_req = _build_burp_request(method, url, headers, body)

    cwe_link = ""
    if finding.cwe and finding.cwe in _CWE_REFERENCES:
        cwe_link = f"[{finding.cwe}]({_CWE_REFERENCES[finding.cwe]})"
    elif finding.cwe:
        cwe_link = finding.cwe

    parts: list[str] = []
    parts.append(f"## #{index} — {finding.title}")
    parts.append("")
    parts.append(f"- **Severity** : `{sev}`")
    if cvss_score > 0:
        parts.append(f"- **CVSS 3.1** : `{cvss_score}` ({cvss_vector})")
    if cwe_link:
        parts.append(f"- **CWE** : {cwe_link}")
    parts.append(f"- **URL** : `{finding.url}`")
    parts.append(f"- **Module** : `{finding.module}`")
    parts.append("")
    parts.append("### Summary")
    parts.append(finding.description or "(no description)")
    parts.append("")
    parts.append("### Impact")
    parts.append(_impact_blurb(finding))
    parts.append("")
    parts.append("### Steps to Reproduce")
    parts.append("1. Authentifier sur l'application (si nécessaire).")
    parts.append(f"2. Émettre la requête vers `{finding.url}` avec le payload ci-dessous.")
    parts.append("3. Observer la réponse — voir l'evidence pour les indicateurs.")
    parts.append("")
    parts.append("### Proof of Concept")
    parts.append("")
    parts.append("**curl :**")
    parts.append("```bash")
    parts.append(curl_cmd)
    parts.append("```")
    parts.append("")
    parts.append("**Raw HTTP request (Burp-style) :**")
    parts.append("```http")
    parts.append(burp_req)
    parts.append("```")
    if finding.evidence:
        parts.append("")
        parts.append("**Evidence collected by scanner :**")
        parts.append("```")
        parts.append(finding.evidence[:2000])
        parts.append("```")
    parts.append("")
    parts.append("### Suggested Fix")
    parts.append(finding.remediation or "(see CWE reference for guidance)")
    if finding.cwe and finding.cwe in _CWE_REFERENCES:
        parts.append("")
        parts.append("### References")
        parts.append(f"- {finding.cwe}: {_CWE_REFERENCES[finding.cwe]}")
    parts.append("")
    parts.append("---")
    parts.append("")
    return "\n".join(parts)


def _executive_summary(result: "ScanResult") -> str:
    """Section de tête : counts par severity + métriques."""
    parts: list[str] = []
    parts.append(f"# PhantomScan BB Report — {result.target}")
    parts.append("")
    parts.append(f"_Generated: {datetime.now(timezone.utc).isoformat()}_")
    parts.append("")
    parts.append("## Executive Summary")
    parts.append("")

    # Compter par severity
    counts: dict[str, int] = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
    for f in result.findings:
        sev = f.severity.value if hasattr(f.severity, "value") else str(f.severity)
        counts[sev] = counts.get(sev, 0) + 1

    parts.append("| Severity | Count |")
    parts.append("|----------|-------|")
    for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
        parts.append(f"| {sev} | {counts.get(sev, 0)} |")
    parts.append("")

    parts.append(f"- **Target** : `{result.target}`")
    parts.append(f"- **Duration** : {result.duration_s:.1f}s")
    parts.append(f"- **Total HTTP requests** : {result.total_requests}")
    if result.fingerprint:
        fp = result.fingerprint
        parts.append(f"- **Tech stack** : {', '.join(fp.technologies) or 'unknown'}")
        if fp.waf:
            parts.append(f"- **WAF detected** : {fp.waf}")
    parts.append("")
    return "\n".join(parts)


def write_markdown_report(result: "ScanResult", output_path: str,
                          per_finding_dir: str | None = None) -> dict:
    """
    Écrit le rapport Markdown.

    Args:
        result: ScanResult complet
        output_path: chemin du rapport global (un seul fichier)
        per_finding_dir: si fourni, écrit aussi un fichier .md par finding
                         dans ce dossier — utile pour soumissions BB séparées

    Returns:
        dict avec les chemins des fichiers écrits
    """
    written = {"global": output_path, "per_finding": []}

    # Trier : critical d'abord, puis high, etc.
    severity_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
    sorted_findings = sorted(
        result.findings,
        key=lambda f: severity_rank.get(
            f.severity.value if hasattr(f.severity, "value") else str(f.severity), 5
        ),
    )

    # Rapport global
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as fh:
        fh.write(_executive_summary(result))
        fh.write("## Findings\n\n")
        for i, finding in enumerate(sorted_findings, 1):
            fh.write(_format_finding_md(finding, index=i))

    # Mode per-finding
    if per_finding_dir and sorted_findings:
        Path(per_finding_dir).mkdir(parents=True, exist_ok=True)
        for i, finding in enumerate(sorted_findings, 1):
            sev = finding.severity.value if hasattr(finding.severity, "value") else str(finding.severity)
            fname = f"{i:03d}_{sev}_{_sanitize_filename(finding.title, 50)}.md"
            fpath = os.path.join(per_finding_dir, fname)
            with open(fpath, "w", encoding="utf-8") as fh:
                fh.write(f"# {finding.title}\n\n")
                fh.write(f"_Target: `{result.target}` — generated {datetime.now(timezone.utc).isoformat()}_\n\n")
                fh.write(_format_finding_md(finding, index=i))
            written["per_finding"].append(fpath)

    return written
