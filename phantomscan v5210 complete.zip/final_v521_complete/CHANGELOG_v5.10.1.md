# PhantomScan — CHANGELOG v5.10.1 (hotfix)

## Problème : 0 findings systématiques (faux négatifs massifs)

La v5.10.0 héritait d'une série de durcissements introduits en v5.9
("v5.9-fp" dans le code) qui, combinés, rendaient l'heuristique trop
conservatrice pour détecter quoi que ce soit sur les apps modernes.

---

## Corrections apportées — `core/heuristic.py`

### 1. `SIZE_ZSCORE_DYNAMIC_THRESHOLD` : 4.5 → 3.2

Presque toutes les apps modernes sont classifiées "dynamiques" (CSRF token,
nonce, requestId…). Un seuil de 4.5σ était quasi impossible à dépasser,
même avec un payload injecté qui modifie substantiellement la réponse.

### 2. Seuil `is_dynamic` (variation de taille) : 3% → 8%

Une variation de taille de 3% entre requêtes normales (GZIP, padding
aléatoire, timestamp) suffisait à basculer en mode dynamique et déclencher
le seuil 4.5σ. 8% est plus représentatif d'une vraie page dynamique.

### 3. Score `result.interesting` : 0.5 → 0.3

Le score requis pour qu'une réponse soit considérée intéressante était trop
élevé. Avec un seul anomalie STATUS_DEVIATION à sévérité 0.7 (ex: 200→500),
le score était 0.7 → passe. Mais avec SIZE_DEVIATION seule (sévérité ~0.3),
on obtenait score=0.3 → rejeté. Désormais 0.3 suffit.

Seuils STATUS_DEVIATION ajustés : 0.6 → 0.5 (cohérence).
Seuil SIZE+score : 0.4 → 0.25.

### 4. Soft-404 tolerance : 3.5% → 6%

`max(150, size * 0.035)` filtrait des réponses vulnérables dont la taille
différait légèrement du soft-404 (ex: page d'erreur SQL légèrement plus
grande que la 404 custom). Revenu à 6% + floor 200 octets.

### 5. Soft-404 probes : 5 → 3

5 probes au démarrage ralentissaient l'initialisation sans apport mesurable.

### 6. `build_endpoint_baselines` n : 5 → 3

Sur des crawls de 200+ endpoints, 5 requêtes/endpoint représentait 1000+
requêtes supplémentaires avant le moindre test d'attaque. 3 est suffisant
pour un profil fiable.

---

## Correction — `config.py`

### 7. `baseline_requests` : 8 → 5

8 requêtes de baseline gonflaient le `timing_stdev` (le serveur se "chauffe"
entre la req 1 et la req 8), ce qui rendait les anomalies timing plus difficiles
à détecter par le z-score.

---

## Rappel : autres causes de 0 findings (non liées au code)

Ces points sont des erreurs d'utilisation, non des bugs :

- **URL sans params GET** → SQLi/XSS ne testent rien sans `?param=val`
  → Toujours lancer sur une URL avec paramètres : `https://target.com/search?q=test`
- **SSRF/Log4Shell** → nécessitent `--ssrf-oob-url` et `--log4shell-canary`
  (ex: interactsh) pour confirmer les vuln blind
- **WAF + rate trop bas** → utiliser `--preset stealth` face à Cloudflare/Akamai
- **Module concurrency** → passer à `--module-concurrency 8` sur cibles complexes
