"""
PhantomScan — AuthContext (v5.19)
==================================
Gestion centralisée du contexte d'authentification pour les scans BB.

Problème résolu : la majorité des bugs critiques (IDOR, BOLA, mass-assignment,
business-logic, race-condition) ne sont détectables QUE dans une session
authentifiée. Avant v5.19, chaque module devait gérer ses propres cookies/headers,
ce qui était à la fois redondant et incomplet (oublis fréquents).

L'AuthContext fournit :
  - Profils multi-utilisateurs (pour comparaisons IDOR cross-account)
  - Refresh automatique des tokens expirés (JWT, OAuth)
  - Détection d'expiration/déconnexion via heuristique de réponse
  - Injection automatique des credentials dans Requester

Usage CLI :
    --auth-cookie "session=abc123; csrf=xyz"
    --auth-header "Authorization: Bearer eyJ..."
    --auth-profile alice:cookie:session=alice_session
    --auth-profile bob:cookie:session=bob_session
    --auth-login-url https://target/api/login --auth-creds alice:p4ss

Usage programmatique :
    ctx = AuthContext()
    ctx.add_profile("alice", cookies={"session": "abc"})
    ctx.add_profile("bob",   cookies={"session": "def"})
    req.attach_auth(ctx, profile="alice")
    # ... requêtes envoyées avec les cookies d'alice ...
    req.attach_auth(ctx, profile="bob")
    # ... requêtes envoyées avec les cookies de bob (pour test IDOR) ...
"""

from __future__ import annotations

import asyncio
import re
import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class AuthProfile:
    """Profil d'authentification : un utilisateur avec ses credentials."""
    name: str
    cookies: dict[str, str] = field(default_factory=dict)
    headers: dict[str, str] = field(default_factory=dict)
    # Pour refresh automatique
    refresh_url: str | None = None
    refresh_body: dict | None = None
    refresh_token: str | None = None
    # Fingerprint de session valide (pour détecter expiration)
    valid_fingerprint: str | None = None
    last_validated: float = 0.0
    # Métadonnées (utile pour IDOR : ID utilisateur, email, role)
    user_id: str | None = None
    email: str | None = None
    role: str | None = None

    def cookie_header(self) -> str:
        """Construit le header Cookie complet."""
        return "; ".join(f"{k}={v}" for k, v in self.cookies.items())

    def all_headers(self) -> dict[str, str]:
        """Retourne tous les headers (auth + cookies fusionnés)."""
        result = dict(self.headers)
        if self.cookies:
            existing = result.get("Cookie", "")
            cookie_str = self.cookie_header()
            result["Cookie"] = f"{existing}; {cookie_str}" if existing else cookie_str
        return result


# Indicateurs heuristiques d'une session expirée/invalide dans la réponse
_AUTH_FAIL_PATTERNS = [
    re.compile(r'\b(?:session\s+expired|please\s+log\s*in|unauthor[iz]ed|authentication\s+required)\b', re.I),
    re.compile(r'\b(?:invalid\s+token|token\s+expired|jwt\s+expired)\b', re.I),
    re.compile(r'<title>[^<]*(?:login|sign\s*in)[^<]*</title>', re.I),
]


class AuthContext:
    """
    Contexte d'authentification global, partagé entre tous les modules.
    Thread-safe via asyncio.Lock.
    """

    def __init__(self) -> None:
        self._profiles: dict[str, AuthProfile] = {}
        self._active: str | None = None
        self._lock = asyncio.Lock()
        # Compteur d'expirations détectées par profil (heuristique)
        self._expiry_count: dict[str, int] = {}

    def add_profile(
        self,
        name: str,
        cookies: dict[str, str] | None = None,
        headers: dict[str, str] | None = None,
        user_id: str | None = None,
        email: str | None = None,
        role: str | None = None,
        refresh_url: str | None = None,
        refresh_body: dict | None = None,
    ) -> AuthProfile:
        """Ajoute un profil. Si nom déjà pris, écrase."""
        prof = AuthProfile(
            name=name,
            cookies=cookies or {},
            headers=headers or {},
            user_id=user_id,
            email=email,
            role=role,
            refresh_url=refresh_url,
            refresh_body=refresh_body,
        )
        self._profiles[name] = prof
        if self._active is None:
            self._active = name
        return prof

    def add_from_string(self, spec: str) -> AuthProfile | None:
        """
        Parse une spec CLI : "name:type:value"
        Examples :
          "alice:cookie:session=abc; csrf=xyz"
          "bob:header:Authorization=Bearer eyJ..."
          "carol:bearer:eyJ..."
        """
        try:
            name, kind, value = spec.split(":", 2)
        except ValueError:
            return None

        kind = kind.lower().strip()
        if kind == "cookie":
            cookies = {}
            for kv in value.split(";"):
                kv = kv.strip()
                if "=" in kv:
                    k, v = kv.split("=", 1)
                    cookies[k.strip()] = v.strip()
            return self.add_profile(name, cookies=cookies)
        elif kind == "header":
            if "=" in value:
                k, v = value.split("=", 1)
                return self.add_profile(name, headers={k.strip(): v.strip()})
        elif kind == "bearer":
            return self.add_profile(name, headers={"Authorization": f"Bearer {value.strip()}"})
        return None

    @property
    def profiles(self) -> list[AuthProfile]:
        return list(self._profiles.values())

    @property
    def active_profile(self) -> AuthProfile | None:
        if self._active and self._active in self._profiles:
            return self._profiles[self._active]
        return None

    def has_auth(self) -> bool:
        """True si au moins un profil avec credentials existe."""
        return any(
            (p.cookies or p.headers)
            for p in self._profiles.values()
        )

    def has_multiple_profiles(self) -> bool:
        """True si ≥ 2 profils → tests cross-user IDOR/BOLA possibles."""
        return len(self._profiles) >= 2

    async def use(self, name: str) -> bool:
        """Active un profil. Retourne False si introuvable."""
        async with self._lock:
            if name not in self._profiles:
                return False
            self._active = name
            return True

    def detect_session_invalid(self, status: int, body: str, url: str) -> bool:
        """
        Heuristique : la réponse indique-t-elle une session expirée ?
        Retourne True si oui (le scanner doit alors recharger l'auth).
        """
        # 401 explicite
        if status == 401:
            return True
        # Redirect vers /login
        if status in (302, 303, 307) and "login" in url.lower():
            return True
        # Patterns dans le body
        if status in (200, 401, 403):
            sample = body[:8000]
            for pat in _AUTH_FAIL_PATTERNS:
                if pat.search(sample):
                    return True
        return False

    def report_session_invalid(self, profile_name: str | None = None) -> None:
        """À appeler quand un module détecte une session invalide."""
        name = profile_name or self._active
        if name:
            self._expiry_count[name] = self._expiry_count.get(name, 0) + 1

    def is_profile_unhealthy(self, name: str, threshold: int = 3) -> bool:
        """Un profil est unhealthy si on a vu >= threshold expirations."""
        return self._expiry_count.get(name, 0) >= threshold

    def summary(self) -> dict[str, Any]:
        return {
            "profiles": [
                {
                    "name": p.name,
                    "has_cookies": bool(p.cookies),
                    "has_headers": bool(p.headers),
                    "user_id": p.user_id,
                    "email": p.email,
                    "expiries_detected": self._expiry_count.get(p.name, 0),
                }
                for p in self._profiles.values()
            ],
            "active": self._active,
            "multi_profile_available": self.has_multiple_profiles(),
        }
