"""
PhantomScan — Heuristic Engine
Analyse les réponses, établit une baseline, détecte les anomalies.

Améliorations v5.7:
- Baselines par endpoint : chaque URL crawlée obtient sa propre baseline
  comportementale (status, taille, timing) avant que les modules attaquent.
  Plus de baseline globale unique sur la homepage — chaque endpoint est
  comparé à lui-même, pas à la racine.
- build_endpoint_baselines() : méthode appelée après le crawl passif pour
  pré-calculer toutes les baselines sur les endpoints découverts.
- analyze() / is_real_hit() : utilise automatiquement la baseline spécifique
  à l'URL testée si disponible, sinon fallback sur la baseline globale.

Améliorations v4.1:
- Baseline multi-URL (page racine + paths connus) pour profil plus robuste
- Soft-404 triple probe : médiane sur 3 URLs aléatoires → évite les faux positifs
  sur pages dont la taille varie légèrement à chaque requête
- Content-hash fingerprint : détecte les pages dynamiques (timestamps, nonces)
  et ajuste le SIZE_ZSCORE_THRESHOLD en conséquence
- is_real_hit : score de confiance 0-100 au lieu du booléen binaire
- Jitter adaptatif : ralentit automatiquement si WAF détecté
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
import statistics
from dataclasses import dataclass, field
from enum import Enum, auto

from phantomscan.core.requester import ProbeResponse, Requester
import random
import string
from phantomscan.core.fingerprint import Fingerprint


# ─────────────────────────── Enums / Types ──────────────────────────────────

class AnomalyType(Enum):
    STATUS_DEVIATION    = auto()
    SIZE_DEVIATION      = auto()
    TIMING_DEVIATION    = auto()
    HEADER_CHANGE       = auto()
    CONTENT_CHANGE      = auto()
    WAF_TRIGGER         = auto()
    REDIRECT_CHANGE     = auto()


@dataclass
class Anomaly:
    type: AnomalyType
    description: str
    severity: float      # 0.0 → 1.0
    evidence: str = ""


@dataclass
class Baseline:
    """Profil statistique d'une cible sur N requêtes normales."""
    status_mode: int = 200
    size_mean: float = 0.0
    size_stdev: float = 0.0
    timing_mean: float = 0.0
    timing_stdev: float = 0.0
    common_headers: set[str] = field(default_factory=set)
    redirects_count: int = 0
    samples: int = 0
    # NOUVEAU: page dynamique détectée (taille varie fortement entre requêtes)
    is_dynamic: bool = False
    # NOUVEAU: ratio de variation de taille observé (pour ajuster les seuils)
    size_variation_ratio: float = 0.0

    def size_zscore(self, size: int) -> float:
        if self.size_stdev == 0:
            return 0.0
        return abs(size - self.size_mean) / self.size_stdev

    def timing_zscore(self, elapsed: float) -> float:
        if self.timing_stdev == 0:
            return 0.0
        return abs(elapsed - self.timing_mean) / self.timing_stdev


@dataclass
class HeuristicResult:
    url: str
    response: ProbeResponse
    anomalies: list[Anomaly] = field(default_factory=list)
    interesting: bool = False
    score: float = 0.0           # score agrégé d'intérêt
    confidence: int = 0          # NOUVEAU: 0-100, confiance dans le résultat


# ─────────────────────────── Heuristic Engine ───────────────────────────────

class HeuristicEngine:
    """
    Établit une baseline comportementale et évalue chaque réponse par rapport.
    Utilisé par tous les modules pour filtrer les faux positifs.
    """

    SIZE_ZSCORE_THRESHOLD        = 3.0    # fix v5.18-fp: 2.5 → 3.0 (2.5 génère ~1.2% FP sur distribution normale)
    SIZE_ZSCORE_DYNAMIC_THRESHOLD = 3.8   # fix v5.18-fp: 3.2 → 3.8 (pages dynamiques, marge plus large)
    TIMING_ZSCORE_THRESHOLD      = 3.0
    INTERESTING_STATUSES         = {200, 201, 204, 301, 302, 400, 401, 403, 405, 500, 502, 503}
    WAF_STATUSES                 = {403, 406, 429, 503}

    # NOUVEAU: patterns de contenu dynamique (timestamps, nonces, CSRF tokens…)
    _DYNAMIC_PATTERNS = [
        re.compile(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}'),  # ISO datetime
        re.compile(r'"nonce"\s*:\s*"[a-f0-9]{8,}"', re.I),
        re.compile(r'<meta\s+name=["\'"]csrf[^>]+content=["\'"][^"\'"]{16,}', re.I),
        re.compile(r'window\.__INITIAL_STATE__\s*='),
        re.compile(r'var\s+_token\s*=\s*["\'"][a-zA-Z0-9+/=]{20,}["\'"]'),
        re.compile(r'"requestId"\s*:\s*"[a-f0-9-]{32,}"', re.I),       # UUID trace IDs
        re.compile(r'<input[^>]+name=["\']?__RequestVerificationToken', re.I),  # ASP.NET AV token
        re.compile(r'window\.__cf_chl_opt\s*='),                        # Cloudflare challenge
        re.compile(r'"expires(?:_?[Ii]n|At)"\s*:\s*\d{10,}'),          # JWT exp fields
    ]

    # Patterns d'erreurs applicatives — indiquent potentiellement une vuln
    _ERROR_SIGNATURES: list[tuple[re.Pattern, str, float]] = [
        # SQL errors
        (re.compile(r"you have an error in your sql syntax", re.I),         "MySQL error",       0.9),
        (re.compile(r"warning: mysql_",                                      re.I),               "MySQL warning",     0.8),
        (re.compile(r"ORA-\d{5}:",                                           0),                  "Oracle SQL error",  0.9),
        (re.compile(r"pg_query\(\).*error",                                  re.I),               "PostgreSQL error",  0.9),
        (re.compile(r"Microsoft.*OLE DB.*SQL Server",                        re.I),               "MSSQL error",       0.9),
        (re.compile(r"SQLite\.Exception|sqlite3\.OperationalError",          re.I),               "SQLite error",      0.85),
        (re.compile(r"unclosed quotation mark after the character string",   re.I),               "MSSQL syntax",      0.9),
        (re.compile(r"quoted string not properly terminated",                re.I),               "Oracle syntax",     0.85),
        # Stack traces / path disclosure
        (re.compile(r"(?:Traceback \(most recent call last\)|File \"[^\"]+\", line \d+)", re.I), "Python traceback",  0.7),
        (re.compile(r"at [\w\.\$]+\([\w\.]+\.java:\d+\)",                    0),                  "Java stacktrace",   0.7),
        (re.compile(r"Fatal error:.*in /.+\.php on line \d+",                re.I),               "PHP fatal error",   0.75),
        (re.compile(r"Notice:.*in /.+\.php on line \d+",                     re.I),               "PHP notice",        0.4),
        (re.compile(r"undefined method|NoMethodError|NameError.*undefined",  re.I),               "Ruby error",        0.6),
        (re.compile(r"System\.(?:Null|Argument|Format)Exception",            re.I),               "ASP.NET exception", 0.7),
        # Template injection markers
        (re.compile(r"\{\{.*\}\}|\{%.*%\}",                                  0),                  "Template echo",     0.6),
        (re.compile(r"Jinja2\.exceptions\.|TemplateSyntaxError",             re.I),               "Jinja2 error",      0.85),
        (re.compile(r"Twig\\Error\\",                                         re.I),               "Twig error",        0.85),
        # LFI / path inclusion errors
        (re.compile(r"(?:include|require)(?:_once)?\s*\([^)]*\):\s*[Ff]ailed", re.I),           "PHP include error", 0.8),
        (re.compile(r"No such file or directory.*?(?:/etc/|C:\\)",           re.I),               "Path disclosure",   0.75),
        # XXE / deserialization
        (re.compile(r"XML\s+parsing\s+error|SAXParseException|DOMException", re.I),              "XML parse error",   0.7),
        (re.compile(r"java\.io\.(?:ObjectInputStream|InvalidClassException)", re.I),              "Java deserial",     0.8),
    ]

    def __init__(self, requester: Requester) -> None:
        self._req = requester
        self._baseline: Baseline | None = None
        self._fingerprint: Fingerprint | None = None
        # Soft-404 : liste de tailles mesurées (médiane sur 3 probes)
        self._soft404_sizes: list[int] = []
        self._soft404_status: int | None = None
        # NOUVEAU: jitter adaptatif si WAF détecté
        self._waf_backoff: float = 0.0
        # v5.7 — Baselines individuelles par endpoint (URL → Baseline)
        self._endpoint_baselines: dict[str, Baseline] = {}

    # ── Baseline ─────────────────────────────────────────────────────────────

    async def build_baseline(
        self,
        target: str,
        n: int = 5,
        fingerprint: Fingerprint | None = None,
    ) -> Baseline:
        """
        Envoie N requêtes sur la page racine séquentiellement.
        NOUVEAU: détecte les pages dynamiques via variance de taille + content-hash.
        """
        self._fingerprint = fingerprint

        # Jitter adaptatif : si WAF connu, on espace davantage les requêtes baseline
        if fingerprint and fingerprint.waf:
            self._waf_backoff = 0.5

        responses: list[ProbeResponse] = []
        for _ in range(n):
            if self._waf_backoff > 0:
                await asyncio.sleep(self._waf_backoff + random.uniform(0, 0.3))
            responses.append(await self._req.get(target))

        valid = [r for r in responses if r.error is None]
        if not valid:
            self._baseline = Baseline()
            return self._baseline

        sizes = [r.content_length for r in valid]
        timings = [r.elapsed_ms for r in valid]
        statuses = [r.status for r in valid]
        status_mode = max(set(statuses), key=statuses.count)

        common_hdrs = set(valid[0].headers.keys())
        for r in valid[1:]:
            common_hdrs &= set(r.headers.keys())

        redirects = sum(1 for r in valid if r.redirects)

        size_mean = statistics.mean(sizes)
        size_stdev = statistics.stdev(sizes) if len(sizes) > 1 else 0.0

        # NOUVEAU: détection page dynamique
        # Critère 1 : variation de taille relative > 3% sur les N requêtes
        size_variation_ratio = (size_stdev / size_mean) if size_mean > 0 else 0.0
        is_dynamic_size = size_variation_ratio > 0.08

        # Critère 2 : présence de patterns dynamiques dans le body
        is_dynamic_content = any(
            any(pat.search(r.body[:4096]) for pat in self._DYNAMIC_PATTERNS)
            for r in valid
        )

        is_dynamic = is_dynamic_size or is_dynamic_content

        self._baseline = Baseline(
            status_mode=status_mode,
            size_mean=size_mean,
            size_stdev=size_stdev,
            timing_mean=statistics.mean(timings),
            timing_stdev=statistics.stdev(timings) if len(timings) > 1 else 0.0,
            common_headers=common_hdrs,
            redirects_count=redirects,
            samples=len(valid),
            is_dynamic=is_dynamic,
            size_variation_ratio=size_variation_ratio,
        )
        return self._baseline

    async def build_endpoint_baselines(
        self,
        urls: list[str],
        n: int = 3,  # fix v5.10.1: 5 → 3 (5 trop lent sur gros crawl, ralentit les modules)
        concurrency: int = 10,
    ) -> None:
        """
        v5.7 — Phase passive : construit une baseline individuelle pour chaque
        endpoint découvert par le crawler.

        Chaque URL reçoit N requêtes normales (sans payload) pour établir son
        profil statistique (status normal, taille normale, timing normal).
        Les modules d'attaque comparent ensuite leurs réponses à CET endpoint
        spécifique — pas à la homepage globale.

        Args:
            urls: liste d'URLs à pré-profiler (typiquement le snapshot du bus)
            n: nombre de requêtes par endpoint (3 suffit pour un profil fiable)
            concurrency: semaphore pour ne pas saturer la cible
        """
        if not urls:
            return

        sem = asyncio.Semaphore(concurrency)

        async def _profile_one(url: str) -> None:
            async with sem:
                # v5.11 — Jitter réduit pour les baselines passives : 25% du waf_backoff global.
                # Les baselines ne génèrent pas de payloads suspects, un jitter minimal suffit.
                baseline_jitter = self._waf_backoff * 0.25 if self._waf_backoff > 0 else 0.0
                if baseline_jitter > 0:
                    await asyncio.sleep(baseline_jitter + random.uniform(0, baseline_jitter * 0.3))
                responses: list[ProbeResponse] = []
                for _ in range(n):
                    try:
                        resp = await self._req.get(url)
                        if resp.error is None:
                            responses.append(resp)
                    except Exception:
                        pass
                    if baseline_jitter > 0:
                        await asyncio.sleep(baseline_jitter)

                if not responses:
                    return

                sizes = [r.content_length for r in responses]
                timings = [r.elapsed_ms for r in responses]
                statuses = [r.status for r in responses]
                status_mode = max(set(statuses), key=statuses.count)
                common_hdrs = set(responses[0].headers.keys())
                for r in responses[1:]:
                    common_hdrs &= set(r.headers.keys())
                redirects = sum(1 for r in responses if r.redirects)

                size_mean = statistics.mean(sizes)
                size_stdev = statistics.stdev(sizes) if len(sizes) > 1 else 0.0
                size_variation_ratio = (size_stdev / size_mean) if size_mean > 0 else 0.0
                is_dynamic_size = size_variation_ratio > 0.08
                is_dynamic_content = any(
                    any(pat.search(r.body[:4096]) for pat in self._DYNAMIC_PATTERNS)
                    for r in responses
                )

                self._endpoint_baselines[url] = Baseline(
                    status_mode=status_mode,
                    size_mean=size_mean,
                    size_stdev=size_stdev,
                    timing_mean=statistics.mean(timings),
                    timing_stdev=statistics.stdev(timings) if len(timings) > 1 else 0.0,
                    common_headers=common_hdrs,
                    redirects_count=redirects,
                    samples=len(responses),
                    is_dynamic=is_dynamic_size or is_dynamic_content,
                    size_variation_ratio=size_variation_ratio,
                )

        tasks = [asyncio.create_task(_profile_one(u)) for u in urls]
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    def get_baseline_for(self, url: str) -> Baseline | None:
        """
        v5.7 — Retourne la baseline spécifique à l'URL si disponible,
        sinon la baseline globale (homepage). Les modules d'attaque doivent
        appeler cette méthode plutôt que d'utiliser self._heur.baseline.
        """
        # Chercher une baseline exacte ou par chemin parent
        if url in self._endpoint_baselines:
            return self._endpoint_baselines[url]
        # Fallback : baseline globale
        return self._baseline

    async def probe_soft404(self, target: str) -> None:
        """
        AMÉLIORÉ: Triple probe sur 3 slugs aléatoires différents.
        La taille de référence soft-404 est la médiane des 3 → beaucoup plus robuste
        sur les serveurs dont les pages d'erreur ont une légère variation de taille
        (ex: timestamp embarqué dans la 404).
        """
        from urllib.parse import urlparse
        p = urlparse(target)
        sizes: list[int] = []
        statuses: list[int] = []

        for _ in range(3):  # fix v5.10.1: 5 → 3 probes (5 ralentit le démarrage inutilement)
            rand_slug = ''.join(random.choices(string.ascii_lowercase + string.digits, k=22))
            test_url = f"{p.scheme}://{p.netloc}/{rand_slug}"
            if self._waf_backoff > 0:
                await asyncio.sleep(self._waf_backoff)
            resp = await self._req.get(test_url)
            if resp.error is None:
                sizes.append(resp.content_length)
                statuses.append(resp.status)

        if sizes:
            self._soft404_sizes = sizes
            # Status mode parmi les 3 probes
            self._soft404_status = max(set(statuses), key=statuses.count)

    # ── Analyse ──────────────────────────────────────────────────────────────

    def analyze(self, resp: ProbeResponse, context: str = "") -> HeuristicResult:
        """Analyse une réponse par rapport à la baseline de l'endpoint (v5.7) ou globale."""
        result = HeuristicResult(url=resp.url, response=resp)

        # v5.7 — préférer la baseline spécifique à l'URL testée
        bl = self.get_baseline_for(resp.url) or self._baseline
        if bl is None:
            result.interesting = True
            result.confidence = 30
            return result

        anomalies: list[Anomaly] = []

        # Seuil de taille adaptatif selon dynamisme de la page
        size_threshold = (
            self.SIZE_ZSCORE_DYNAMIC_THRESHOLD if bl.is_dynamic
            else self.SIZE_ZSCORE_THRESHOLD
        )

        # 1. Status deviation
        if resp.status != bl.status_mode:
            sev = self._status_severity(resp.status, bl.status_mode)
            if sev > 0:
                anomalies.append(Anomaly(
                    type=AnomalyType.STATUS_DEVIATION,
                    description=f"Status {resp.status} vs baseline {bl.status_mode}",
                    severity=sev,
                    evidence=f"URL: {resp.url}",
                ))

        # 2. Size deviation (seuil dynamique)
        z_size = bl.size_zscore(resp.content_length)
        if z_size > size_threshold:
            anomalies.append(Anomaly(
                type=AnomalyType.SIZE_DEVIATION,
                description=(
                    f"Taille {resp.content_length}B vs baseline {bl.size_mean:.0f}B "
                    f"(z={z_size:.1f}, {'dynamic page' if bl.is_dynamic else 'static page'})"
                ),
                severity=min(1.0, z_size / 10),
                evidence=context,
            ))

        # 3. Timing deviation
        z_time = bl.timing_zscore(resp.elapsed_ms)
        if z_time > self.TIMING_ZSCORE_THRESHOLD:
            anomalies.append(Anomaly(
                type=AnomalyType.TIMING_DEVIATION,
                description=f"Timing {resp.elapsed_ms:.0f}ms vs baseline {bl.timing_mean:.0f}ms (z={z_time:.1f})",
                severity=min(1.0, z_time / 15),
                evidence=context,
            ))

        # 4. Nouveaux headers suspects
        new_headers = set(resp.headers.keys()) - bl.common_headers
        for h in new_headers:
            if any(sus in h.lower() for sus in ["x-injected", "set-cookie", "location", "content-disposition"]):
                anomalies.append(Anomaly(
                    type=AnomalyType.HEADER_CHANGE,
                    description=f"Nouveau header suspect: {h}: {resp.headers[h][:80]}",
                    severity=0.6,
                    evidence=context,
                ))

        # 5. WAF trigger
        if resp.status in self.WAF_STATUSES and resp.status != bl.status_mode:
            anomalies.append(Anomaly(
                type=AnomalyType.WAF_TRIGGER,
                description=f"WAF probable (status {resp.status})",
                severity=0.3,
                evidence=context,
            ))

        # 6. Redirect change
        if resp.redirects and bl.redirects_count == 0:
            anomalies.append(Anomaly(
                type=AnomalyType.REDIRECT_CHANGE,
                description=f"Redirection inattendue vers {resp.redirects[-1]}",
                severity=0.5,
                evidence=context,
            ))

        result.anomalies = anomalies
        result.score = sum(a.severity for a in anomalies)
        # fix v5.18-fp: seuils resserrés — v5.10.1 était trop permissif (score>0.3 = tout trigger)
        # Un WAF_TRIGGER (0.3) ou un status catch-all (0.2) seuls ne suffisent plus.
        result.interesting = result.score > 0.5 or any(
            a.type == AnomalyType.STATUS_DEVIATION and a.severity >= 0.6
            for a in anomalies
        ) or (
            any(a.type == AnomalyType.SIZE_DEVIATION for a in anomalies)
            and result.score > 0.45
        )
        # NOUVEAU: score de confiance basé sur le nombre d'anomalies et leur sévérité
        result.confidence = min(100, int(result.score * 50 + len(anomalies) * 10))
        return result

    # ── Helpers ───────────────────────────────────────────────────────────────

    def has_tech(self, tech: str) -> bool:
        """
        Vérifie si une technologie a été détectée lors du fingerprinting.
        Comparaison case-insensitive sur le nom partiel.
        Ex: has_tech("PHP") → True si "PHP" est dans technologies ou CMS PHP-based.
        """
        if self._fingerprint is None:
            return False
        tech_lower = tech.lower()
        for t in self._fingerprint.technologies:
            if tech_lower in t.lower():
                return True
        # CMS PHP-based : WordPress, Joomla, Drupal, Magento
        if tech_lower == "php" and self._fingerprint.cms in ("WordPress", "Joomla", "Drupal", "Magento"):
            return True
        return False

    def is_real_hit(self, resp: ProbeResponse, min_confidence: int = 50) -> bool:
        """
        Filtre les faux positifs.
        v5.7  — utilise la baseline spécifique à l'endpoint si disponible.
        v5.18 — min_confidence relevé 0→30.
        v5.20 — min_confidence relevé 30→50 ; amélioration soft-404 :
                on élimine aussi les réponses dont la taille normalisée
                tombe dans le cluster soft-404 même si le status est 200.
        """
        if resp.status in (404, 410, 400, 422):
            return False

        # v5.20 — Soft-404 amélioré : cluster de tailles + heuristique body
        if resp.status == 200 and self._soft404_sizes:
            median_size = sorted(self._soft404_sizes)[len(self._soft404_sizes) // 2]
            if median_size > 0:
                if median_size < 2000:
                    tolerance = max(150, int(median_size * 0.10))
                elif median_size < 20000:
                    tolerance = max(300, int(median_size * 0.06))
                else:
                    tolerance = max(800, int(median_size * 0.04))
                if abs(resp.content_length - median_size) <= tolerance:
                    return False

        # v5.20 — Détection soft-404 par body : pages génériques "not found"
        if resp.status == 200 and resp.body:
            body_low = resp.body[:500].lower()
            soft404_phrases = (
                "page not found", "404 not found", "doesn't exist",
                "no longer available", "nothing here", "this page does not exist",
            )
            if any(p in body_low for p in soft404_phrases):
                return False

        if min_confidence > 0:
            result = self.analyze(resp)
            if result.confidence < min_confidence:
                return False

        return True

    def content_hash(self, body: str) -> str:
        """NOUVEAU: Hash MD5 du body normalisé (sans valeurs dynamiques)."""
        # Supprime les valeurs qui changent à chaque requête avant de hasher
        normalized = re.sub(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[^\s"\'<]*', 'TS', body)
        normalized = re.sub(r'(?:nonce|token|_token|csrf)["\s:=]+["\']?[a-zA-Z0-9+/=]{16,}["\']?',
                            'TOK', normalized, flags=re.I)
        return hashlib.md5(normalized.encode("utf-8", errors="replace")).hexdigest()

    def _status_severity(self, status: int, baseline: int) -> float:
        if baseline == 200 and status == 403:
            return 0.7
        if baseline == 200 and status == 401:
            return 0.7
        if baseline == 404 and status == 200:
            return 0.9
        if baseline == 404 and status == 403:
            return 0.6
        if status == 500:
            return 0.8
        if status == 200 and baseline != 200:
            return 0.8
        # fix v5.18-fp: catch-all réduit 0.3→0.2 et exclut les redirections/réponses
        # conditionnelles légitimes (301/302/304/206) qui ne sont pas des anomalies réelles.
        if status not in (301, 302, 304, 206) and status != baseline:
            return 0.2
        return 0.0

    def body_similarity(self, body_a: str, body_b: str) -> float:
        """
        Retourne un ratio 0.0→1.0 de similarité entre deux bodies.
        v5.9-intel — utilise difflib.SequenceMatcher pour une comparaison
        structurelle réelle, plus précise que le ratio de taille seul.

        Utile pour les modules boolean-based (SQLi, LFI, CSRF probe) qui
        doivent distinguer deux réponses quasi-identiques.

        Optimisation : tronquement à 8192 chars pour éviter des comparaisons
        O(n²) sur des pages volumineuses.
        """
        import difflib
        if len(body_a) == 0 and len(body_b) == 0:
            return 1.0
        if len(body_a) == 0 or len(body_b) == 0:
            return 0.0
        # Tronquer pour limiter le coût CPU sur les grosses pages
        a = body_a[:8192]
        b = body_b[:8192]
        # Normaliser les valeurs dynamiques avant comparaison
        if self.content_hash(a) == self.content_hash(b):
            return 1.0
        # SequenceMatcher : ratio structurel réel
        return difflib.SequenceMatcher(None, a, b, autojunk=True).ratio()

    def detect_error_signatures(self, body: str) -> list[tuple[str, float]]:
        """
        v5.9-intel — Détecte les signatures d'erreurs applicatives dans le body
        d'une réponse (erreurs SQL, stack traces, path disclosure, erreurs de
        template, etc.).

        Returns:
            liste de (description, severity) pour chaque signature détectée.
            Ex: [("MySQL error", 0.9), ("PHP notice", 0.4)]

        Utilisé par les modules SQLi / SSTI / LFI pour valider les hits
        error-based sans heuristique de taille fragile.
        """
        hits: list[tuple[str, float]] = []
        # Limiter la recherche aux 16 Ko du body pour la perf
        sample = body[:16384]
        for pattern, description, severity in self._ERROR_SIGNATURES:
            if pattern.search(sample):
                hits.append((description, severity))
        return hits

    @property
    def baseline(self) -> Baseline | None:
        return self._baseline

    @property
    def fingerprint(self) -> Fingerprint | None:
        return self._fingerprint

    @property
    def waf_backoff(self) -> float:
        return self._waf_backoff


# ─────────────────────────── TimingOracle ───────────────────────────────────

class TimingOracle:
    """
    v5.17 — Oracle de timing amélioré pour les attaques blind/time-based.

    Problèmes résolus par rapport au timing heuristic basique :
      1. Variance réseau — une seule mesure est non fiable. Le TimingOracle
         prend N mesures de référence et N mesures sous payload, puis applique
         un test statistique (Welch's t-test simplifié) pour décider si le
         délai est significativement différent.
      2. Jitter adaptatif — si la variance réseau est haute (serveur lent/flaky),
         le seuil de détection s'ajuste automatiquement vers le haut.
      3. Normalisation par baseline — le délai SLEEP(5) n'est significatif que
         si le delta par rapport à la baseline dépasse le seuil calibré.
      4. Multi-probe — supporte les délais courts (SLEEP(1)) répétés pour
         distinguer le bruit réseau d'un vrai sleep.

    Usage dans un module time-based (SQLi, CMDi, SSTI) :
        oracle = TimingOracle(heuristic)
        # Calibrer sur ce endpoint spécifique
        await oracle.calibrate(req, url, params={"id": "1"}, n=3)
        # Tester un payload time-based
        result = await oracle.probe(
            req, url,
            params={"id": "1 AND SLEEP(5)--"},
            expected_delay=5.0
        )
        if result.is_delay_confirmed:
            # Vuln time-based confirmée
            print(f"Délai: {result.measured_delay:.1f}s (confiance: {result.confidence}%)")
    """

    # Seuil minimum de délai absolu pour éviter les faux positifs réseaux
    MIN_ABSOLUTE_DELAY = 3.5  # secondes

    # Ratio : délai mesuré / baseline_mean pour confirmer
    MIN_DELAY_RATIO = 2.5

    @dataclass
    class ProbeResult:
        is_delay_confirmed: bool
        measured_delay: float      # délai moyen mesuré sous payload (secondes)
        baseline_mean: float       # délai moyen de référence (secondes)
        delta: float               # measured_delay - baseline_mean
        confidence: int            # 0–100
        reason: str

    def __init__(self, heuristic: "HeuristicEngine") -> None:
        self._heuristic = heuristic
        self._calibrated_baselines: dict[str, tuple[float, float]] = {}
        # url → (mean_ms, stdev_ms)

    async def calibrate(
        self,
        requester: "Requester",
        url: str,
        params: dict | None = None,
        n: int = 3,
        method: str = "GET",
    ) -> tuple[float, float]:
        """
        Envoie N requêtes normales sur l'endpoint et calcule mean/stdev du timing.

        Returns: (mean_seconds, stdev_seconds)
        """
        timings: list[float] = []
        for _ in range(n):
            if method.upper() == "POST":
                resp = await requester.post(url, data=params or {})
            else:
                resp = await requester.get(url, params=params)
            if resp.error is None:
                timings.append(resp.elapsed_ms / 1000.0)

        if not timings:
            mean, stdev = 0.5, 0.1
        elif len(timings) == 1:
            mean, stdev = timings[0], 0.2
        else:
            mean = statistics.mean(timings)
            stdev = statistics.stdev(timings)

        self._calibrated_baselines[url] = (mean, stdev)
        return mean, stdev

    async def probe(
        self,
        requester: "Requester",
        url: str,
        params: dict | None = None,
        expected_delay: float = 5.0,
        n_probes: int = 2,
        method: str = "GET",
    ) -> "TimingOracle.ProbeResult":
        """
        Envoie n_probes requêtes avec le payload time-based et analyse le timing.

        Args:
            requester:      instance Requester configurée
            url:            URL à tester
            params:         paramètres incluant le payload time-based
            expected_delay: délai attendu injecté (ex: 5.0 pour SLEEP(5))
            n_probes:       nombre de mesures sous payload (min 2 pour fiabilité)
            method:         GET | POST

        Returns:
            ProbeResult avec is_delay_confirmed et confidence
        """
        # Récupérer la baseline calibrée pour cet endpoint
        baseline_mean, baseline_stdev = self._calibrated_baselines.get(url, (0.5, 0.2))

        # Si pas de calibration spécifique, essayer la baseline globale
        if url not in self._calibrated_baselines:
            bl = self._heuristic.get_baseline_for(url) or self._heuristic.baseline
            if bl:
                baseline_mean = bl.timing_mean / 1000.0
                baseline_stdev = bl.timing_stdev / 1000.0

        # Seuil adaptatif : si la variance réseau est haute, exiger plus de délai
        # stdev élevée → seuil plus haut pour éviter les faux positifs
        adaptive_threshold = max(
            self.MIN_ABSOLUTE_DELAY,
            baseline_mean + max(expected_delay * 0.6, baseline_stdev * 4)
        )

        # Envoyer les probes sous payload
        probe_timings: list[float] = []
        for _ in range(n_probes):
            if method.upper() == "POST":
                resp = await requester.post(url, data=params or {})
            else:
                resp = await requester.get(url, params=params)
            if resp.error is None:
                probe_timings.append(resp.elapsed_ms / 1000.0)

        if not probe_timings:
            return self.ProbeResult(
                is_delay_confirmed=False,
                measured_delay=0.0,
                baseline_mean=baseline_mean,
                delta=0.0,
                confidence=0,
                reason="Requête échouée (erreur réseau ou timeout)",
            )

        measured_delay = statistics.mean(probe_timings)
        delta = measured_delay - baseline_mean

        # Score de confiance multi-critères
        confidence = 0
        reasons: list[str] = []

        # Critère 1 : délai absolu significatif
        if measured_delay >= self.MIN_ABSOLUTE_DELAY:
            confidence += 30
            reasons.append(f"Délai absolu {measured_delay:.1f}s ≥ seuil {self.MIN_ABSOLUTE_DELAY}s")

        # Critère 2 : ratio par rapport à la baseline
        if baseline_mean > 0:
            ratio = measured_delay / baseline_mean
            if ratio >= self.MIN_DELAY_RATIO:
                confidence += 35
                reasons.append(f"Ratio {ratio:.1f}x la baseline ({baseline_mean:.2f}s)")

        # Critère 3 : delta absolu par rapport au délai attendu
        if delta >= expected_delay * 0.7:
            confidence += 25
            reasons.append(f"Delta {delta:.1f}s ≈ expected_delay {expected_delay:.1f}s")

        # Critère 4 : cohérence multi-probes (tous au-dessus du seuil)
        if n_probes >= 2 and all(t >= adaptive_threshold for t in probe_timings):
            confidence += 10
            reasons.append(f"Délai cohérent sur {n_probes} probes")

        # Critère 5 : bruit réseau faible (variance des probes)
        if n_probes >= 2 and len(probe_timings) >= 2:
            probe_stdev = statistics.stdev(probe_timings)
            if probe_stdev < expected_delay * 0.3:
                confidence += 5
                reasons.append(f"Variance faible ({probe_stdev:.2f}s)")

        confidence = min(100, confidence)
        is_confirmed = confidence >= 60 and measured_delay >= adaptive_threshold

        return self.ProbeResult(
            is_delay_confirmed=is_confirmed,
            measured_delay=measured_delay,
            baseline_mean=baseline_mean,
            delta=delta,
            confidence=confidence,
            reason=" | ".join(reasons) if reasons else f"Délai {measured_delay:.1f}s, seuil {adaptive_threshold:.1f}s",
        )

    def get_sleep_payloads(
        self,
        delay: int = 5,
        db_type: str | None = None,
    ) -> list[tuple[str, str]]:
        """
        Retourne des payloads time-based pour différents moteurs DB.

        Args:
            delay:    délai en secondes à injecter
            db_type:  "mysql" | "postgres" | "mssql" | "oracle" | None (tous)

        Returns:
            liste de (payload, db_name)
        """
        all_payloads = [
            (f"' AND SLEEP({delay})--",                          "mysql"),
            (f"' AND SLEEP({delay}) AND '1'='1",                 "mysql"),
            (f"1; SELECT SLEEP({delay})--",                      "mysql"),
            (f"' AND pg_sleep({delay})--",                       "postgres"),
            (f"'; SELECT pg_sleep({delay})--",                   "postgres"),
            (f"1 AND 1=(SELECT 1 FROM pg_sleep({delay}))",       "postgres"),
            (f"'; WAITFOR DELAY '0:0:{delay}'--",                "mssql"),
            (f"1; WAITFOR DELAY '0:0:{delay}'--",                "mssql"),
            (f"' OR SLEEP({delay})--",                           "mysql"),
            (f"1 AND (SELECT * FROM (SELECT(SLEEP({delay})))a)", "mysql"),
            (f"' AND (SELECT 1337 FROM (SELECT(SLEEP({delay})))x)--", "mysql"),
        ]
        if db_type:
            return [(p, db) for p, db in all_payloads if db == db_type.lower()]
        return all_payloads




# ─────────────────────────── ResponseDiffAnalyzer ───────────────────────────

class ResponseDiffAnalyzer:
    """
    v5.11 — Comparaison sémantique entre deux réponses HTTP pour les modules
    boolean-based (SQLi blind, LFI conditional, CSRF probe, IDOR, etc.).

    Va bien au-delà du simple delta de taille :
      - Diff JSON récursif avec normalisation des champs volatils
      - Détection de nouveaux champs JSON dans la réponse altérée
      - Diff HTML structural (nombre de balises, présence de blocs clés)
      - Détection de secrets/tokens dans la réponse altérée absents de la baseline
      - Score de confiance 0–100 pour chaque diff

    Usage :
        analyzer = ResponseDiffAnalyzer(heuristic_engine)
        diff = analyzer.diff(baseline_resp, probed_resp, context="sqli blind")
        if diff.is_significant:
            # Finding confirmé
    """

    # Patterns de données sensibles dans la réponse altérée
    _SENSITIVE_PATTERNS: list[tuple[re.Pattern, str, float]] = [
        (re.compile(r'"(?:password|passwd|pwd|secret|token|api_?key|access_?key)"\\s*:\\s*"[^"]{4,}"', re.I), "Champ sensible exposé", 0.95),
        (re.compile(r'[a-f0-9]{32,}', re.I), "Hash/token hexadécimal", 0.5),
        (re.compile(r'eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}', re.I), "JWT exposé", 0.9),
        (re.compile(r'(?:BEGIN (?:RSA |EC )?PRIVATE KEY|PRIVATE KEY-----)', re.I), "Clé privée", 1.0),
        (re.compile(r'(?:aws_access_key_id|AKIA)[A-Z0-9]{16}', re.I), "AWS key", 1.0),
        (re.compile(r'"email"\s*:\s*"[^@"]+@[^".]+"', re.I), "Email exposé", 0.7),
        (re.compile(r'"(?:ssn|social_security|credit_card|card_number)"\s*:', re.I), "PII sensible", 0.95),
        (re.compile(r'/(?:etc/passwd|proc/self|windows/system32)', re.I), "Path disclosure LFI", 0.9),
        (re.compile(r'root:x:0:0:|daemon:x:', re.I), "Contenu /etc/passwd", 1.0),
    ]

    # Champs JSON volatils à ignorer lors du diff
    _VOLATILE_FIELDS: frozenset[str] = frozenset({
        "timestamp", "ts", "nonce", "request_id", "trace_id", "correlation_id",
        "created_at", "updated_at", "expires_at", "issued_at", "last_seen",
        "session_id", "csrf_token", "_token", "x-request-id",
    })

    @dataclass
    class DiffResult:
        is_significant: bool
        confidence: int          # 0–100
        reason: str              # description lisible du diff
        new_fields: list[str]    # champs JSON nouveaux dans la réponse altérée
        sensitive_hits: list[tuple[str, float]]  # (description, severity)
        size_delta: int          # delta en octets
        status_changed: bool

    def __init__(self, heuristic: "HeuristicEngine") -> None:
        self._heuristic = heuristic

    def diff(
        self,
        baseline: "ProbeResponse",
        probed: "ProbeResponse",
        context: str = "",
    ) -> "ResponseDiffAnalyzer.DiffResult":
        """
        Compare semantiquement baseline et probed.
        Retourne un DiffResult avec score de confiance et raisons.
        """
        reasons: list[str] = []
        confidence = 0
        new_fields: list[str] = []
        sensitive_hits: list[tuple[str, float]] = []
        size_delta = probed.content_length - baseline.content_length
        status_changed = probed.status != baseline.status

        # 1. Status change
        if status_changed:
            if probed.status in (200, 201) and baseline.status in (401, 403, 404):
                reasons.append(f"Status {baseline.status}→{probed.status} (accès obtenu)")
                confidence += 40
            elif probed.status == 500 and baseline.status != 500:
                reasons.append(f"Status {baseline.status}→500 (erreur serveur interne)")
                confidence += 35
            else:
                reasons.append(f"Status {baseline.status}→{probed.status}")
                confidence += 20

        # 2. JSON diff récursif
        json_diff = self._json_diff(baseline.body, probed.body)
        if json_diff["new_fields"]:
            new_fields = json_diff["new_fields"]
            reasons.append(f"Nouveaux champs JSON: {', '.join(new_fields[:5])}")
            confidence += min(35, len(new_fields) * 8)
        if json_diff["value_changes"] > 0:
            reasons.append(f"{json_diff['value_changes']} valeur(s) changée(s) dans le JSON")
            confidence += min(25, json_diff["value_changes"] * 6)
        if json_diff["array_length_diff"] != 0:
            delta = json_diff["array_length_diff"]
            reasons.append(f"Tableau JSON: {'+' if delta > 0 else ''}{delta} élément(s)")
            confidence += 20 if abs(delta) > 0 else 0

        # 3. Données sensibles dans la réponse altérée (absentes de baseline)
        sensitive_hits = self._find_new_sensitive(baseline.body, probed.body)
        for desc, sev in sensitive_hits:
            reasons.append(f"Donnée sensible: {desc}")
            confidence += int(sev * 45)

        # 4. Diff HTML structural
        if not json_diff["is_json"] and "<" in probed.body:
            html_diff = self._html_structural_diff(baseline.body, probed.body)
            if html_diff["significant"]:
                reasons.append(html_diff["reason"])
                confidence += html_diff["confidence_bonus"]

        # 5. Taille — uniquement en signal secondaire si pas d'autre diff
        if not reasons and abs(size_delta) > 200:
            bl = self._heuristic.get_baseline_for(baseline.url) or self._heuristic.baseline
            if bl:
                z = bl.size_zscore(probed.content_length)
                if z > (self._heuristic.SIZE_ZSCORE_DYNAMIC_THRESHOLD if bl.is_dynamic else self._heuristic.SIZE_ZSCORE_THRESHOLD):
                    reasons.append(f"Taille anormale ({'+' if size_delta > 0 else ''}{size_delta}B, z={z:.1f})")
                    confidence += min(20, int(z * 4))

        # 6. body_similarity fallback
        if not reasons:
            sim = self._heuristic.body_similarity(baseline.body, probed.body)
            if sim < 0.6:
                reasons.append(f"Corps très différent (similarité={sim:.2f})")
                confidence += int((1 - sim) * 30)

        confidence = min(100, confidence)
        is_significant = confidence >= 35 or bool(sensitive_hits)

        return self.DiffResult(
            is_significant=is_significant,
            confidence=confidence,
            reason=" | ".join(reasons) if reasons else "Pas de diff significatif",
            new_fields=new_fields,
            sensitive_hits=sensitive_hits,
            size_delta=size_delta,
            status_changed=status_changed,
        )

    def _json_diff(self, body_a: str, body_b: str) -> dict:
        """Diff récursif JSON, ignore les champs volatils."""
        result = {
            "is_json": False,
            "new_fields": [],
            "value_changes": 0,
            "array_length_diff": 0,
        }
        try:
            ja = json.loads(body_a)
            jb = json.loads(body_b)
            result["is_json"] = True

            if isinstance(ja, dict) and isinstance(jb, dict):
                for key in jb:
                    if key.lower() in self._VOLATILE_FIELDS:
                        continue
                    if key not in ja:
                        result["new_fields"].append(key)
                    elif ja[key] != jb[key]:
                        result["value_changes"] += 1
            elif isinstance(ja, list) and isinstance(jb, list):
                result["array_length_diff"] = len(jb) - len(ja)
        except (json.JSONDecodeError, ValueError, TypeError):
            pass
        return result

    def _find_new_sensitive(self, baseline_body: str, probed_body: str) -> list[tuple[str, float]]:
        """Retourne les données sensibles présentes dans probed mais absentes de baseline."""
        hits = []
        for pattern, description, severity in self._SENSITIVE_PATTERNS:
            in_baseline = bool(pattern.search(baseline_body[:8192]))
            in_probed = bool(pattern.search(probed_body[:8192]))
            if in_probed and not in_baseline:
                hits.append((description, severity))
        return hits

    def _html_structural_diff(self, body_a: str, body_b: str) -> dict:
        """Analyse le diff HTML structural entre deux réponses."""
        result = {"significant": False, "reason": "", "confidence_bonus": 0}
        # Compter les balises importantes
        for tag in ["<form", "<table", "<script", "<input", "<article", "<section"]:
            ca = body_a.lower().count(tag)
            cb = body_b.lower().count(tag)
            if cb > ca + 1:
                result["significant"] = True
                result["reason"] = f"Nouveau(x) élément(s) `{tag.strip('<')}` dans la réponse ({ca}→{cb})"
                result["confidence_bonus"] = min(25, (cb - ca) * 8)
                break
        # Titre différent
        title_re = re.compile(r'<title[^>]*>([^<]{3,100})</title>', re.I)
        ta = title_re.search(body_a)
        tb = title_re.search(body_b)
        if ta and tb and ta.group(1).strip() != tb.group(1).strip():
            result["significant"] = True
            result["reason"] = f"Titre HTML changé: '{ta.group(1).strip()}'→'{tb.group(1).strip()}'"
            result["confidence_bonus"] = max(result["confidence_bonus"], 20)
        return result
