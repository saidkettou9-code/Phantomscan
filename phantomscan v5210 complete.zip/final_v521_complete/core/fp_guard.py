"""
PhantomScan — FPGuard v5.20 (False-Positive Guard)
====================================================
Moteur centralisé de réduction des faux positifs. Tous les modules l'utilisent
avant de yield un Finding.

Problèmes résolus
-----------------
1. Pas de re-probe : un délai réseau ponctuel → faux SQLi time-based
2. Pages dynamiques non normalisées : CSRF token change → faux IDOR boolean
3. Signatures trop courtes : "root" dans une page normale → faux LFI
4. Réponse stable non vérifiée : un endpoint qui varie naturellement de 15 %
   déclenche des faux boolean-based
5. Content-length comme seul signal de différence (insuffisant)

Architecture
------------
FPGuard expose 4 méthodes :

  await guard.re_probe(req, url, method, ...)
      → Rejoue la même requête, retourne la 2e réponse (ou None si erreur).
        Permet de confirmer que le hit n'est pas une anomalie transitoire.

  guard.normalize(body) → str
      → Supprime les valeurs dynamiques du body avant comparaison.
        Enlève : timestamps ISO8601, nonces/CSRF tokens, UUIDs v4 aléatoires,
        nombres qui changent (counters, prix, ids dans JSON).

  guard.stable_diff(body_a, body_b) → float  (0.0 = identique, 1.0 = totalement différent)
      → Calcule la différence APRÈS normalisation.
        Évite les faux positifs sur pages avec padding dynamique.

  guard.sig_entropy_ok(sig_match, body) → bool
      → Vérifie que la signature matchée a une entropie suffisante pour être
        significative. "root" dans 10 000 chars → FP probable. "root:x:0:0:" → OK.

Usage typique dans un scanner
-----------------------------
    guard = FPGuard(req)

    # Re-probe avant de conclure à un time-based
    resp2 = await guard.re_probe(req, fuzz_url)
    if resp2 is None or resp2.elapsed_ms < threshold_ms:
        continue  # confirmation échouée → FP

    # Comparer deux réponses IDOR sans se faire piéger par les tokens CSRF
    diff = guard.stable_diff(resp_orig.body, resp_alt.body)
    if diff < 0.15:
        continue  # trop similaires après normalisation → pas un IDOR

    # Vérifier une signature LFI/CMDi
    if not guard.sig_entropy_ok(match.group(0), resp.body):
        continue  # signature trop courte/générique → FP probable
"""

from __future__ import annotations

import asyncio
import hashlib
import math
import re
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from phantomscan.core.requester import Requester, ProbeResponse


# ── Patterns de normalisation ──────────────────────────────────────────────────
# Chaque pattern est remplacé par un token fixe pour rendre les comparaisons
# stables entre deux requêtes successives sur une page dynamique.

_NORM_RULES: list[tuple[re.Pattern, str]] = [
    # Timestamps ISO-8601 : 2024-01-15T10:30:00Z ou 2024-01-15 10:30:00+00:00
    (re.compile(
        r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?',
        re.I,
    ), "<<TS>>"),
    # Dates simples DD/MM/YYYY ou MM-DD-YYYY
    (re.compile(r'\b(?:\d{1,2}[/-]){2}\d{2,4}\b'), "<<DATE>>"),
    # Tous les entiers >= 7 chiffres → un seul token unifié
    # (timestamps unix, IDs, prix, compteurs, numéros de version)
    # On préserve les courts (< 7 chiffres) : uid=0, gid=0, port 8080, etc.
    (re.compile(r'\b\d{7,}\b'), "<<NUMID>>"),
    # Dates YYYY-MM-DD seules (sans heure)
    (re.compile(r'\b\d{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\d|3[01])\b'), "<<DATE>>"),
    # UUIDs v4 (complètement aléatoires)
    (re.compile(
        r'[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}',
        re.I,
    ), "<<UUID>>"),
    # Tokens CSRF / nonces : attributs HTML ou JSON (valeurs ≥ 8 chars)
    # Couvre : csrfToken, csrf_token, _token, xsrfToken, nonce, authenticity_token
    (re.compile(
        r'(?:csrf|nonce|xsrf|\b_token\b|authenticity.token|verif\w*token)'
        r'["\'\']?[\w-]*[=:\ ]+["\'\']?([A-Za-z0-9+/=_\-]{8,128})["\'\']?',
        re.I,
    ), "<<TOKEN_VALUE>>"),
    # Authorization Bearer tokens
    (re.compile(r'Bearer\s+[A-Za-z0-9._\-]{20,}', re.I), "Bearer <<TOKEN>>"),
    # Strings hex longues (ETag, hash de build, checksums)
    (re.compile(r'"[0-9a-f]{16,64}"', re.I), '"<<HEXHASH>>"'),
    # Grands nombres dans JSON (compteurs, prix, IDs > 6 chiffres)
    (re.compile(r'(?<=[":,\[])\s*\d{7,}(?=[\s,\]\}\n])'), " <<BIGNUM>>"),
    # Commentaires HTML (build IDs, analytics, etc.)
    (re.compile(r'<!--.*?-->', re.S), "<!--X-->"),
    # User-agent strings
    (re.compile(
        r'Mozilla/5\.0\s*\([^)]{5,150}\)\s*[A-Za-z][^\n"\' <]{0,200}',
    ), "<<UA>>"),
]


def normalize_body(body: str, max_len: int = 32768) -> str:
    """
    Normalise un body HTTP en remplaçant les valeurs dynamiques par des tokens.
    Réduit la sensibilité aux changements non-sécuritaires entre deux requêtes.
    """
    # Tronquer pour éviter les comparaisons O(n²) sur des pages très longues
    text = body[:max_len]
    for pattern, replacement in _NORM_RULES:
        text = pattern.sub(replacement, text)
    return text


# ── Différence stable ───────────────────────────────────────────────────────────

def stable_diff(body_a: str, body_b: str) -> float:
    """
    Retourne un score de différence entre 0.0 (identique) et 1.0 (totalement différent),
    calculé APRÈS normalisation des valeurs dynamiques.

    Combine :
    - Différence de taille relative (25 % du poids)
    - Distance Jaccard sur trigrammes normalisés (75 % du poids)

    Seuils recommandés par type de test :
      IDOR           : diff > 0.20 pour conclure à un accès différent
      Boolean SQLi   : diff_true vs baseline < 0.05  ET  diff_false > 0.25
      Cache poison   : diff > 0.30 pour conclure à une réponse corrompue
    """
    na = normalize_body(body_a)
    nb = normalize_body(body_b)

    # Différence de taille
    len_a, len_b = len(na), len(nb)
    if len_a == 0 and len_b == 0:
        return 0.0
    size_diff = abs(len_a - len_b) / max(len_a, len_b, 1)

    # Jaccard sur trigrammes
    window = 6000
    ta = na[:window]
    tb = nb[:window]
    trig_a = {ta[i:i+3] for i in range(len(ta) - 2)}
    trig_b = {tb[i:i+3] for i in range(len(tb) - 2)}
    if not trig_a and not trig_b:
        return 0.0
    union = len(trig_a | trig_b)
    inter = len(trig_a & trig_b)
    jaccard_diff = 1.0 - (inter / union if union else 0.0)

    return 0.25 * size_diff + 0.75 * jaccard_diff


# ── Entropie de signature ───────────────────────────────────────────────────────

# Mots trop génériques pour être des indicateurs fiables de vulnérabilités
_GENERIC_WORDS: frozenset[str] = frozenset({
    "root", "admin", "user", "password", "passwd", "secret", "token",
    "error", "warning", "debug", "info", "true", "false", "null", "none",
    "success", "failed", "ok", "yes", "no", "get", "post", "put",
    "id", "name", "type", "data", "value", "key", "host", "path",
})


def sig_entropy_ok(match_text: str, full_body: str, min_entropy: float = 2.0) -> bool:
    """
    Vérifie qu'une signature matchée est suffisamment spécifique pour
    constituer une preuve réelle de vulnérabilité (et non un FP).

    Critères combinés :
    1. Longueur minimale : rejet si < 4 chars
    2. Mot générique seul : rejet si la signature exacte est un mot banal
       ('root', 'admin', 'password'…) — trop présent dans les pages normales
    3. Entropie de Shannon ≥ min_entropy (défaut 2.0 bits)
       Seuil abaissé vs v5.19 car des patterns comme 'root:x:0:0:' (2.37 bits)
       sont clairement significatifs malgré une entropie modérée.
    4. Trop fréquent dans le body : rejeté si la signature apparaît > 5 fois
       naturellement (déjà présente dans la page sans injection).
    """
    if not match_text or len(match_text) < 4:
        return False

    # Rejet des mots génériques seuls (insensible à la casse)
    if match_text.strip().lower() in _GENERIC_WORDS:
        return False

    # Entropie de Shannon
    freq: dict[str, int] = {}
    for ch in match_text:
        freq[ch] = freq.get(ch, 0) + 1
    n = len(match_text)
    entropy = -sum((c / n) * math.log2(c / n) for c in freq.values() if c > 0)
    if entropy < min_entropy:
        return False

    # Fréquence dans le body
    if len(match_text) >= 6 and full_body.count(match_text) > 5:
        return False

    return True


# ── Re-probe ────────────────────────────────────────────────────────────────────

async def re_probe(
    req: "Requester",
    url: str,
    method: str = "GET",
    headers: dict | None = None,
    body: str | None = None,
    delay_s: float = 0.3,
) -> "ProbeResponse | None":
    """
    Rejoue une requête après un court délai et retourne la 2e réponse.
    Utilisé pour confirmer que le hit n'était pas dû à une latence transitoire
    ou une anomalie réseau ponctuelle (jitter, TCP retransmit, etc.).

    Retourne None si la requête échoue (timeout, erreur réseau).
    Le module doit traiter None comme un échec de confirmation.
    """
    await asyncio.sleep(delay_s)
    try:
        from phantomscan.core.requester import ProbeRequest
        resp = await req.send(ProbeRequest(
            method=method,
            url=url,
            headers=headers or {},
            body=body,
        ))
        return None if resp.error else resp
    except Exception:
        return None


# ── Vérification de stabilité de page ───────────────────────────────────────────

async def is_page_stable(
    req: "Requester",
    url: str,
    n_probes: int = 2,
    max_diff: float = 0.08,
) -> bool:
    """
    Vérifie que la page est stable entre n_probes requêtes successives.
    Une page instable (CSRF tokens, contenu personnalisé, compteurs live)
    rend les tests boolean-based non fiables → ne pas lancer le scanner.

    max_diff : différence maximale stable_diff() acceptable (défaut 8 %)
    """
    bodies: list[str] = []
    for _ in range(n_probes):
        try:
            resp = await req.get(url)
            if not resp.error and resp.body:
                bodies.append(resp.body)
        except Exception:
            pass
        await asyncio.sleep(0.1)

    if len(bodies) < 2:
        return True  # Pas assez de données → on suppose stable (bénéfice du doute)

    # Vérifier toutes les paires
    for i in range(len(bodies) - 1):
        if stable_diff(bodies[i], bodies[i + 1]) > max_diff:
            return False
    return True


# ── Classe de façade ─────────────────────────────────────────────────────────────

class FPGuard:
    """
    Façade utilisable par les modules. Regroupe toutes les fonctions anti-FP.
    Peut être instancié sans aucun argument (toutes les méthodes ont des defaults).

    Usage minimal :
        guard = FPGuard(req)
        # Avant de reporter un time-based :
        resp2 = await guard.re_probe(fuzz_url)
        if not guard.time_confirmed(resp2, elapsed_ms, threshold_ms):
            continue
    """

    def __init__(self, req: "Requester | None" = None) -> None:
        self._req = req

    # Délégation vers les fonctions module-level
    def normalize(self, body: str) -> str:
        return normalize_body(body)

    def stable_diff(self, body_a: str, body_b: str) -> float:
        return stable_diff(body_a, body_b)

    def sig_entropy_ok(self, match_text: str, full_body: str,
                       min_entropy: float = 2.5) -> bool:
        return sig_entropy_ok(match_text, full_body, min_entropy)

    async def re_probe(
        self,
        url: str,
        method: str = "GET",
        headers: dict | None = None,
        body: str | None = None,
        delay_s: float = 0.3,
    ) -> "ProbeResponse | None":
        if self._req is None:
            return None
        return await re_probe(self._req, url, method, headers, body, delay_s)

    async def is_page_stable(self, url: str, n_probes: int = 2,
                              max_diff: float = 0.08) -> bool:
        if self._req is None:
            return True
        return await is_page_stable(self._req, url, n_probes, max_diff)

    def time_confirmed(
        self,
        resp2: "ProbeResponse | None",
        elapsed1_ms: float,
        elapsed2_ms: float,
        threshold_ms: float,
    ) -> bool:
        """
        Confirme un time-based hit.
        Conditions :
          1. La 2e requête a aussi dépassé le seuil
          2. Les deux délais sont cohérents (pas un pic isolé)
          3. Le ratio elapsed/threshold est > 1.1 (marge de sécurité)
        """
        if resp2 is None:
            return False
        elapsed2 = getattr(resp2, "elapsed_ms", 0.0)
        if elapsed2 < threshold_ms:
            return False
        # Les deux mesures doivent être cohérentes entre elles (±50%)
        ratio = max(elapsed1_ms, elapsed2) / max(min(elapsed1_ms, elapsed2), 1)
        if ratio > 4.0:
            return False  # Trop inconsistant → probablement transitoire
        return True

    def idor_diff_significant(
        self,
        body_orig: str,
        body_alt: str,
        min_diff: float = 0.20,
        status_orig: int = 200,
        status_alt: int = 200,
    ) -> bool:
        """
        Décide si une différence IDOR est significative.
        Combine diff normalisée + vérification des status codes.
        """
        if status_orig != status_alt:
            # Changement de status → toujours significatif
            return True
        diff = self.stable_diff(body_orig, body_alt)
        return diff >= min_diff

    def baseline_check(self, sig_re: re.Pattern, baseline_body: str) -> bool:
        """
        Retourne True si la signature est DÉJÀ dans le baseline.
        Dans ce cas, la détecter dans une réponse fuzzée est un FP.
        """
        return bool(sig_re.search(normalize_body(baseline_body)))
