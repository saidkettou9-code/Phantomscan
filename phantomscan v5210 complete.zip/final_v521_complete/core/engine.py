"""
PhantomScan — Engine v5.11
Orchestrateur principal.

v5.2 :
- Déduplication de findings : clé (title, url, param) au lieu de (title, url)
- Scope filtering : scope_domains dans ScanConfig
- Concurrence inter-modules bornée : module_concurrency (défaut 4)
- _collect filtre les INFO si silent=True
- _run_vulns : timeout individuels via _run_module
- ScanResult.stats dict pour métriques par module
- Gestion propre KeyboardInterrupt

v5.4 :
- Ajout HTTPSmugglingScanner, S3EnumScanner, DeserializationScanner

v5.7 — Améliorations majeures :
- Phase passive avant attaque, DOM XSS, JSON/REST API Scanner,
  Corrélation inter-findings, Rate adaptatif par module.

v5.6 — Intelligence Layer :
- EndpointBus, TechPrioritizer, CrawlerBridge, recon/vulns en overlap.

v5.12 — Optimisations engine :
- Déduplication du double-crawl : la phase passive alimente _passive_crawled_urls.
  Le recon actif (Crawler dans _run_recon) skip les URLs déjà crawlées passivement
  en passant skip_urls au crawler, évitant de re-fetcher des centaines de pages.
- _collect() : remplace asyncio.Lock par une deque + asyncio.Event pour les findings
  et flush par batch au lieu d'un lock par finding. Réduit la contention sur les
  modules très prolixes (XSS, SQLi bus-mode).
- Métriques cache exposées dans ScanResult.stats à la fin du scan.
- Gestion propre des tâches annulées lors de KeyboardInterrupt (cancel explicite).
"""

from __future__ import annotations

import asyncio
import time
from collections import deque
from dataclasses import dataclass, field
from typing import AsyncGenerator
from urllib.parse import urlparse

from phantomscan.config import PhantomConfig
from phantomscan.core.requester import Requester
from phantomscan.core.fingerprint import Fingerprinter, Fingerprint
from phantomscan.core.heuristic import HeuristicEngine
from phantomscan.core.intelligence import (
    EndpointBus, TechPrioritizer, CrawlerBridge,
    FlowGraphAnalyzer, GraphPayloadChain,
    PatternMemory, SmartRetryOracle,
)
# v5.19 — nouveaux composants
from phantomscan.core.auth_context import AuthContext
from phantomscan.core.oob_canary import OOBCanaryManager
from phantomscan.core.dedup_index import DedupIndex
from phantomscan.core import cvss_scorer
from phantomscan.output.reporter import Reporter, Finding, Severity

_DEFAULT_MODULE_TIMEOUT = 300


@dataclass
class ScanResult:
    target: str
    fingerprint: Fingerprint | None = None
    findings: list[Finding] = field(default_factory=list)
    duration_s: float = 0.0
    errors: list[str] = field(default_factory=list)
    total_requests: int = 0
    module_stats: dict[str, int] = field(default_factory=dict)
    # v5.19 — Métriques additionnelles
    auth_summary: dict = field(default_factory=dict)
    oob_summary: dict = field(default_factory=dict)
    dedup_stats: dict = field(default_factory=dict)

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.CRITICAL)

    @property
    def high_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.HIGH)

    @property
    def medium_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.MEDIUM)


class Engine:

    def __init__(self, config: PhantomConfig) -> None:
        self._cfg = config
        self._reporter = Reporter(config)
        self._findings: list[Finding] = []
        self._lock = asyncio.Lock()
        self._seen_findings: set[tuple[str, str, str]] = set()
        self._scope: set[str] = set(getattr(config.scan, "scope_domains", []))
        # v5.6 — Intelligence Layer
        self._bus = EndpointBus()
        self._prioritizer = TechPrioritizer()
        self._crawler_bridge = CrawlerBridge(self._bus)
        # v5.18 — Intelligence avancée : mémoire de patterns + retry oracle
        self._pattern_memory = PatternMemory()
        self._retry_oracle = SmartRetryOracle()
        # v5.11 — URLs crawlées passivement pour éviter le double-crawl
        self._passive_crawled_urls: set[str] = set()
        # v5.13 — Early stop + streaming JSONL
        self._early_stop_after: int = getattr(config.scan, "early_stop_after", 0)
        self._high_critical_count: int = 0
        self._early_stop_triggered: bool = False
        self._stream_path: str | None = getattr(config.scan, "stream_output", None)
        if self._stream_path:
            import pathlib
            pathlib.Path(self._stream_path).parent.mkdir(parents=True, exist_ok=True)
        # v5.19 — AuthContext, OOB canary manager, DedupIndex
        self._auth_context = AuthContext()
        self._oob = OOBCanaryManager()
        self._dedup = DedupIndex()
        # Charger les profils d'auth depuis la config
        self._init_auth_from_config()

    def _init_auth_from_config(self) -> None:
        """Charge les profils d'auth depuis la config si fournis."""
        auth_specs = getattr(self._cfg.scan, "auth_profiles", None) or []
        for spec in auth_specs:
            try:
                self._auth_context.add_from_string(spec)
            except Exception:
                pass
        # Cookies/headers globaux → profil "default"
        if (self._cfg.cookies or self._cfg.headers) and not self._auth_context.profiles:
            self._auth_context.add_profile(
                "default",
                cookies=dict(self._cfg.cookies),
                headers={k: v for k, v in self._cfg.headers.items()
                         if k.lower() in ("authorization", "x-api-key", "x-auth-token")},
            )

    def _in_scope(self, url: str) -> bool:
        if not self._scope:
            return True
        netloc = urlparse(url).netloc.lower()
        for allowed in self._scope:
            allowed = allowed.lower()
            if netloc == allowed or netloc.endswith("." + allowed):
                return True
        return False

    def _inject_components(self, scanner) -> None:
        """
        v5.19 — Injecte tous les composants partagés sur un scanner.

        Stratégie en deux temps :
          1. Si le scanner expose un setter set_xxx() → on l'appelle.
          2. Sinon, on injecte directement l'attribut _xxx sur l'instance.

        Conséquence : MÊME les modules pré-v5.19 qui n'ont aucun setter v5.19
        reçoivent les nouveaux composants. Ils ne s'en serviront pas activement,
        mais ils ne crashent pas non plus si un fix futur les utilise.
        """
        # Composants v5.6 / v5.18 (déjà branchés via setters dans la plupart des modules)
        components = [
            ("set_endpoint_bus",   "_bus",            self._bus),
            ("set_pattern_memory", "_pattern_memory", self._pattern_memory),
            # v5.19 — Nouveaux composants
            ("set_oob_canary",     "_oob",            self._oob),
            ("set_auth_context",   "_auth_context",   self._auth_context),
            ("set_dedup_index",    "_dedup_index",    self._dedup),
        ]
        for setter_name, attr_name, value in components:
            if value is None:
                continue
            setter = getattr(scanner, setter_name, None)
            if callable(setter):
                try:
                    setter(value)
                    continue
                except Exception:
                    pass
            # Fallback : injection directe d'attribut
            try:
                setattr(scanner, attr_name, value)
            except Exception:
                pass

    @staticmethod
    def _dedup_param(url: str) -> str:
        qs = urlparse(url).query
        if not qs:
            return ""
        return qs.split("&")[0].split("=")[0]

    async def run(self) -> ScanResult:
        t0 = time.monotonic()
        target = self._cfg.target.rstrip("/")
        result = ScanResult(target=target)

        self._reporter.banner(target)

        all_tasks: list[asyncio.Task] = []

        try:
            async with Requester(self._cfg) as req:
                # v5.19 — Brancher l'auth context si on a des profils
                if self._auth_context.has_auth():
                    req.attach_auth(self._auth_context)
                    self._reporter.phase(
                        f"Authentication context loaded "
                        f"({len(self._auth_context.profiles)} profile(s))"
                    )
                # v5.19 — Démarrer l'OOB canary manager si configuré
                oob_spec = getattr(self._cfg.scan, "oob_backend", None)
                if oob_spec:
                    started = await self._oob.start(oob_spec)
                    if started:
                        self._reporter.phase(f"OOB canary backend: {self._oob.backend_name}")
                    else:
                        result.errors.append(f"[OOB] Échec d'initialisation du backend '{oob_spec}'")

                heuristic = HeuristicEngine(req)

                # Phase 0: Fingerprinting
                self._reporter.phase("Fingerprinting")
                fingerprinter = Fingerprinter(req, cfg=self._cfg)
                try:
                    fp = await fingerprinter.run(target)
                    result.fingerprint = fp
                    self._reporter.fingerprint(fp)
                    if fp and fp.waf:
                        jitter = heuristic.waf_backoff or 0.4
                        req.set_waf_jitter(jitter)
                except Exception as e:
                    result.errors.append(f"[Fingerprinter] {e}")
                    fp = None

                # Phase 1: Baseline
                self._reporter.phase("Baseline analysis")
                try:
                    await heuristic.build_baseline(
                        target,
                        n=self._cfg.scan.baseline_requests,
                        fingerprint=fp,
                    )
                except Exception as e:
                    result.errors.append(f"[Baseline] {e}")

                try:
                    await heuristic.probe_soft404(target)
                except Exception as e:
                    result.errors.append(f"[Soft404Probe] {e}")

                self._crawler_bridge.ingest_url(target)

                # v5.7 — Phase passive : crawler silencieux AVANT l'attaque.
                # v5.11 — On mémorise les URLs crawlées pour ne pas les refaire en recon actif.
                self._reporter.phase("Passive crawl (endpoint discovery + per-endpoint baselines)")
                if self._cfg.scan.crawl:
                    try:
                        from phantomscan.modules.recon.crawler import Crawler
                        passive_crawler = Crawler(req, heuristic, self._cfg)
                        async for finding in passive_crawler.run(target):
                            self._crawler_bridge.ingest_finding(finding)
                            # Mémoriser l'URL comme déjà visitée
                            self._passive_crawled_urls.add(finding.url)

                        # Ajouter aussi les endpoints du bus
                        for ep in self._bus.snapshot:
                            self._passive_crawled_urls.add(ep.url)

                        discovered_urls = [ep.url for ep in self._bus.snapshot]
                        if discovered_urls:
                            await heuristic.build_endpoint_baselines(
                                discovered_urls,
                                n=3,
                                concurrency=getattr(self._cfg.scan, "module_concurrency", 4),
                            )
                            self._reporter.phase(
                                f"Per-endpoint baselines built ({len(discovered_urls)} endpoints)"
                            )
                    except Exception as e:
                        result.errors.append(f"[PassiveCrawl] {e}")

                # Phase 2+3 : Recon et Vulns en overlap (v5.6)
                recon_task = None
                vulns_task = None
                offensive_task = None

                if self._cfg.scan.recon:
                    recon_task = asyncio.create_task(
                        self._run_recon(target, req, heuristic, result)
                    )
                    all_tasks.append(recon_task)

                if self._cfg.scan.vulns:
                    vulns_task = asyncio.create_task(
                        self._run_vulns(target, req, heuristic, result, fp)
                    )
                    all_tasks.append(vulns_task)

                offensive_task = asyncio.create_task(
                    self._run_offensive(target, req, heuristic, result)
                )
                all_tasks.append(offensive_task)

                if recon_task:
                    try:
                        await asyncio.wait_for(
                            recon_task,
                            timeout=getattr(self._cfg.scan, "module_timeout", 300) * 2
                        )
                    except (asyncio.TimeoutError, Exception) as e:
                        result.errors.append(f"[Recon] {e}")
                    finally:
                        self._bus.close()
                else:
                    self._bus.close()

                # v5.18 — Phase FlowGraphAnalyzer : analyse des chemins d'attaque multi-étapes
                try:
                    flow = FlowGraphAnalyzer()
                    flow.ingest_bus(self._bus)
                    attack_paths = flow.find_attack_paths()
                    if attack_paths:
                        self._reporter.phase(
                            f"Flow graph analysis ({len(attack_paths)} chemin(s) d'attaque)"
                        )
                        flow_findings: list[Finding] = []
                        for path in attack_paths:
                            flow_findings.append(Finding(
                                title=f"Multi-step Attack Path — {path.attack_type}",
                                url=path.steps[0] if path.steps else target,
                                param="",
                                payload=" → ".join(path.steps),
                                evidence=path.description,
                                severity=Severity.HIGH if path.risk_score >= 0.85 else Severity.MEDIUM,
                                remediation=(
                                    "Valider et restreindre les paramètres de redirection. "
                                    "Implémenter une whitelist stricte des redirect_uri OAuth. "
                                    "Vérifier les tokens CSRF sur chaque transition d'état."
                                ),
                                module="FlowGraphAnalyzer",
                            ))
                        await self._flush_pending(flow_findings, result, "FlowGraphAnalyzer")
                except Exception as e:
                    result.errors.append(f"[FlowGraphAnalyzer] {e}")

                remaining = [t for t in [vulns_task, offensive_task] if t]
                if remaining:
                    done, pending = await asyncio.wait(remaining, return_when=asyncio.ALL_COMPLETED)
                    for t in pending:
                        t.cancel()
                        try:
                            await t
                        except (asyncio.CancelledError, Exception):
                            pass

                # Phase 5: Fuzzing
                if self._cfg.scan.fuzz:
                    await self._run_fuzz(target, req, heuristic, result)

                result.total_requests = req.request_count
                # v5.11 — Exposer les métriques cache
                result.module_stats["_cache_hits"] = req.cache_size

        except KeyboardInterrupt:
            result.errors.append("Scan interrompu par l'utilisateur")
            # v5.11 — Annuler proprement les tâches en cours
            for t in all_tasks:
                if not t.done():
                    t.cancel()

        result.duration_s = time.monotonic() - t0
        result.findings = self._findings

        # v5.7 — Phase de corrélation post-scan
        try:
            from phantomscan.core.correlation import CorrelationEngine
            correlation_engine = CorrelationEngine()
            composite_findings = correlation_engine.correlate(self._findings)
            if composite_findings:
                self._reporter.phase(f"Correlation ({len(composite_findings)} chaîne(s) détectée(s))")
                for cf in composite_findings:
                    self._findings.append(cf)
                    self._reporter.finding(cf)
                result.findings = self._findings
        except Exception as e:
            result.errors.append(f"[Correlation] {e}")

        # v5.19 — Annotation CVSS automatique de tous les findings
        try:
            cvss_scorer.annotate_findings(
                self._findings,
                override_severity=getattr(self._cfg.scan, "cvss_override_severity", False),
            )
        except Exception as e:
            result.errors.append(f"[CVSS] {e}")

        # v5.19 — Métriques additionnelles
        result.auth_summary = self._auth_context.summary()
        result.dedup_stats = self._dedup.stats
        if self._oob.enabled:
            result.oob_summary = {"backend": self._oob.backend_name, "enabled": True}

        # v5.19 — Fermer proprement l'OOB
        try:
            await self._oob.close()
        except Exception:
            pass

        self._reporter.summary(result)

        if self._cfg.scan.output_json:
            self._reporter.write_json(result, self._cfg.scan.output_json)

        # v5.19 — Rapport Markdown BB-ready
        md_path = getattr(self._cfg.scan, "output_markdown", None)
        if md_path:
            try:
                from phantomscan.output.bb_markdown import write_markdown_report
                per_finding_dir = getattr(self._cfg.scan, "output_markdown_per_finding_dir", None)
                written = write_markdown_report(result, md_path, per_finding_dir=per_finding_dir)
                self._reporter.phase(f"Markdown report → {written['global']}")
                if written["per_finding"]:
                    self._reporter.phase(
                        f"Per-finding reports → {len(written['per_finding'])} files in {per_finding_dir}"
                    )
            except Exception as e:
                result.errors.append(f"[Markdown] {e}")

        return result

    async def _run_recon(
        self, target: str, req: Requester,
        heuristic: HeuristicEngine, result: ScanResult,
    ) -> None:
        self._reporter.phase("Recon")
        tasks: list[asyncio.Task] = []

        # v5.19 — Helper : instancie + injecte les composants
        def _build(cls, *args):
            inst = cls(*args)
            self._inject_components(inst)
            return inst

        if self._cfg.scan.subdomain_enum:
            from phantomscan.modules.recon.subdomain import SubdomainEnumerator
            e = _build(SubdomainEnumerator, req, self._cfg)
            tasks.append(asyncio.create_task(
                self._run_module("SubdomainEnumerator", self._collect(e.run(target), result, "SubdomainEnumerator"), result)
            ))

        if self._cfg.scan.crawl:
            from phantomscan.modules.recon.crawler import Crawler
            c = _build(Crawler, req, heuristic, self._cfg)
            # v5.11 — Passer les URLs déjà crawlées passivement pour éviter le double-crawl
            if hasattr(c, "set_skip_urls") and self._passive_crawled_urls:
                c.set_skip_urls(self._passive_crawled_urls)
            tasks.append(asyncio.create_task(
                self._run_module("Crawler", self._collect_and_feed_bus(c.run(target), result, "Crawler"), result)
            ))

        if self._cfg.scan.js_analysis:
            from phantomscan.modules.recon.js_analyzer import JSAnalyzer
            a = _build(JSAnalyzer, req, self._cfg)
            tasks.append(asyncio.create_task(
                self._run_module("JSAnalyzer", self._collect_and_feed_bus(a.run(target), result, "JSAnalyzer"), result)
            ))

        if self._cfg.scan.tech_detect:
            from phantomscan.modules.recon.tech_detect import TechDetector
            d = _build(TechDetector, req, self._cfg)
            tasks.append(asyncio.create_task(
                self._run_module("TechDetector", self._collect(d.run(target), result, "TechDetector"), result)
            ))

        if self._cfg.scan.wayback_scrape:
            from phantomscan.modules.recon.wayback_scraper import WaybackScraper
            wb = _build(WaybackScraper, req, self._cfg)
            tasks.append(asyncio.create_task(
                self._run_module("WaybackScraper", self._collect_and_feed_bus(wb.run(target), result, "WaybackScraper"), result)
            ))

        if self._cfg.scan.google_dork:
            from phantomscan.modules.recon.google_dork import GoogleDorker
            gd = _build(GoogleDorker, req, self._cfg)
            tasks.append(asyncio.create_task(
                self._run_module("GoogleDorker", self._collect(gd.run(target), result, "GoogleDorker"), result)
            ))

        if self._cfg.scan.dns_enum:
            from phantomscan.modules.recon.dns_enum import DNSEnumerator
            de = _build(DNSEnumerator, req, self._cfg)
            tasks.append(asyncio.create_task(
                self._run_module("DNSEnumerator", self._collect(de.run(target), result, "DNSEnumerator"), result)
            ))

        if self._cfg.scan.secrets_finder:
            from phantomscan.modules.recon.secrets_finder import SecretsFinder
            sf = _build(SecretsFinder, req, self._cfg)
            tasks.append(asyncio.create_task(
                self._run_module("SecretsFinder", self._collect(sf.run(target), result, "SecretsFinder"), result)
            ))

        if getattr(self._cfg.scan, "git_exposure", True):
            try:
                from phantomscan.modules.recon.git_exposure import GitExposureScanner
                ge = _build(GitExposureScanner, req, heuristic, self._cfg)
                tasks.append(asyncio.create_task(
                    self._run_module("GitExposureScanner", self._collect(ge.run(target), result, "GitExposureScanner"), result)
                ))
            except ModuleNotFoundError:
                pass

        if getattr(self._cfg.scan, 'param_miner', True):
            try:
                from phantomscan.modules.recon.param_miner import ParamMinerScanner
                pm = _build(ParamMinerScanner, req, heuristic, self._cfg)
                tasks.append(asyncio.create_task(
                    self._run_module('ParamMinerScanner', self._collect(pm.run(target), result, 'ParamMinerScanner'), result)
                ))
            except ModuleNotFoundError:
                pass

        # v5.21 — Sitemap + robots.txt recon
        if getattr(self._cfg.scan, 'sitemap_recon', True):
            try:
                from phantomscan.modules.recon.sitemap_recon import SitemapReconScanner
                sr = _build(SitemapReconScanner, req, heuristic, self._cfg)
                self._inject_components(sr)
                tasks.append(asyncio.create_task(
                    self._run_module('SitemapReconScanner', self._collect(sr.run(target), result, 'SitemapReconScanner'), result)
                ))
            except ModuleNotFoundError:
                pass

        # v5.21 — Cloud bucket recon
        if getattr(self._cfg.scan, 'cloud_recon', True):
            try:
                from phantomscan.modules.recon.cloud_recon import CloudReconScanner
                cr = _build(CloudReconScanner, req, heuristic, self._cfg)
                self._inject_components(cr)
                tasks.append(asyncio.create_task(
                    self._run_module('CloudReconScanner', self._collect(cr.run(target), result, 'CloudReconScanner'), result)
                ))
            except ModuleNotFoundError:
                pass

        # v5.21 — SPA endpoint extractor
        if getattr(self._cfg.scan, 'spa_crawler', True):
            try:
                from phantomscan.modules.recon.spa_crawler import SPACrawler
                sp = _build(SPACrawler, req, heuristic, self._cfg)
                self._inject_components(sp)
                tasks.append(asyncio.create_task(
                    self._run_module('SPACrawler', self._collect(sp.run(target), result, 'SPACrawler'), result)
                ))
            except ModuleNotFoundError:
                pass

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _run_vulns(
        self, target: str, req: Requester,
        heuristic: HeuristicEngine, result: ScanResult,
        fingerprint: Fingerprint | None = None,
    ) -> None:
        self._reporter.phase("Vulnerability scanning")
        scan = self._cfg.scan
        concurrency = getattr(scan, "module_concurrency", 4)
        sem = asyncio.Semaphore(concurrency)

        module_map = [
            ("headers_injection",    "phantomscan.modules.vulns.headers",             "HeadersScanner"),
            ("crlf",                 "phantomscan.modules.vulns.crlf",                "CRLFScanner"),
            ("open_redirect",        "phantomscan.modules.vulns.redirect",            "RedirectScanner"),
            ("auth_bypass",          "phantomscan.modules.vulns.auth_bypass",         "AuthBypassScanner"),
            ("idor",                 "phantomscan.modules.vulns.idor",                "IDORScanner"),
            ("cache_poison",         "phantomscan.modules.vulns.cache_poison",        "CachePoisonScanner"),
            ("xss",                  "phantomscan.modules.vulns.xss",                 "XSSScanner"),
            ("lfi",                  "phantomscan.modules.vulns.lfi",                 "LFIScanner"),
            ("xxe",                  "phantomscan.modules.vulns.xxe",                 "XXEScanner"),
            ("ssrf",                 "phantomscan.modules.vulns.ssrf",                "SSRFScanner"),
            ("prototype_pollution",  "phantomscan.modules.vulns.prototype_pollution", "PrototypePollutionScanner"),
            ("graphql_injection",    "phantomscan.modules.vulns.graphql_injection",   "GraphQLInjectionScanner"),
            ("file_upload",          "phantomscan.modules.vulns.file_upload",         "FileUploadScanner"),
            ("ssti",                 "phantomscan.modules.vulns.ssti",                "SSTIScanner"),
            ("sqli",                 "phantomscan.modules.vulns.sqli",                "SQLiScanner"),
            ("cmdi",                 "phantomscan.modules.vulns.cmdi",                "CMDiScanner"),
            ("jwt",                  "phantomscan.modules.vulns.jwt",                 "JWTScanner"),
            ("actuator",             "phantomscan.modules.vulns.actuator",            "ActuatorScanner"),
            ("http_smuggling",       "phantomscan.modules.vulns.http_smuggling",      "HTTPSmugglingScanner"),
            ("s3_enum",              "phantomscan.modules.vulns.s3_enum",             "S3EnumScanner"),
            ("deserialization",      "phantomscan.modules.vulns.deserialization",     "DeserializationScanner"),
            ("waf_fingerprint",      "phantomscan.modules.vulns.waf_fingerprint",     "WAFFingerprintScanner"),
            ("oauth_misconfig",      "phantomscan.modules.vulns.oauth_misconfig",     "OAuth2MisconfigScanner"),
            ("path_traversal",       "phantomscan.modules.vulns.path_traversal",      "PathTraversalScanner"),
            ("log4shell",            "phantomscan.modules.vulns.log4shell",           "Log4ShellScanner"),
            ("tls_audit",            "phantomscan.modules.vulns.tls_audit",           "TLSAuditScanner"),
            ("dom_xss",              "phantomscan.modules.vulns.dom_xss",             "DOMXSSAnalyzer"),
            ("json_api",             "phantomscan.modules.vulns.json_api",            "JSONAPIScanner"),
            ("nosql_injection",      "phantomscan.modules.vulns.nosql_injection",     "NoSQLInjectionScanner"),
            ("open_api_recon",       "phantomscan.modules.vulns.open_api_recon",      "OpenAPIReconScanner"),
            ("subdomain_takeover",   "phantomscan.modules.vulns.subdomain_takeover",  "SubdomainTakeoverScanner"),
            ("otp_bypass",           "phantomscan.modules.vulns.otp_bypass",          "OTPBypassScanner"),
            ("csrf",                 "phantomscan.modules.vulns.csrf",                "CSRFScanner"),
            ("clickjacking",         "phantomscan.modules.vulns.clickjacking",        "ClickjackingScanner"),
            ("race_condition",       "phantomscan.modules.vulns.race_condition",      "RaceConditionScanner"),
            ("websocket_scan",       "phantomscan.modules.vulns.websocket_scan",      "WebSocketScanner"),
            ("jwt_advanced",         "phantomscan.modules.vulns.jwt_advanced",        "JWTAdvancedScanner"),
            ("business_logic",       "phantomscan.modules.vulns.business_logic",      "BusinessLogicScanner"),
            ("api_security",         "phantomscan.modules.vulns.api_security",        "APISecurityScanner"),
            # v5.15 — Nouveaux modules BB
            ("host_header_injection","phantomscan.modules.vulns.host_header_injection","HostHeaderInjectionScanner"),
            ("dependency_confusion", "phantomscan.modules.vulns.dependency_confusion", "DependencyConfusionScanner"),
            ("mass_assignment",      "phantomscan.modules.vulns.mass_assignment",      "MassAssignmentScanner"),
            # v5.16 — Nouveaux modules BB
            ("exposed_panels",       "phantomscan.modules.vulns.exposed_panels",       "ExposedPanelsScanner"),
            ("api_key_exposure",     "phantomscan.modules.vulns.api_key_exposure",     "APIKeyExposureScanner"),
            ("open_redirect_chain",  "phantomscan.modules.vulns.open_redirect_chain",  "OpenRedirectChainScanner"),
            # v5.21 — Nouveaux modules offensifs
            ("account_takeover",    "phantomscan.modules.vulns.account_takeover",    "AccountTakeoverScanner"),
            ("xpath_injection",     "phantomscan.modules.vulns.xpath_injection",     "XPathInjectionScanner"),
            ("email_injection",     "phantomscan.modules.vulns.email_injection",     "EmailInjectionScanner"),
            ("api_versioning",      "phantomscan.modules.vulns.api_versioning",      "APIVersioningScanner"),
        ]

        priority_order = self._prioritizer.prioritize(fingerprint)
        attr_to_module = {attr: (mod_path, cls_name) for attr, mod_path, cls_name in module_map}
        ordered_map = []
        for attr in priority_order:
            if attr in attr_to_module:
                mod_path, cls_name = attr_to_module[attr]
                ordered_map.append((attr, mod_path, cls_name))
        covered = set(priority_order)
        for attr, mod_path, cls_name in module_map:
            if attr not in covered:
                ordered_map.append((attr, mod_path, cls_name))

        async def _semaphored(attr, mod_path, cls_name):
            # v5.12 — Import et instanciation AVANT d'entrer dans le semaphore :
            # importlib.import_module() est synchrone et CPU-bound ; le faire
            # sous sem bloque inutilement un slot de concurrence pendant le chargement
            # du module (peut prendre ~5-50ms selon la taille du fichier .py).
            try:
                import importlib
                mod = importlib.import_module(mod_path)
                cls = getattr(mod, cls_name)
                scanner = cls(req, heuristic, self._cfg)
                # v5.19 — Injection unifiée de tous les composants partagés
                # (bus, pattern memory, oob, auth, dedup). Garantit que TOUS les
                # modules ont accès aux composants, même ceux sans setter v5.19.
                self._inject_components(scanner)
            except Exception as e:
                result.errors.append(f"[{cls_name}] load error: {e}")
                return

            async with sem:
                req.set_active_module(cls_name)
                try:
                    await self._run_module(
                        cls_name,
                        self._collect(scanner.run(target), result, cls_name),
                        result,
                    )
                finally:
                    req.set_active_module(None)

        tasks = [
            asyncio.create_task(_semaphored(attr, mod_path, cls_name))
            for attr, mod_path, cls_name in ordered_map
            if getattr(scan, attr, False)
        ]
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _run_offensive(
        self, target: str, req: Requester,
        heuristic: HeuristicEngine, result: ScanResult,
    ) -> None:
        self._reporter.phase("Offensive modules")
        scan = self._cfg.scan
        concurrency = getattr(scan, "module_concurrency", 4)
        sem = asyncio.Semaphore(concurrency)
        tasks: list[asyncio.Task] = []

        offensive_map = [
            ("cors",             "phantomscan.modules.vulns.cors",                  "CORSScanner"),
            ("forbidden_bypass", "phantomscan.modules.vulns.forbidden_bypass",      "ForbiddenBypassScanner"),
            ("rate_limit",       "phantomscan.modules.vulns.rate_limit",            "RateLimitScanner"),
            ("vhost_discovery",  "phantomscan.modules.network.vhost_discovery",     "VHostDiscovery"),
            ("port_scan",        "phantomscan.modules.network.port_scan",           "PortScanner"),
        ]

        async def _semaphored_off(attr, mod_path, cls_name):
            # v5.12 — Même pattern que _run_vulns : import hors du semaphore.
            try:
                import importlib
                mod = importlib.import_module(mod_path)
                cls = getattr(mod, cls_name)
                scanner = cls(req, heuristic, self._cfg)
                # v5.19 — Injection unifiée des composants
                self._inject_components(scanner)
            except ModuleNotFoundError:
                return
            except Exception as e:
                result.errors.append(f"[{cls_name}] load error: {e}")
                return

            async with sem:
                try:
                    await self._run_module(
                        cls_name,
                        self._collect(scanner.run(target), result, cls_name),
                        result,
                    )
                except Exception as e:
                    result.errors.append(f"[{cls_name}] load error: {e}")

        for attr, mod_path, cls_name in offensive_map:
            if getattr(scan, attr, True):
                tasks.append(asyncio.create_task(_semaphored_off(attr, mod_path, cls_name)))

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

        # v5.18 — GraphPayloadChain : exécution des chaînes de payloads multi-étapes
        try:
            chain_gen = GraphPayloadChain()
            fp_hints: list[str] = []
            if hasattr(self, "_prioritizer") and hasattr(self._prioritizer, "_detected_techs"):
                fp_hints = list(self._prioritizer._detected_techs)

            chain_findings: list[Finding] = []
            for ep in self._bus.snapshot:
                chains = chain_gen.chains_for_endpoint(ep, tech_hints=fp_hints)
                for chain in chains:
                    # Exécuter chaque étape de la chaîne séquentiellement
                    context: dict = {}
                    chain_ok = True
                    for step in chain.steps:
                        step_num = step.get("step", 0)
                        method = step.get("method", "GET").upper()
                        step_url = step.get("url", ep.url)
                        params = {**step.get("params", {})}
                        body = step.get("body_override") or step.get("body") or {}

                        # Injecter les valeurs extraites des étapes précédentes
                        for key in step.get("inject_extracted", []):
                            if key in context:
                                body[key] = context[key]

                        # Requêtes simultanées pour race condition
                        concurrent = step.get("concurrent", 1)
                        try:
                            if concurrent > 1:
                                resps = await asyncio.gather(*[
                                    req.post(step_url, json=body or None, params=params or None)
                                    for _ in range(min(concurrent, 10))
                                ], return_exceptions=True)
                                resp = next((r for r in resps if not isinstance(r, Exception)), None)
                            elif method == "POST":
                                resp = await req.post(step_url, json=body or None, params=params or None)
                            else:
                                resp = await req.get(step_url, params=params or None)
                        except Exception:
                            chain_ok = False
                            break

                        if resp is None or resp.error:
                            chain_ok = False
                            break

                        # Extraction de valeurs pour les étapes suivantes (ex: CSRF token)
                        extract = step.get("extract", {})
                        for var_name, pattern in extract.items():
                            import re as _re
                            m = _re.search(pattern, resp.body)
                            if m:
                                context[var_name] = m.group(1)

                        # Vérifier la condition de succès
                        success_if = step.get("success_if", "")
                        if success_if and "status==200" in success_if:
                            if resp.status != 200:
                                chain_ok = False
                                break

                    if chain_ok and chain.expected_indicator in ("200 on foreign resource write",
                                                                  "200 OR action_performed"):
                        chain_findings.append(Finding(
                            title=f"Chained Attack Confirmed — {chain.name}",
                            url=ep.url,
                            param=", ".join(ep.params[:3]),
                            payload=f"{chain.vuln_type} chain ({len(chain.steps)} steps)",
                            evidence=f"Chaîne exécutée avec succès : {chain.name}",
                            severity=Severity.CRITICAL if chain.severity == "CRITICAL" else Severity.HIGH,
                            remediation=(
                                "Implémenter des contrôles d'autorisation à chaque étape. "
                                "Valider les tokens CSRF. Utiliser des sessions isolées."
                            ),
                            module="GraphPayloadChain",
                        ))

            if chain_findings:
                self._reporter.phase(f"GraphPayloadChain ({len(chain_findings)} chaîne(s) confirmée(s))")
                await self._flush_pending(chain_findings, result, "GraphPayloadChain")

        except Exception as e:
            result.errors.append(f"[GraphPayloadChain] {e}")

    async def _run_fuzz(
        self, target: str, req: Requester,
        heuristic: HeuristicEngine, result: ScanResult,
    ) -> None:
        self._reporter.phase("Smart fuzzing")
        if self._cfg.scan.smart_fuzz:
            from phantomscan.modules.fuzz.smart_fuzzer import SmartFuzzer
            fuzzer = SmartFuzzer(req, heuristic, self._cfg)
            await self._run_module(
                "SmartFuzzer",
                self._collect(fuzzer.run(target), result, "SmartFuzzer"),
                result,
            )

    async def _run_module(self, module_name: str, coro, result: ScanResult) -> None:
        timeout = getattr(self._cfg.scan, "module_timeout", _DEFAULT_MODULE_TIMEOUT)
        try:
            await asyncio.wait_for(coro, timeout=timeout)
        except asyncio.TimeoutError:
            async with self._lock:
                result.errors.append(f"[{module_name}] timeout après {timeout}s")
        except asyncio.CancelledError:
            raise
        except Exception as e:
            async with self._lock:
                result.errors.append(f"[{module_name}] {e}")

    async def _flush_pending(
        self,
        pending: list[Finding],
        result: ScanResult,
        module_name: str,
    ) -> list[Finding]:
        """
        v5.12 — Flush atomique d'un batch de findings vers self._findings.
        v5.13 — Streaming JSONL live + early stop après N CRITICAL/HIGH.
        """
        if not pending:
            return []
        batch = pending
        async with self._lock:
            for finding in batch:
                param_key = self._dedup_param(finding.url)
                dedup_key = (finding.title, finding.url, param_key)
                if dedup_key in self._seen_findings:
                    continue
                self._seen_findings.add(dedup_key)
                self._findings.append(finding)
                result.module_stats[module_name] = result.module_stats.get(module_name, 0) + 1
                self._reporter.finding(finding)

                # v5.13 — Streaming JSONL live
                if self._stream_path:
                    try:
                        import json as _json
                        from dataclasses import asdict
                        line = _json.dumps(asdict(finding), default=str)
                        with open(self._stream_path, "a", encoding="utf-8") as _sf:
                            _sf.write(line + "\n")
                    except Exception:
                        pass

                # v5.13 — Early stop
                if finding.severity in (Severity.CRITICAL, Severity.HIGH):
                    self._high_critical_count += 1
                    if self._early_stop_after and self._high_critical_count >= self._early_stop_after:
                        self._early_stop_triggered = True
                        self._reporter.phase(
                            f"Early stop : {self._high_critical_count} findings "
                            f"CRITICAL/HIGH atteints (--early-stop {self._early_stop_after})"
                        )
        return []

    async def _collect(
        self,
        gen: AsyncGenerator[Finding, None],
        result: ScanResult,
        module_name: str = "",
    ) -> None:
        """
        v5.12 — _collect() avec flush factorisé via _flush_pending().
        v5.13 — Vérifie l'early stop avant chaque itération.
        """
        pending: list[Finding] = []
        total_seen = 0

        async for finding in gen:
            # v5.13 — Early stop
            if self._early_stop_triggered:
                break

            if self._cfg.scan.silent and finding.severity == Severity.INFO:
                continue
            if not self._in_scope(finding.url):
                continue

            pending.append(finding)
            total_seen += 1
            flush_threshold = 25 if total_seen > 50 else 10
            if len(pending) >= flush_threshold:
                pending = await self._flush_pending(pending, result, module_name)

        await self._flush_pending(pending, result, module_name)

    async def _collect_and_feed_bus(
        self,
        gen: AsyncGenerator[Finding, None],
        result: ScanResult,
        module_name: str = "",
    ) -> None:
        """
        v5.6 — Variante de _collect qui alimente aussi le bus d'endpoints.
        v5.12 — Utilise _flush_pending() factorisé.
        v5.13 — Early stop intégré.
        """
        pending: list[Finding] = []
        total_seen = 0

        async for finding in gen:
            # Alimenter le bus AVANT le filtre silent
            self._crawler_bridge.ingest_finding(finding)

            # v5.13 — Early stop
            if self._early_stop_triggered:
                break

            if self._cfg.scan.silent and finding.severity == Severity.INFO:
                continue
            if not self._in_scope(finding.url):
                continue

            pending.append(finding)
            total_seen += 1
            flush_threshold = 25 if total_seen > 50 else 10
            if len(pending) >= flush_threshold:
                pending = await self._flush_pending(pending, result, module_name)

        await self._flush_pending(pending, result, module_name)
