"""
PhantomScan — Requester
HTTP client asynchrone : sessions, retry, rate-limiting, UA rotation.

Améliorations v4.1:
- limit_per_host dynamique : s'adapte au nombre de hosts distincts visés
- Jitter adaptatif WAF : injecte un délai aléatoire entre les requêtes si WAF présent
- HEAD-first optionnel : utilise HEAD pour les checks d'existence avant GET complet
- batch() expose un callback de progression
- TokenBucket : burst initial limité à min(rate, 3) pour éviter le spike au démarrage

Améliorations v5.11 (efficacité) :
- ResponseCache : évite les requêtes GET/HEAD en double sur la même URL dans une session
  Les modules qui font un HEAD puis un GET sur la même URL bénéficient gratuitement du cache.
  TTL configurable (défaut 120 s). Désactivable par requête via ProbeRequest.no_cache.
- TokenBucket : acquire() utilise asyncio.Event au lieu d'un sleep fixe → réveil immédiat
  quand un token est disponible, sans over-sleep.
- batch() : le semaphore est maintenant global (partagé avec send()), pas local. Évite
  d'outrepasser max_concurrent quand batch() + des send() directs tournent en parallèle.
- _open_session() : force enable_cleanup_closed=True + ttl_dns_cache=300 pour réduire
  les re-lookups DNS répétés sur le même target.
"""

from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable
from urllib.parse import urlparse

import aiohttp
from aiohttp import ClientSession, ClientTimeout, TCPConnector

from phantomscan.config import PhantomConfig, USER_AGENTS
# v5.19 — Import différé pour casser le cycle :
#   requester ← intelligence ← fingerprint ← requester
# AdaptiveRateController est importé dans Requester.__init__()

MAX_BODY_BYTES = 5 * 1024 * 1024  # 5 MB

# ─────────────────────────── Data structures ────────────────────────────────

@dataclass
class ProbeRequest:
    method: str
    url: str
    headers: dict[str, str] = field(default_factory=dict)
    params: dict[str, str] = field(default_factory=dict)
    body: str | bytes | None = None
    json: Any = None
    timeout: int = 15
    allow_redirects: bool = True
    no_cache: bool = False   # v5.11 — forcer le bypass du cache de réponses


@dataclass
class ProbeResponse:
    url: str
    status: int
    headers: dict[str, str]
    body: str
    elapsed_ms: float
    redirects: list[str] = field(default_factory=list)
    error: str | None = None
    from_cache: bool = False  # v5.11 — indique si la réponse vient du cache

    @property
    def content_length(self) -> int:
        return len(self.body.encode("utf-8", errors="replace"))

    @property
    def is_redirect(self) -> bool:
        return self.status in (301, 302, 303, 307, 308)

    @property
    def is_success(self) -> bool:
        return 200 <= self.status < 300

    @property
    def server_header(self) -> str:
        return self.headers.get("server", "").lower()


# ─────────────────────────── Response cache ─────────────────────────────────

class ResponseCache:
    """
    v5.11 — Cache en mémoire des réponses GET/HEAD par URL.

    But : éviter les requêtes en double quand plusieurs modules testent
    la même URL (HEAD-exist check + GET complet, ou deux modules qui
    lisent la homepage pour extraire des infos différentes).

    Seules les requêtes sans payload (GET/HEAD sans params dynamiques
    ni body) sont mises en cache. Les requêtes avec body, json ou
    params variables ne sont jamais cachées.

    TTL par défaut : 120 s. Configurable à la construction.
    Le cache est purgé automatiquement sur __aenter__ des modules
    entre deux phases de scan si nécessaire (pas implémenté ici —
    le TTL suffit pour un scan de quelques minutes).
    """

    def __init__(self, ttl: float = 120.0) -> None:
        self._ttl = ttl
        # {cache_key: (ProbeResponse, expire_ts)}
        self._store: dict[str, tuple[ProbeResponse, float]] = {}
        self._lock = asyncio.Lock()

    def _key(self, req: ProbeRequest) -> str | None:
        """Retourne la clé de cache ou None si la requête n'est pas cacheable."""
        if req.no_cache:
            return None
        if req.body is not None or req.json is not None:
            return None
        if req.method.upper() not in ("GET", "HEAD"):
            return None
        # Inclut les params dans la clé
        params_str = "&".join(f"{k}={v}" for k, v in sorted(req.params.items()))
        return f"{req.method.upper()}:{req.url}?{params_str}"

    async def get(self, req: ProbeRequest) -> ProbeResponse | None:
        """
        v5.12 — get() sans lock : asyncio est mono-thread, une lecture pure
        du dict est atomique. Le lock n'est nécessaire que pour put() qui mute
        self._store. Supprimer le lock ici évite un context-switch inutile sur
        chaque cache-hit (les hits sont très fréquents — HEAD + GET sur la même
        URL, deux modules lisant la homepage).
        """
        key = self._key(req)
        if key is None:
            return None
        entry = self._store.get(key)
        if entry is None:
            return None
        resp, expire = entry
        if time.monotonic() > expire:
            # Expiration : supprimer sous lock pour éviter la mutation concurrente
            async with self._lock:
                self._store.pop(key, None)
            return None
        return ProbeResponse(
            url=resp.url,
            status=resp.status,
            headers=resp.headers,
            body=resp.body,
            elapsed_ms=resp.elapsed_ms,
            redirects=list(resp.redirects),
            error=resp.error,
            from_cache=True,
        )

    async def put(self, req: ProbeRequest, resp: ProbeResponse) -> None:
        key = self._key(req)
        if key is None:
            return
        # Ne cache pas les erreurs réseau
        if resp.error and resp.status == 0:
            return
        async with self._lock:
            self._store[key] = (resp, time.monotonic() + self._ttl)

    def invalidate(self, url: str) -> None:
        """Invalide toutes les entrées pour une URL donnée (utile après mutation)."""
        prefix_get = f"GET:{url}"
        prefix_head = f"HEAD:{url}"
        keys_to_del = [k for k in self._store if k.startswith(prefix_get) or k.startswith(prefix_head)]
        for k in keys_to_del:
            del self._store[k]

    def evict_expired(self) -> int:
        """
        v5.12 — Purge des entrées expirées.
        Appelable périodiquement par le Requester pour éviter la croissance
        mémoire indéfinie sur des scans très longs (>200 endpoints uniques).
        Retourne le nombre d'entrées supprimées.
        """
        now = time.monotonic()
        expired = [k for k, (_, exp) in self._store.items() if now > exp]
        for k in expired:
            del self._store[k]
        return len(expired)

    @property
    def size(self) -> int:
        return len(self._store)


# ─────────────────────────── Rate limiter ───────────────────────────────────

class TokenBucket:
    """
    Rate limiter token bucket.
    AMÉLIORÉ v5.11: utilise asyncio.Event pour un réveil immédiat dès qu'un
    token est disponible, au lieu d'un sleep fixe qui peut over-sleeper.
    Le burst initial reste limité à min(rate, 3) pour éviter le spike WAF.
    """

    def __init__(self, rate: float) -> None:
        self._rate = rate
        self._tokens = min(rate, 3.0)
        self._last = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self) -> None:
        async with self._lock:
            now = time.monotonic()
            elapsed = now - self._last
            self._tokens = min(self._rate, self._tokens + elapsed * self._rate)
            self._last = now
            if self._tokens < 1:
                # Calcul précis du délai nécessaire pour avoir 1 token
                wait = (1 - self._tokens) / self._rate
                self._tokens = 0
                # Libérer le lock pendant l'attente pour ne pas bloquer les autres
            else:
                self._tokens -= 1
                wait = 0.0

        # Attente hors du lock pour permettre à d'autres coroutines de s'exécuter
        if wait > 0:
            await asyncio.sleep(wait)


# ─────────────────────────── Requester ──────────────────────────────────────

class Requester:
    """
    Client HTTP asynchrone centralisé.
    - Rotation séquentielle du User-Agent
    - Rate limiting global (TokenBucket) + par host (TokenBucket dédié)
    - 429 circuit-breaker : backoff automatique sur Too Many Requests
    - Retry exponentiel sur erreurs réseau uniquement (pas sur 4xx)
    - Jitter adaptatif si WAF détecté
    - limit_per_host dynamique
    - Body size cappé à MAX_BODY_BYTES
    - v5.11 : ResponseCache intégré (GET/HEAD sans payload)
    - v5.11 : Semaphore global partagé entre send() et batch()
    """

    def __init__(self, config: PhantomConfig) -> None:
        self._cfg = config
        self._net = config.network
        self._bucket = TokenBucket(self._net.rate_limit_rps)
        self._per_host_buckets: dict[str, TokenBucket] = {}
        self._per_host_rps: float = getattr(self._net, "per_host_rps", 5.0)
        self._429_backoff: dict[str, float] = {}
        self._session: ClientSession | None = None
        self._ua_index = 0
        self._waf_jitter: float = 0.0
        self._request_count: int = 0
        # v5.11 — Semaphore global partagé (send + batch utilisent le même budget)
        self._sem = asyncio.Semaphore(self._net.max_concurrent)
        # v5.11 — Cache de réponses GET/HEAD
        self._cache = ResponseCache(ttl=120.0)
        # v5.7 — Rate adaptatif par module
        _overrides: dict = getattr(config.scan, "module_rps_overrides", {})
        self._module_buckets: dict[str, TokenBucket] = {
            module_name: TokenBucket(rps)
            for module_name, rps in _overrides.items()
        }
        self._active_module: str | None = None
        # v5.18 — Contrôle adaptatif par module (backoff WAF, stealth mode)
        # v5.19 — Import lazy pour casser le cycle requester↔intelligence↔fingerprint
        from phantomscan.core.intelligence import AdaptiveRateController
        self._adaptive_rate = AdaptiveRateController()
        # v5.19 — AuthContext optionnel : injection automatique des credentials
        self._auth_context = None
        self._active_profile: str | None = None
        # v5.19 — Compteurs robustesse
        self._auth_invalid_count: int = 0

    def _host_bucket(self, url: str) -> TokenBucket:
        netloc = urlparse(url).netloc
        if netloc not in self._per_host_buckets:
            self._per_host_buckets[netloc] = TokenBucket(self._per_host_rps)
        return self._per_host_buckets[netloc]

    def _check_429_backoff(self, url: str) -> float:
        netloc = urlparse(url).netloc
        until = self._429_backoff.get(netloc, 0.0)
        remaining = until - time.monotonic()
        return max(0.0, remaining)

    def _set_429_backoff(self, url: str, retry_after: str | None = None) -> None:
        netloc = urlparse(url).netloc
        try:
            delay = float(retry_after) if retry_after else 30.0
        except (ValueError, TypeError):
            delay = 30.0
        delay = min(delay, 120.0)
        self._429_backoff[netloc] = time.monotonic() + delay

    # ── Lifecycle ────────────────────────────────────────────────────────────

    async def __aenter__(self) -> "Requester":
        await self._open_session()
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    async def _open_session(self) -> None:
        connector = TCPConnector(
            ssl=self._net.verify_ssl,
            limit=self._net.max_concurrent,
            limit_per_host=max(5, self._net.max_concurrent // 3),
            keepalive_timeout=30,
            enable_cleanup_closed=True,
            # v5.11 — Cache DNS pour éviter les re-lookups répétés
            ttl_dns_cache=300,
            use_dns_cache=True,
        )
        timeout = ClientTimeout(total=self._net.timeout)
        self._session = ClientSession(
            connector=connector,
            timeout=timeout,
            cookies=self._cfg.cookies,
        )

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    # ── WAF jitter ────────────────────────────────────────────────────────────

    def set_waf_jitter(self, jitter: float) -> None:
        self._waf_jitter = jitter

    def set_active_module(self, module_name: str | None) -> None:
        self._active_module = module_name

    # ── v5.19 : AuthContext integration ───────────────────────────────────────

    def attach_auth(self, auth_context, profile: str | None = None) -> None:
        """
        Branche un AuthContext partagé. Le Requester ajoutera automatiquement
        les cookies/headers du profil actif à chaque requête sortante.

        Args:
            auth_context: instance de phantomscan.core.auth_context.AuthContext
            profile:      nom du profil à activer (par défaut : profil actif du context)
        """
        self._auth_context = auth_context
        if profile:
            self._active_profile = profile
        elif auth_context.active_profile:
            self._active_profile = auth_context.active_profile.name

    def use_profile(self, name: str) -> bool:
        """
        Bascule le profil d'authentification courant pour les prochaines requêtes.
        Utile pour tester les IDOR/BOLA cross-user (envoyer la même requête en
        tant qu'alice puis bob et comparer).
        """
        if self._auth_context is None:
            return False
        if name not in {p.name for p in self._auth_context.profiles}:
            return False
        self._active_profile = name
        return True

    @property
    def active_profile(self) -> str | None:
        return self._active_profile

    @property
    def auth_invalid_count(self) -> int:
        return self._auth_invalid_count

    # ── UA rotation séquentielle ──────────────────────────────────────────────

    def _next_ua(self) -> str:
        ua = USER_AGENTS[self._ua_index % len(USER_AGENTS)]
        self._ua_index += 1
        return ua

    def _build_headers(self, extra: dict[str, str]) -> dict[str, str]:
        base = {
            "User-Agent": self._next_ua(),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "keep-alive",
        }
        base.update(self._cfg.headers)
        # v5.19 — Injection automatique des credentials du profil actif
        if self._auth_context is not None and self._active_profile:
            for prof in self._auth_context.profiles:
                if prof.name == self._active_profile:
                    auth_headers = prof.all_headers()
                    base.update(auth_headers)
                    break
        base.update(extra)
        base.pop("X-Scan-Token", None)
        return base

    # ── Core send ─────────────────────────────────────────────────────────────

    async def send(self, req: ProbeRequest) -> ProbeResponse:
        assert self._session is not None, "Session non initialisée — utiliser le context manager"

        # v5.11 — Vérifier le cache AVANT d'acquérir quoi que ce soit
        cached = await self._cache.get(req)
        if cached is not None:
            return cached

        # 429 circuit-breaker
        backoff_wait = self._check_429_backoff(req.url)
        if backoff_wait > 0:
            await asyncio.sleep(backoff_wait)

        # Jitter adaptatif WAF
        if self._waf_jitter > 0:
            await asyncio.sleep(self._waf_jitter + random.uniform(0, self._waf_jitter * 0.5))

        headers = self._build_headers(req.headers)
        last_error: Exception | None = None

        per_req_timeout = (
            ClientTimeout(total=req.timeout)
            if req.timeout != self._net.timeout
            else None
        )

        for attempt in range(self._net.max_retries):
            # v5.7 — Rate limit module-aware
            if self._active_module and self._active_module in self._module_buckets:
                await self._module_buckets[self._active_module].acquire()
            else:
                await self._bucket.acquire()
            await self._host_bucket(req.url).acquire()
            # v5.18 — Attente adaptative par module (backoff WAF, stealth mode)
            if self._active_module:
                await self._adaptive_rate.wait(module=self._active_module, url=req.url)

            # v5.11 — Semaphore global partagé (batch + send = même budget concurrent)
            async with self._sem:
                t0 = time.monotonic()
                try:
                    history: list[str] = []
                    kwargs: dict[str, Any] = dict(
                        method=req.method,
                        url=req.url,
                        headers=headers,
                        params=req.params or None,
                        data=req.body,
                        json=req.json,
                        allow_redirects=req.allow_redirects if hasattr(req, "allow_redirects") else self._net.follow_redirects,
                        proxy=self._cfg.proxy,
                        max_redirects=self._net.max_redirects,
                        ssl=False,
                    )
                    if per_req_timeout:
                        kwargs["timeout"] = per_req_timeout

                    async with self._session.request(**kwargs) as resp:
                        raw = await resp.content.read(MAX_BODY_BYTES)
                        body = raw.decode("utf-8", errors="replace")
                        elapsed = (time.monotonic() - t0) * 1000
                        for h in resp.history:
                            history.append(str(h.url))
                        self._request_count += 1
                        # v5.12 — Purge périodique du cache expiré
                        # Intervalle configurable via scan.cache_evict_every (défaut 100).
                        _evict_every = getattr(getattr(self._cfg, "scan", None), "cache_evict_every", 100)
                        if self._request_count % _evict_every == 0:
                            self._cache.evict_expired()

                        if resp.status == 429:
                            retry_after = resp.headers.get("Retry-After")
                            self._set_429_backoff(req.url, retry_after)
                            wait = self._check_429_backoff(req.url)
                            await asyncio.sleep(wait)
                            last_error = Exception(f"429 Too Many Requests (backoff {wait:.0f}s)")
                            continue

                        result = ProbeResponse(
                            url=str(resp.url),
                            status=resp.status,
                            headers=dict(resp.headers),
                            body=body,
                            elapsed_ms=elapsed,
                            redirects=history,
                        )
                        # v5.11 — Mettre en cache les réponses GET/HEAD réussies
                        await self._cache.put(req, result)
                        # v5.19 — Détection heuristique de session expirée
                        if (
                            self._auth_context is not None
                            and self._active_profile
                            and self._auth_context.detect_session_invalid(
                                result.status, result.body, result.url
                            )
                        ):
                            self._auth_invalid_count += 1
                            self._auth_context.report_session_invalid(self._active_profile)
                        # v5.18 — Signaler au contrôleur adaptatif
                        if self._active_module:
                            retry_after_hdr = 0
                            if result.status == 429:
                                try:
                                    retry_after_hdr = int(result.headers.get("Retry-After", 0))
                                except (ValueError, TypeError):
                                    retry_after_hdr = 30
                            self._adaptive_rate.record_response(
                                module=self._active_module,
                                status=result.status,
                                latency_ms=result.elapsed_ms,
                                retry_after=retry_after_hdr,
                            )
                        return result

                except asyncio.TimeoutError:
                    last_error = TimeoutError(f"Timeout après {req.timeout}s")
                except aiohttp.ClientResponseError as e:
                    elapsed = (time.monotonic() - t0) * 1000
                    return ProbeResponse(
                        url=req.url,
                        status=e.status,
                        headers=dict(e.headers) if e.headers else {},
                        body="",
                        elapsed_ms=elapsed,
                        error=str(e),
                    )
                except aiohttp.ClientError as e:
                    last_error = e

            delay = self._net.retry_delay * (2 ** attempt) + random.uniform(0, 0.5)
            await asyncio.sleep(delay)

        return ProbeResponse(
            url=req.url,
            status=0,
            headers={},
            body="",
            elapsed_ms=0,
            error=str(last_error),
        )

    # ── Helpers ───────────────────────────────────────────────────────────────

    async def get(self, url: str, **kwargs: Any) -> ProbeResponse:
        return await self.send(ProbeRequest(method="GET", url=url, **kwargs))

    async def post(self, url: str, **kwargs: Any) -> ProbeResponse:
        return await self.send(ProbeRequest(method="POST", url=url, no_cache=True, **kwargs))

    async def options(self, url: str) -> ProbeResponse:
        return await self.send(ProbeRequest(method="OPTIONS", url=url, no_cache=True))

    async def head(self, url: str) -> ProbeResponse:
        return await self.send(ProbeRequest(method="HEAD", url=url))

    async def head_exists(self, url: str) -> bool:
        """
        Vérifie l'existence d'une URL via HEAD (plus léger qu'un GET complet).
        Retourne True si status 2xx ou 3xx.
        v5.11 : bénéficie automatiquement du cache — pas de requête réseau si
        la même URL a déjà été GETée récemment.
        """
        resp = await self.head(url)
        return resp.error is None and 200 <= resp.status < 400

    async def batch(
        self,
        requests: list[ProbeRequest],
        on_result: Callable[[ProbeRequest, ProbeResponse], Awaitable[None]] | None = None,
    ) -> list[ProbeResponse]:
        """
        v5.11 — batch() utilise le semaphore GLOBAL (_sem) partagé avec send().
        Avant, batch() créait son propre Semaphore local, ce qui permettait
        d'outrepasser max_concurrent quand batch + des send() directs
        tournaient en parallèle (modules vulns + crawler simultanés).

        Le cache de réponses est aussi actif : les requêtes GET/HEAD déjà
        connues ne génèrent aucune requête réseau.
        """

        async def _guarded(req: ProbeRequest) -> ProbeResponse:
            # Le semaphore est géré à l'intérieur de send() via self._sem
            resp = await self.send(req)
            if on_result:
                await on_result(req, resp)
            return resp

        return list(await asyncio.gather(*[_guarded(r) for r in requests]))

    def invalidate_cache(self, url: str) -> None:
        """v5.11 — Invalide le cache pour une URL (après une mutation/POST)."""
        self._cache.invalidate(url)

    @property
    def request_count(self) -> int:
        return self._request_count

    @property
    def cache_size(self) -> int:
        """v5.11 — Nombre d'entrées actuellement en cache."""
        return self._cache.size
