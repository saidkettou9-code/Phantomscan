"""
PhantomScan — ScannerMixin (v5.20)
====================================
Mixin commun à tous les scanners de vulns. Fournit :
  - Setters standardisés (bus, memory, oob, auth, dedup)
  - FPGuard intégré : re_probe, stable_diff, normalize, sig_entropy_ok
  - Helpers : should_skip, get_canary, iter_profiles, record_pattern_success
"""

from __future__ import annotations
from urllib.parse import urlparse


class ScannerMixin:
    """Mixin universel pour tous les scanners PhantomScan."""

    # ── Setters ───────────────────────────────────────────────────────────────

    def set_endpoint_bus(self, bus) -> None:
        self._phantom_bus = bus
        if not hasattr(self, "_bus") or getattr(self, "_bus", None) is None:
            self._bus = bus

    def set_pattern_memory(self, memory) -> None:
        self._phantom_pattern_memory = memory
        if not hasattr(self, "_pattern_memory") or getattr(self, "_pattern_memory", None) is None:
            self._pattern_memory = memory

    def set_oob_canary(self, oob) -> None:
        self._phantom_oob = oob
        if not hasattr(self, "_oob") or getattr(self, "_oob", None) is None:
            self._oob = oob

    def set_auth_context(self, ctx) -> None:
        self._phantom_auth_context = ctx
        if not hasattr(self, "_auth_context") or getattr(self, "_auth_context", None) is None:
            self._auth_context = ctx

    def set_dedup_index(self, idx) -> None:
        self._phantom_dedup_index = idx
        if not hasattr(self, "_dedup_index") or getattr(self, "_dedup_index", None) is None:
            self._dedup_index = idx

    # ── Accès safe ────────────────────────────────────────────────────────────

    @property
    def bus(self):
        return getattr(self, "_phantom_bus", None) or getattr(self, "_bus", None)

    @property
    def pattern_memory(self):
        return (getattr(self, "_phantom_pattern_memory", None)
                or getattr(self, "_pattern_memory", None))

    @property
    def oob(self):
        return getattr(self, "_phantom_oob", None) or getattr(self, "_oob", None)

    @property
    def auth_context(self):
        return (getattr(self, "_phantom_auth_context", None)
                or getattr(self, "_auth_context", None))

    @property
    def dedup_index(self):
        return (getattr(self, "_phantom_dedup_index", None)
                or getattr(self, "_dedup_index", None))

    # ── FPGuard intégré ───────────────────────────────────────────────────────

    @property
    def _fpguard(self):
        if not hasattr(self, "_phantom_fpguard") or self._phantom_fpguard is None:
            from phantomscan.core.fp_guard import FPGuard
            req = getattr(self, "_req", None)
            self._phantom_fpguard = FPGuard(req)
        return self._phantom_fpguard

    async def re_probe(self, url, method="GET", headers=None, body=None, delay_s=0.3):
        """Rejoue la requête après delay_s pour confirmer un hit (anti-FP transitoire)."""
        return await self._fpguard.re_probe(url, method, headers, body, delay_s)

    def stable_diff(self, body_a, body_b):
        """Diff normalisée 0.0=identique 1.0=totalement différent (tokens/timestamps filtrés)."""
        return self._fpguard.stable_diff(body_a, body_b)

    def normalize_body(self, body):
        """Supprime timestamps, CSRF tokens, UUIDs dynamiques."""
        return self._fpguard.normalize(body)

    def sig_entropy_ok(self, match_text, full_body, min_entropy=2.5):
        """True si la signature matchée est assez spécifique (pas un mot banal)."""
        return self._fpguard.sig_entropy_ok(match_text, full_body, min_entropy)

    def time_hit_confirmed(self, resp2, elapsed1_ms, elapsed2_ms, threshold_ms):
        """Confirme un time-based hit sur 2 mesures cohérentes."""
        return self._fpguard.time_confirmed(resp2, elapsed1_ms, elapsed2_ms, threshold_ms)

    def idor_diff_significant(self, body_orig, body_alt, min_diff=0.20):
        """True si la diff IDOR est réelle après normalisation."""
        return self._fpguard.idor_diff_significant(body_orig, body_alt, min_diff)

    def baseline_check(self, sig_re, baseline_body):
        """True si la signature était déjà dans le baseline => FP."""
        return self._fpguard.baseline_check(sig_re, baseline_body)

    async def is_page_stable(self, url, max_diff=0.08):
        """True si la page est stable entre 2 requêtes."""
        return await self._fpguard.is_page_stable(url, max_diff=max_diff)

    # ── DedupIndex ────────────────────────────────────────────────────────────

    async def should_skip(self, url, method="GET", vuln_type=""):
        idx = self.dedup_index
        if idx is None:
            return False
        try:
            return await idx.should_skip(url, method, vuln_type)
        except Exception:
            return False

    async def mark_tested(self, url, method="GET", vuln_type=""):
        idx = self.dedup_index
        if idx is None:
            return
        try:
            await idx.mark_tested(url, method, vuln_type)
        except Exception:
            pass

    # ── PatternMemory ─────────────────────────────────────────────────────────

    def suggest_payloads(self, vuln_type, param, context="query_param",
                         endpoint_prefix="", top_n=5):
        mem = self.pattern_memory
        if mem is None:
            return []
        try:
            return mem.suggest_payloads(vuln_type=vuln_type, param=param,
                                        context=context, endpoint_prefix=endpoint_prefix,
                                        top_n=top_n)
        except Exception:
            return []

    def record_pattern_success(self, vuln_type, param, payload, url,
                                context="query_param", confidence=0.85):
        mem = self.pattern_memory
        if mem is None:
            return
        try:
            prefix = urlparse(url).path.rsplit("/", 1)[0] or "/"
            mem.record_success(vuln_type=vuln_type, param=param, payload=payload,
                               context=context, endpoint_prefix=prefix,
                               confidence=confidence)
        except Exception:
            pass

    # ── OOB Canary ────────────────────────────────────────────────────────────

    def get_canary(self, tag=""):
        oob = self.oob
        if oob is None:
            return None
        try:
            return oob.new_canary(tag=tag)
        except Exception:
            return None

    async def wait_for_oob_hit(self, canary, timeout=12.0):
        oob = self.oob
        if oob is None or canary is None:
            return []
        try:
            return await oob.wait_for_hit(canary.id, timeout=timeout)
        except Exception:
            return []

    # ── AuthContext ───────────────────────────────────────────────────────────

    def iter_profiles(self):
        ctx = self.auth_context
        if ctx is None:
            return []
        try:
            return list(ctx.profiles)
        except Exception:
            return []

    def has_multi_profile(self):
        ctx = self.auth_context
        if ctx is None:
            return False
        return ctx.has_multiple_profiles()
