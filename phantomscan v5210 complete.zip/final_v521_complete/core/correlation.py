"""
PhantomScan — Correlation Engine  (v5.7)
==========================================
Moteur de corrélation post-scan : génère des findings composites à partir de
findings individuels qui, combinés, représentent une chaîne d'exploitation
plus critique que chaque finding pris isolément.

Exemples de corrélations implémentées :
  - SSRF + S3 bucket ouvert → exfiltration de données possible
  - SQLi + credentials dans le JS → compromission complète de la DB
  - XSS + absence de CSP → exploitation sans contrainte
  - SSRF + IMDS accessible → pivot vers le rôle IAM
  - LFI + inclusion de fichiers de conf → lecture de secrets
  - OAuth misconfig + CORS open → vol de tokens OAuth
  - JWT weak + IDOR → usurpation d'identité cross-user
  - HTTP Smuggling + session fixation → hijacking de session
  - Deserialization + RCE gadgets → compromission totale serveur
  - Open redirect + phishing indicators → chaîne phishing complète
  - Path traversal + LFI → double confirmation lecture de fichiers arbitraires
  - SSTI + CMDi → RCE multi-vecteur confirmé
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable

from phantomscan.output.reporter import Finding, Severity


# ─────────────────────────── Règle de corrélation ───────────────────────────

@dataclass
class CorrelationRule:
    """
    Décrit une règle de corrélation entre N findings individuels.

    rule_id:    identifiant unique de la règle
    name:       titre du finding composite généré
    severity:   sévérité du finding composite (souvent > aux findings individuels)
    required:   liste de prédicats — chacun doit matcher au moins un finding
    description_fn: fonction qui reçoit les findings matchés et retourne la description
    remediation: recommandation de remédiation globale
    cwe:        CWE principal du finding composite
    """
    rule_id: str
    name: str
    severity: Severity
    required: list[Callable[[Finding], bool]]
    description_fn: Callable[[list[list[Finding]]], str]
    remediation: str
    cwe: str
    tags: list[str] = field(default_factory=list)


def _has_module(f: Finding, *modules: str) -> bool:
    return any(m in f.module for m in modules)


def _has_title(f: Finding, *keywords: str) -> bool:
    title_lower = f.title.lower()
    return any(kw.lower() in title_lower for kw in keywords)


def _has_severity(f: Finding, *severities: Severity) -> bool:
    return f.severity in severities


# ─────────────────────────── Catalogue de règles ────────────────────────────

CORRELATION_RULES: list[CorrelationRule] = [

    # ── SSRF + S3 bucket ouvert → exfiltration ─────────────────────────────
    CorrelationRule(
        rule_id="CORR-001",
        name="Chaîne SSRF + S3 ouvert → Exfiltration de données",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "ssrf"),
            lambda f: _has_module(f, "s3_enum") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Un SSRF ({groups[0][0].url}) combiné à un bucket S3/cloud ouvert "
            f"({groups[1][0].url}) permet une exfiltration de données via le réseau interne : "
            f"l'attaquant peut utiliser le SSRF pour accéder au bucket depuis le serveur, "
            f"contournant les ACLs IP éventuelles.\n"
            f"SSRF: {groups[0][0].title}\n"
            f"S3: {groups[1][0].title}"
        ),
        remediation=(
            "Corriger le SSRF en priorité (allowlist d'URLs). "
            "Restreindre l'accès S3 au réseau interne + rôles IAM. "
            "Activer IMDSv2 et bloquer l'accès IMDS depuis les lambdas/fonctions."
        ),
        cwe="CWE-918",
        tags=["ssrf", "s3", "exfiltration", "cloud"],
    ),

    # ── SSRF + IMDS accessible → vol de rôle IAM ───────────────────────────
    CorrelationRule(
        rule_id="CORR-002",
        name="Chaîne SSRF + IMDS → Vol de rôle IAM (privilege escalation cloud)",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "ssrf") and "imds" in f.title.lower(),
            lambda f: _has_module(f, "s3_enum", "actuator") or "iam" in f.title.lower(),
        ],
        description_fn=lambda groups: (
            f"Le SSRF atteint l'IMDS AWS ({groups[0][0].url}), permettant de récupérer "
            f"les credentials IAM temporaires du rôle EC2 attaché. Ces credentials permettent "
            f"un accès complet aux ressources AWS du compte (S3, RDS, SSM, etc.).\n"
            f"SSRF→IMDS: {groups[0][0].title}"
        ),
        remediation=(
            "Désactiver IMDSv1 immédiatement. Migrer vers IMDSv2 (token requis). "
            "Corriger le SSRF. Auditer les permissions IAM du rôle EC2 (principe de moindre privilège)."
        ),
        cwe="CWE-918",
        tags=["ssrf", "imds", "aws", "iam", "cloud"],
    ),

    # ── XSS + absence de CSP → exploitation facilitée ──────────────────────
    CorrelationRule(
        rule_id="CORR-003",
        name="XSS sans CSP → Exploitation sans contrainte",
        severity=Severity.HIGH,
        required=[
            lambda f: _has_module(f, "xss") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: "content-security-policy" in f.title.lower() or
                      ("header" in f.module and "csp" in f.description.lower()),
        ],
        description_fn=lambda groups: (
            f"Un XSS ({groups[0][0].url}) existe sans Content-Security-Policy. "
            f"L'absence de CSP permet à un attaquant d'exécuter du JS arbitraire sans "
            f"restriction : exfiltration de cookies, keylogging, redirection, "
            f"chargement de scripts externes, etc.\n"
            f"XSS: {groups[0][0].title}\n"
            f"CSP: {groups[1][0].title}"
        ),
        remediation=(
            "Déployer une CSP stricte (script-src 'nonce-...') sur toutes les pages. "
            "Corriger le XSS sous-jacent. HttpOnly sur tous les cookies de session."
        ),
        cwe="CWE-79",
        tags=["xss", "csp", "no-defense-in-depth"],
    ),

    # ── SQLi + secrets JS → compromission DB ───────────────────────────────
    CorrelationRule(
        rule_id="CORR-004",
        name="SQLi + Credentials exposés → Compromission directe de la base de données",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "sqli") and _has_severity(f, Severity.CRITICAL),
            lambda f: ("secret" in f.title.lower() or "password" in f.title.lower() or
                       "credential" in f.title.lower() or "connection string" in f.title.lower()),
        ],
        description_fn=lambda groups: (
            f"SQLi confirmée ({groups[0][0].url}) et des credentials de base de données "
            f"sont exposés ({groups[1][0].url}). Un attaquant peut combiner les deux : "
            f"extraire les données via SQLi ET se connecter directement à la DB si accessible.\n"
            f"SQLi: {groups[0][0].title}\n"
            f"Credentials: {groups[1][0].title}"
        ),
        remediation=(
            "Révoquer immédiatement les credentials exposés. "
            "Corriger le SQLi (requêtes paramétrées). "
            "Auditer les logs de la base de données pour détecter un accès anormal."
        ),
        cwe="CWE-89",
        tags=["sqli", "credentials", "database"],
    ),

    # ── OAuth misconfig + CORS open → vol de token ──────────────────────────
    CorrelationRule(
        rule_id="CORR-005",
        name="OAuth misconfig + CORS ouvert → Vol de tokens OAuth",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "oauth"),
            lambda f: _has_module(f, "cors") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Une misconfiguration OAuth ({groups[0][0].url}) combinée à un CORS ouvert "
            f"({groups[1][0].url}) permet à un site malveillant de voler des tokens OAuth : "
            f"le redirect_uri ouvert permet de récupérer le code, le CORS permet de l'échanger "
            f"depuis un domaine tiers.\n"
            f"OAuth: {groups[0][0].title}\n"
            f"CORS: {groups[1][0].title}"
        ),
        remediation=(
            "Restreindre redirect_uri à des URLs exactes en allowlist. "
            "Implémenter PKCE pour les clients publics. "
            "Restreindre CORS aux domaines légitimes uniquement."
        ),
        cwe="CWE-601",
        tags=["oauth", "cors", "token-theft"],
    ),

    # ── JWT weak + IDOR → usurpation cross-user ─────────────────────────────
    CorrelationRule(
        rule_id="CORR-006",
        name="JWT vulnérable + IDOR → Usurpation d'identité cross-user",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "jwt") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: _has_module(f, "idor") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Un JWT vulnérable ({groups[0][0].url}) permet de forger des tokens pour n'importe "
            f"quel userId, et un IDOR ({groups[1][0].url}) confirme que les IDs numériques sont "
            f"prédictibles. Combinés, l'attaquant peut accéder aux données de tout utilisateur.\n"
            f"JWT: {groups[0][0].title}\n"
            f"IDOR: {groups[1][0].title}"
        ),
        remediation=(
            "Signer les JWT avec RS256/ES256 (asymétrique). Rejeter alg:none. "
            "Implémenter une vérification d'ownership côté serveur sur chaque endpoint."
        ),
        cwe="CWE-287",
        tags=["jwt", "idor", "auth", "identity"],
    ),

    # ── HTTP Smuggling + XSS → hijacking de session ──────────────────────────
    CorrelationRule(
        rule_id="CORR-007",
        name="HTTP Smuggling + XSS → Cache empoisonné / Session hijacking",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "http_smuggling"),
            lambda f: _has_module(f, "xss", "cache_poison"),
        ],
        description_fn=lambda groups: (
            f"HTTP Request Smuggling ({groups[0][0].url}) combiné à XSS ou cache poisoning "
            f"({groups[1][0].url}) permet d'injecter du contenu malveillant dans le cache "
            f"partagé, affectant tous les utilisateurs qui reçoivent la réponse empoisonnée.\n"
            f"Smuggling: {groups[0][0].title}\n"
            f"XSS/Cache: {groups[1][0].title}"
        ),
        remediation=(
            "Mettre à jour le reverse proxy/load balancer (Nginx, HAProxy). "
            "Normaliser les headers Content-Length et Transfer-Encoding. "
            "Désactiver le keep-alive entre le proxy et le backend si possible."
        ),
        cwe="CWE-444",
        tags=["smuggling", "xss", "cache", "session"],
    ),

    # ── Deserialization + CMDi → RCE confirmé ──────────────────────────────
    CorrelationRule(
        rule_id="CORR-008",
        name="Désérialisation non sécurisée + CMDi → RCE multi-vecteur",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "deserialization"),
            lambda f: _has_module(f, "cmdi") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Désérialisation non sécurisée ({groups[0][0].url}) et injection de commandes "
            f"({groups[1][0].url}) sont toutes deux présentes. L'application est vulnérable "
            f"à la RCE via au moins deux vecteurs indépendants — la surface d'attaque est maximale.\n"
            f"Deserial: {groups[0][0].title}\n"
            f"CMDi: {groups[1][0].title}"
        ),
        remediation=(
            "Corriger la désérialisation (ne pas désérialiser de données non fiables). "
            "Corriger le CMDi (utiliser des APIs OS sécurisées). "
            "Isoler l'application dans un container avec des capabilities réduites."
        ),
        cwe="CWE-502",
        tags=["deserialization", "cmdi", "rce", "critical"],
    ),

    # ── Path Traversal + LFI → lecture de fichiers arbitraires ─────────────
    CorrelationRule(
        rule_id="CORR-009",
        name="Path Traversal + LFI → Lecture de fichiers arbitraires confirmée (double vecteur)",
        severity=Severity.HIGH,
        required=[
            lambda f: _has_module(f, "path_traversal") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: _has_module(f, "lfi") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Path traversal ({groups[0][0].url}) et LFI ({groups[1][0].url}) toutes deux "
            f"confirmées. L'attaquant peut lire des fichiers arbitraires via deux vecteurs "
            f"distincts : chemins relatifs ET inclusion de fichiers. Risque de lecture de "
            f"/etc/passwd, .env, configurations, clés privées.\n"
            f"Path Traversal: {groups[0][0].title}\n"
            f"LFI: {groups[1][0].title}"
        ),
        remediation=(
            "Valider et canonicaliser tous les chemins (realpath + vérification du préfixe autorisé). "
            "Ne jamais passer des inputs utilisateur à include/require/open sans validation stricte."
        ),
        cwe="CWE-22",
        tags=["lfi", "path-traversal", "file-read"],
    ),

    # ── SSTI + CMDi → RCE confirmé multi-moteur ─────────────────────────────
    CorrelationRule(
        rule_id="CORR-010",
        name="SSTI + CMDi → RCE multi-moteur",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "ssti") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: _has_module(f, "cmdi") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Server-Side Template Injection ({groups[0][0].url}) et CMDi "
            f"({groups[1][0].url}) toutes deux confirmées. L'application est vulnérable "
            f"à la RCE via des vecteurs différents — exécution de code arbitraire garantie.\n"
            f"SSTI: {groups[0][0].title}\n"
            f"CMDi: {groups[1][0].title}"
        ),
        remediation=(
            "Ne jamais interpoler des inputs utilisateur dans des templates. "
            "Utiliser des APIs OS sécurisées (subprocess avec liste d'arguments). "
            "Mettre en place un WAF, une isolation du processus serveur, et des alertes d'intégrité."
        ),
        cwe="CWE-94",
        tags=["ssti", "cmdi", "rce", "critical"],
    ),

    # ── Open redirect + XSS → phishing avancé ──────────────────────────────
    CorrelationRule(
        rule_id="CORR-011",
        name="Open Redirect + XSS → Chaîne phishing / Account takeover",
        severity=Severity.HIGH,
        required=[
            lambda f: _has_module(f, "redirect"),
            lambda f: _has_module(f, "xss") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Open redirect ({groups[0][0].url}) + XSS ({groups[1][0].url}) : "
            f"un attaquant peut envoyer un lien légitime (domaine de la cible) qui redirige "
            f"vers une page malveillante, puis utiliser le XSS pour voler la session avant "
            f"la redirection.\n"
            f"Redirect: {groups[0][0].title}\n"
            f"XSS: {groups[1][0].title}"
        ),
        remediation=(
            "Supprimer ou restreindre l'open redirect à une allowlist de destinations. "
            "Corriger le XSS. Implémenter SameSite=Strict sur les cookies de session."
        ),
        cwe="CWE-601",
        tags=["redirect", "xss", "phishing", "account-takeover"],
    ),

    # ── LFI + secrets exposés → credential dump ─────────────────────────────
    CorrelationRule(
        rule_id="CORR-012",
        name="LFI + Secrets exposés → Dump de credentials via lecture de fichiers",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "lfi") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: any(kw in f.title.lower() for kw in
                         ["secret", "password", "api key", "token", "credential", "aws"]),
        ],
        description_fn=lambda groups: (
            f"LFI confirmée ({groups[0][0].url}) et des secrets/credentials sont exposés "
            f"({groups[1][0].url}). Via le LFI, l'attaquant peut lire des fichiers de "
            f"configuration (.env, config.php, database.yml) contenant des credentials en clair.\n"
            f"LFI: {groups[0][0].title}\n"
            f"Secrets: {groups[1][0].title}"
        ),
        remediation=(
            "Corriger le LFI (valider les chemins). "
            "Déplacer les secrets dans un gestionnaire de secrets (Vault, AWS SSM). "
            "Révoquer tous les credentials potentiellement exposés."
        ),
        cwe="CWE-73",
        tags=["lfi", "secrets", "credentials", "file-read"],
    ),

    # ── File Upload + LFI → Webshell / RCE ──────────────────────────────────
    CorrelationRule(
        rule_id="CORR-013",
        name="File Upload non filtré + LFI → Webshell / RCE",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "file_upload") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: _has_module(f, "lfi") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Un upload de fichier non filtré ({groups[0][0].url}) combiné à un LFI "
            f"({groups[1][0].url}) permet de déployer un webshell : l'attaquant upload "
            f"un fichier PHP/JSP malveillant, puis l'inclut via le LFI pour obtenir une RCE.\n"
            f"Upload: {groups[0][0].title}\n"
            f"LFI: {groups[1][0].title}"
        ),
        remediation=(
            "Valider strictement le type MIME et l'extension des fichiers uploadés. "
            "Stocker les uploads hors du webroot (ou dans un bucket isolé). "
            "Corriger le LFI. Désactiver l'exécution de scripts dans le répertoire d'upload."
        ),
        cwe="CWE-434",
        tags=["file-upload", "lfi", "rce", "webshell", "critical"],
    ),

    # ── Prototype Pollution + XSS DOM → RCE navigateur ──────────────────────
    CorrelationRule(
        rule_id="CORR-014",
        name="Prototype Pollution + DOM XSS → RCE navigateur garanti",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "prototype_pollution") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: _has_module(f, "xss", "dom_xss") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Prototype pollution ({groups[0][0].url}) + XSS/DOM XSS ({groups[1][0].url}) : "
            f"l'attaquant peut polluer Object.prototype pour injecter des propriétés arbitraires "
            f"utilisées dans des sinks DOM (innerHTML, eval, document.write), transformant "
            f"une pollution bénigne en XSS sans user interaction supplémentaire.\n"
            f"Prototype Pollution: {groups[0][0].title}\n"
            f"XSS: {groups[1][0].title}"
        ),
        remediation=(
            "Geler Object.prototype (Object.freeze) côté client. "
            "Utiliser Object.create(null) pour les objets de configuration. "
            "Corriger le XSS sous-jacent. Auditer les librairies JS tierces (lodash < 4.17.21)."
        ),
        cwe="CWE-1321",
        tags=["prototype-pollution", "xss", "dom", "rce-browser"],
    ),

    # ── NoSQL Injection + Auth Bypass → Account Takeover ────────────────────
    CorrelationRule(
        rule_id="CORR-015",
        name="NoSQL Injection + Auth Bypass → Account Takeover sans credentials",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "nosql_injection") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: _has_module(f, "auth_bypass") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Injection NoSQL ({groups[0][0].url}) + bypass d'authentification "
            f"({groups[1][0].url}) : l'attaquant peut s'authentifier comme n'importe quel "
            f"utilisateur sans connaître son mot de passe en injectant des opérateurs MongoDB "
            f"($ne, $gt, $regex) dans le champ de login.\n"
            f"NoSQL: {groups[0][0].title}\n"
            f"Auth Bypass: {groups[1][0].title}"
        ),
        remediation=(
            "Valider et typer strictement les inputs (rejeter les objets JSON non attendus). "
            "Utiliser des requêtes préparées / ODM avec schéma strict. "
            "Corriger le bypass d'auth (vérification de mot de passe côté serveur obligatoire)."
        ),
        cwe="CWE-943",
        tags=["nosql", "auth-bypass", "account-takeover", "critical"],
    ),

    # ── SSRF + Redis interne → RCE via RESP protocol ─────────────────────────
    CorrelationRule(
        rule_id="CORR-016",
        name="SSRF + Redis interne accessible → RCE via RESP protocol",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "ssrf") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: (
                ("redis" in f.title.lower() or "redis" in f.description.lower()) or
                (_has_module(f, "port_scan") and "6379" in f.evidence)
            ),
        ],
        description_fn=lambda groups: (
            f"SSRF ({groups[0][0].url}) + Redis interne détecté ({groups[1][0].url}) : "
            f"l'attaquant peut envoyer des commandes Redis via le protocole RESP en exploitant "
            f"le SSRF (gopher:// ou dict://). Si Redis tourne en root, cela permet une RCE "
            f"complète via l'écriture d'une crontab ou d'une clé SSH autorisée.\n"
            f"SSRF: {groups[0][0].title}\n"
            f"Redis: {groups[1][0].title}"
        ),
        remediation=(
            "Corriger le SSRF (bloquer gopher://, dict://, file:// dans l'allowlist). "
            "Protéger Redis par authentification (requirepass) et bind uniquement sur 127.0.0.1. "
            "Ne pas exécuter Redis en tant que root."
        ),
        cwe="CWE-918",
        tags=["ssrf", "redis", "rce", "internal-network", "critical"],
    ),

    # ── Race Condition + File Upload → TOCTOU / Webshell ────────────────────
    CorrelationRule(
        rule_id="CORR-017",
        name="Race Condition + File Upload → TOCTOU / Bypass de validation",
        severity=Severity.HIGH,
        required=[
            lambda f: _has_module(f, "race_condition") and _has_severity(f, Severity.MEDIUM, Severity.HIGH, Severity.CRITICAL),
            lambda f: _has_module(f, "file_upload") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Race condition ({groups[0][0].url}) + upload de fichier non sécurisé "
            f"({groups[1][0].url}) : pendant la fenêtre TOCTOU entre le dépôt du fichier "
            f"et sa validation/suppression, l'attaquant peut accéder au fichier malveillant "
            f"et déclencher son exécution (webshell, script malveillant).\n"
            f"Race Condition: {groups[0][0].title}\n"
            f"File Upload: {groups[1][0].title}"
        ),
        remediation=(
            "Effectuer la validation avant d'écrire le fichier dans un emplacement accessible. "
            "Utiliser des noms de fichiers temporaires non prédictibles pendant la validation. "
            "Traiter les uploads dans un répertoire isolé et déplacer atomiquement après validation."
        ),
        cwe="CWE-367",
        tags=["race-condition", "file-upload", "toctou", "webshell"],
    ),

    # v5.11 ── IDOR + Auth Bypass → Accès cross-account sans authentification ─
    CorrelationRule(
        rule_id="CORR-013",
        name="IDOR + Auth Bypass → Accès cross-account non authentifié",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "idor") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: _has_module(f, "auth_bypass") or _has_title(f, "auth bypass", "authentification contournée", "401 bypass", "403 bypass"),
        ],
        description_fn=lambda groups: (
            f"Un IDOR ({groups[0][0].url}) combiné à un contournement d'authentification "
            f"({groups[1][0].url}) permet à un attaquant non authentifié d'accéder aux "
            f"ressources d'autres utilisateurs. La chaîne : (1) bypass l'auth, "
            f"(2) exploite l'IDOR pour accéder à n'importe quel objet.\n"
            f"IDOR: {groups[0][0].title}\n"
            f"Auth bypass: {groups[1][0].title}"
        ),
        remediation=(
            "Corriger le bypass d'authentification en priorité (vérification session obligatoire). "
            "Ajouter une vérification d'autorisation côté serveur pour chaque ressource (ABAC/PBAC). "
            "Ne jamais faire confiance aux IDs fournis côté client sans validation de propriété."
        ),
        cwe="CWE-639",
        tags=["idor", "auth-bypass", "unauthenticated-access", "account-takeover"],
    ),

    # v5.11 ── Rate Limit absent + IDOR → Énumération massive d'objets ─────────
    CorrelationRule(
        rule_id="CORR-014",
        name="Absence de Rate Limit + IDOR → Énumération massive d'objets (BOLA at scale)",
        severity=Severity.HIGH,
        required=[
            lambda f: _has_module(f, "idor") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: _has_module(f, "rate_limit") or _has_title(f, "rate limit", "rate-limit", "pas de rate", "no rate"),
        ],
        description_fn=lambda groups: (
            f"Un IDOR confirmé ({groups[0][0].url}) sans protection rate limit "
            f"({groups[1][0].url}) permet une énumération automatisée et massive de toutes "
            f"les ressources : un attaquant peut itérer sur des milliers d'IDs en quelques "
            f"secondes pour exfiltrer l'intégralité de la base utilisateurs/documents.\n"
            f"IDOR: {groups[0][0].title}\n"
            f"Rate limit: {groups[1][0].title}"
        ),
        remediation=(
            "Implémenter un rate limiting strict sur tous les endpoints sensibles (≤60 req/min par IP/token). "
            "Utiliser des identifiants non-séquentiels (UUID v4). "
            "Mettre en place une détection d'anomalie sur les accès multi-ressources rapides."
        ),
        cwe="CWE-639",
        tags=["idor", "rate-limit", "enumeration", "bola", "mass-data-exposure"],
    ),

    # v5.11 ── JWT faible + BOLA → Usurpation d'identité ciblée ────────────────
    CorrelationRule(
        rule_id="CORR-015",
        name="JWT faible + BOLA → Usurpation d'identité multi-utilisateurs",
        severity=Severity.CRITICAL,
        required=[
            lambda f: (_has_module(f, "jwt", "jwt_advanced") and
                       _has_severity(f, Severity.HIGH, Severity.CRITICAL) and
                       any(kw in f.title.lower() for kw in ["alg:none", "weak", "forged", "hs256", "brute"])),
            lambda f: _has_module(f, "idor") and "bola" in f.title.lower(),
        ],
        description_fn=lambda groups: (
            f"Un JWT forgeable/faible ({groups[0][0].url}) combiné à un BOLA REST "
            f"({groups[1][0].url}) permet à un attaquant de forger des tokens pour "
            f"n'importe quel user_id et d'accéder à toutes leurs ressources sans connaître "
            f"leurs credentials : compromission totale de la confidentialité de l'application.\n"
            f"JWT: {groups[0][0].title}\n"
            f"BOLA: {groups[1][0].title}"
        ),
        remediation=(
            "Remplacer HS256 par RS256/ES256 avec clé asymétrique. "
            "Désactiver l'algorithme 'none'. "
            "Valider côté serveur que le sub/user_id du JWT correspond à la ressource demandée. "
            "Implémenter une rotation des clés et un système de révocation de tokens."
        ),
        cwe="CWE-345",
        tags=["jwt", "bola", "idor", "identity-spoofing", "account-takeover"],
    ),

    # v5.11 ── Prototype Pollution + XSS → Escalade vers RCE côté client ───────
    CorrelationRule(
        rule_id="CORR-016",
        name="Prototype Pollution + XSS → Escalade vers exécution JS arbitraire (gadget chain)",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "prototype_pollution") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: _has_module(f, "xss", "dom_xss") and _has_severity(f, Severity.MEDIUM, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Une Prototype Pollution ({groups[0][0].url}) combinée à un XSS "
            f"({groups[1][0].url}) forme une gadget chain : la pollution permet d'injecter "
            f"des propriétés héritées dans tous les objets, amplifiant le XSS en "
            f"exécution arbitraire de code JS depuis n'importe quel contexte de l'application "
            f"(contournement de CSP basé sur les nonces, hijacking des event handlers, etc.).\n"
            f"Prototype Pollution: {groups[0][0].title}\n"
            f"XSS: {groups[1][0].title}"
        ),
        remediation=(
            "Freezer Object.prototype (Object.freeze) côté serveur et client. "
            "Sanitizer les clés des objets créés depuis des données utilisateur (__proto__, constructor, prototype). "
            "Utiliser Object.create(null) pour les maps/dictionnaires côté applicatif. "
            "Déployer une CSP stricte avec nonces dynamiques pour mitiger le XSS résiduel."
        ),
        cwe="CWE-1321",
        tags=["prototype-pollution", "xss", "gadget-chain", "csp-bypass"],
    ),
    CorrelationRule(
        rule_id="CORR-017",
        name="CORS permissif + OAuth misconfig → Vol de token OAuth (Account Takeover)",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "cors") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: _has_module(f, "oauth_misconfig") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Un CORS trop permissif ({groups[0][0].url}) combiné à une misconfiguration OAuth "
            f"({groups[1][0].url}) permet à un attaquant d'héberger une page malveillante qui "
            f"déclenche le flux OAuth depuis le navigateur de la victime, puis exfiltre le "
            f"code/token via une requête cross-origin autorisée par la politique CORS. "
            f"Résultat : account takeover complet sans interaction visible.\\n"
            f"CORS: {groups[0][0].title}\\n"
            f"OAuth: {groups[1][0].title}"
        ),
        remediation=(
            "Restreindre Access-Control-Allow-Origin à la liste exacte des origines légitimes. "
            "Valider le redirect_uri OAuth contre une allowlist stricte côté serveur. "
            "Utiliser PKCE obligatoire pour tous les clients publics. "
            "Lier les codes d'autorisation à l'IP + User-Agent de la session."
        ),
        cwe="CWE-942",
        tags=["cors", "oauth", "account-takeover", "token-theft"],
    ),

    # ── CORR-018 : XSS + absence CSP → exfiltration cookies/tokens ─────────
    CorrelationRule(
        rule_id="CORR-018",
        name="XSS + Absence de CSP → Exfiltration de session (Account Takeover sans contrainte)",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "xss", "dom_xss") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: (
                _has_module(f, "headers") and
                any(kw in f.title.lower() for kw in ["csp", "content-security-policy", "content security policy"])
            ),
        ],
        description_fn=lambda groups: (
            f"Un XSS confirmé ({groups[0][0].url}) en l'absence de Content-Security-Policy "
            f"({groups[1][0].url}) est exploitable sans aucune contrainte : "
            f"l'attaquant peut charger des scripts externes, exfiltrer les cookies/tokens vers "
            f"un serveur tiers, effectuer des requêtes authentifiées pour le compte de la victime. "
            f"Sans CSP, aucun mécanisme de défense en profondeur n'est en place.\\n"
            f"XSS: {groups[0][0].title}\\n"
            f"CSP: {groups[1][0].title}"
        ),
        remediation=(
            "Déployer une CSP stricte avec nonces dynamiques par requête : "
            "Content-Security-Policy: default-src 'none'; script-src 'nonce-{random}'; "
            "Corriger le XSS à la source (contextual output encoding). "
            "Ajouter HttpOnly + Secure + SameSite=Strict sur les cookies de session."
        ),
        cwe="CWE-79",
        tags=["xss", "csp", "session-hijacking", "account-takeover"],
    ),

    # ── CORR-019 : LFI + log poisoning → RCE ───────────────────────────────
    CorrelationRule(
        rule_id="CORR-019",
        name="LFI + Log Poisoning → RCE via inclusion de log contaminé",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "lfi") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: (
                _has_module(f, "headers", "xss") and
                any(kw in f.title.lower() for kw in ["user-agent", "injection", "header injection", "log"])
            ) or (
                _has_module(f, "lfi") and
                any(kw in f.evidence.lower() for kw in ["/var/log", "/proc/self", "access.log", "error.log"])
            ),
        ],
        description_fn=lambda groups: (
            f"Un LFI ({groups[0][0].url}) capable de lire les logs serveur combiné à une "
            f"possibilité de pollution de headers ({groups[1][0].url}) forme une chaîne "
            f"LFI + Log Poisoning → RCE : (1) injecter du code PHP dans un header "
            f"(ex: User-Agent: <?php system($_GET['c']); ?>) pour qu'il soit écrit dans "
            f"access.log, (2) inclure le log via le LFI pour exécuter le code.\\n"
            f"LFI: {groups[0][0].title}\\n"
            f"Header/Log: {groups[1][0].title}"
        ),
        remediation=(
            "Corriger le LFI : utiliser une allowlist de fichiers, jamais de chemins fournis par l'utilisateur. "
            "Désactiver l'accès aux logs applicatifs depuis le web root. "
            "Encoder les entrées utilisateur avant de les écrire dans les logs. "
            "Utiliser open_basedir pour restreindre les inclusions PHP à un répertoire."
        ),
        cwe="CWE-98",
        tags=["lfi", "log-poisoning", "rce", "php"],
    ),

    # ── CORR-020 : SQLi + credentials dans JS → compromise DB complète ──────
    CorrelationRule(
        rule_id="CORR-020",
        name="SQLi + Credentials hardcodés dans JS → Compromission complète de la base de données",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "sqli") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: (
                _has_module(f, "api_key_exposure", "secrets_finder", "js_analyzer") and
                any(kw in f.title.lower() for kw in ["password", "credential", "database", "db_pass", "mysql", "postgres"])
            ),
        ],
        description_fn=lambda groups: (
            f"Un SQLi exploitable ({groups[0][0].url}) combiné à des credentials de base de données "
            f"exposés dans des fichiers JS/config ({groups[1][0].url}) donne accès complet "
            f"à la base : l'attaquant peut (1) utiliser les credentials pour se connecter "
            f"directement à la DB si le port est exposé, ou (2) via le SQLi exfiltrer/modifier "
            f"l'intégralité des données. Les deux vecteurs se renforcent mutuellement.\\n"
            f"SQLi: {groups[0][0].title}\\n"
            f"Credentials: {groups[1][0].title}"
        ),
        remediation=(
            "Corriger le SQLi avec des requêtes paramétrées (prepared statements). "
            "Supprimer immédiatement les credentials du code source et invalider les secrets exposés. "
            "Utiliser des variables d'environnement ou un gestionnaire de secrets (Vault, AWS Secrets Manager). "
            "Restreindre l'accès DB au réseau interne uniquement (pas d'exposition publique)."
        ),
        cwe="CWE-89",
        tags=["sqli", "credentials", "database", "data-breach"],
    ),

    # ── CORR-021 : SSRF + Redis/Memcached → RCE via protocole interne ───────
    CorrelationRule(
        rule_id="CORR-021",
        name="SSRF + Service Cache Interne exposé → RCE via protocole Redis/Memcached",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "ssrf") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: (
                any(kw in f.title.lower() for kw in ["redis", "memcached", "gopher", "dict://", "port 6379", "port 11211"])
            ),
        ],
        description_fn=lambda groups: (
            f"Un SSRF ({groups[0][0].url}) avec accès aux services internes permet d'interagir "
            f"via les protocoles gopher:// ou dict:// avec Redis/Memcached non authentifiés "
            f"({groups[1][0].url}). Chaîne d'exploitation : SSRF → écriture de cron job ou "
            f"clé SSH dans Redis → RCE sur le serveur. "
            f"Particulièrement critique si le service interne tourne en root.\\n"
            f"SSRF: {groups[0][0].title}\\n"
            f"Service interne: {groups[1][0].title}"
        ),
        remediation=(
            "Bloquer les requêtes SSRF vers les ranges IP internes (169.254.x.x, 10.x.x.x, 172.16-31.x.x, 127.x.x.x). "
            "Implémenter une allowlist stricte d'URLs pour les fonctionnalités fetch/proxy. "
            "Protéger Redis/Memcached par authentification (requirepass) et bind sur 127.0.0.1. "
            "Déployer un WAF de sortie (egress filtering) sur le réseau interne."
        ),
        cwe="CWE-918",
        tags=["ssrf", "redis", "rce", "internal-service", "gopher"],
    ),

    # ── CORR-022 : Host Header Injection + Password Reset → Account Takeover ─
    CorrelationRule(
        rule_id="CORR-022",
        name="Host Header Injection + Password Reset → Account Takeover via reset poisoning",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "host_header_injection") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: (
                any(kw in f.url.lower() for kw in ["reset", "forgot", "password", "recover"]) or
                any(kw in f.title.lower() for kw in ["reset", "forgot-password", "password reset"])
            ),
        ],
        description_fn=lambda groups: (
            f"Une injection du header Host ({groups[0][0].url}) sur un endpoint de réinitialisation "
            f"de mot de passe ({groups[1][0].url}) permet le 'Password Reset Poisoning' : "
            f"l'attaquant injecte son propre domaine dans le header Host, ce qui fait que "
            f"le lien de reset envoyé par email à la victime pointe vers le serveur de l'attaquant. "
            f"Quand la victime clique → le token de reset est volé → account takeover.\\n"
            f"Host Injection: {groups[0][0].title}\\n"
            f"Reset endpoint: {groups[1][0].title}"
        ),
        remediation=(
            "Construire les URLs de reset à partir de la configuration serveur (SERVER_NAME fixe), "
            "jamais depuis le header Host de la requête entrante. "
            "Valider et normaliser le header Host contre une allowlist de domaines autorisés. "
            "Configurer les virtual hosts pour rejeter les requêtes avec des Host headers non reconnus."
        ),
        cwe="CWE-640",
        tags=["host-header", "password-reset", "account-takeover", "reset-poisoning"],
    ),

    # ── CORR-023 : Open Redirect + Phishing + OAuth → Account Takeover P1 ───
    CorrelationRule(
        rule_id="CORR-023",
        name="Open Redirect + OAuth → Chaîne Account Takeover (P1 Bug Bounty)",
        severity=Severity.CRITICAL,
        required=[
            lambda f: (
                _has_module(f, "open_redirect_chain", "open_redirect") and
                _has_severity(f, Severity.HIGH, Severity.CRITICAL)
            ),
            lambda f: _has_module(f, "oauth_misconfig") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Un open redirect confirmé ({groups[0][0].url}) utilisé comme redirect_uri dans un "
            f"flux OAuth misconfiguré ({groups[1][0].url}) permet un account takeover complet : "
            f"(1) l'attaquant forge un lien OAuth avec redirect_uri pointant vers l'open redirect, "
            f"(2) le serveur OAuth valide uniquement le domaine racine (pas le chemin), "
            f"(3) après authentification, le code/token est redirigé vers le contrôle de l'attaquant. "
            f"Ce pattern est classé P1 sur la majorité des programmes de bug bounty.\\n"
            f"Open Redirect: {groups[0][0].title}\\n"
            f"OAuth: {groups[1][0].title}"
        ),
        remediation=(
            "Valider le redirect_uri OAuth par correspondance exacte (pas de matching partiel de domaine). "
            "Éliminer tous les open redirects du périmètre OAuth. "
            "Implémenter PKCE pour prévenir le vol de code d'autorisation. "
            "Logger et alerter sur toute utilisation de redirect_uri hors allowlist."
        ),
        cwe="CWE-601",
        tags=["open-redirect", "oauth", "account-takeover", "p1", "bug-bounty"],
    ),

    # ── CORR-024 : Dependency Confusion + CI/CD Exposed → Supply Chain RCE ──
    CorrelationRule(
        rule_id="CORR-024",
        name="Dependency Confusion + CI/CD Exposé → Compromission Supply Chain (RCE sur pipeline)",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "dependency_confusion") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: (
                _has_module(f, "exposed_panels") and
                any(kw in f.title.lower() for kw in ["jenkins", "gitlab", "github", "ci/cd", "drone", "argocd", "concourse", "pipeline"])
            ),
        ],
        description_fn=lambda groups: (
            f"Une vulnérabilité de Dependency Confusion ({groups[0][0].url}) combinée à un "
            f"pipeline CI/CD exposé ({groups[1][0].url}) forme une chaîne d'attaque supply chain : "
            f"(1) l'attaquant publie un paquet malveillant sur le registre public avec le nom "
            f"du paquet interne découvert, (2) le pipeline CI/CD télécharge la version malveillante "
            f"lors du build, (3) exécution de code arbitraire dans l'environnement de build "
            f"avec accès potentiel aux secrets, tokens de déploiement et artefacts de production.\\n"
            f"Dependency Confusion: {groups[0][0].title}\\n"
            f"CI/CD: {groups[1][0].title}"
        ),
        remediation=(
            "Configurer le gestionnaire de paquets pour préférer toujours le registre privé "
            "(scoping, pinning de version, hash integrity). "
            "Protéger l'accès au CI/CD par authentification forte + MFA. "
            "Isoler l'environnement de build (pas d'accès Internet sortant non filtré). "
            "Utiliser des signatures de paquets (sigstore/cosign) pour valider les artefacts."
        ),
        cwe="CWE-427",
        tags=["dependency-confusion", "supply-chain", "ci-cd", "rce", "pipeline"],
    ),
]


# ─────────────────────────── Correlation Engine ──────────────────────────────

class CorrelationEngine:
    """
    Moteur de corrélation post-scan.

    Usage :
        engine = CorrelationEngine()
        composite_findings = engine.correlate(findings)
        all_findings = findings + composite_findings
    """

    def __init__(self, rules: list[CorrelationRule] | None = None) -> None:
        self._rules = rules or CORRELATION_RULES

    def correlate(self, findings: list[Finding]) -> list[Finding]:
        """
        Analyse les findings individuels et génère des findings composites
        pour toutes les règles qui matchent.

        Returns:
            liste de findings composites (peut être vide)
        """
        composite: list[Finding] = []
        seen_rules: set[str] = set()

        for rule in self._rules:
            matched_groups = self._match_rule(rule, findings)
            if matched_groups is None:
                continue
            if rule.rule_id in seen_rules:
                continue
            seen_rules.add(rule.rule_id)

            # Générer la description avec les findings concrets
            description = rule.description_fn(matched_groups)

            # URL du finding composite = URL du premier finding
            url = matched_groups[0][0].url

            # Evidence = liste des finding titles impliqués
            evidence_parts = []
            for i, group in enumerate(matched_groups):
                for f in group:
                    evidence_parts.append(f"[{i+1}] {f.title} @ {f.url}")
            evidence = "\n".join(evidence_parts)

            composite.append(Finding(
                title=f"[COMPOSITE] {rule.name}",
                severity=rule.severity,
                url=url,
                module="correlation",
                description=(
                    f"[{rule.rule_id}] Chaîne d'exploitation détectée par corrélation de findings.\n\n"
                    + description
                ),
                evidence=evidence,
                cwe=rule.cwe,
                remediation=rule.remediation,
            ))

        return composite

    def _match_rule(
        self, rule: CorrelationRule, findings: list[Finding]
    ) -> list[list[Finding]] | None:
        """
        Vérifie si tous les prédicats de la règle matchent au moins un finding.

        Returns:
            liste de groupes (un groupe par prédicat) si tous matchent, None sinon
        """
        matched_groups: list[list[Finding]] = []

        for predicate in rule.required:
            matched = [f for f in findings if predicate(f)]
            if not matched:
                return None
            matched_groups.append(matched)

        # Vérifier qu'on n'utilise pas le même finding pour deux prédicats différents
        # (évite de corréler un finding avec lui-même)
        all_matched_ids = [id(f) for group in matched_groups for f in group]
        if len(set(all_matched_ids)) < len(rule.required):
            return None

        return matched_groups


# ═══════════════════════════════════════════════════════════════════════════════
# v5.18 — 6 nouvelles règles de corrélation (CORR-025 à CORR-030)
# ═══════════════════════════════════════════════════════════════════════════════

CORRELATION_RULES.extend([

    # ── LFI + Log Poisoning → RCE ───────────────────────────────────────────
    CorrelationRule(
        rule_id="CORR-025",
        name="LFI + Logs accessibles → Log Poisoning → RCE",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "lfi") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: _has_module(f, "lfi", "path_traversal") and any(
                kw in f.description.lower() for kw in ["/var/log", "access.log", "error.log", "apache", "nginx"]
            ),
        ],
        description_fn=lambda groups: (
            f"Un LFI ({groups[0][0].url}) peut inclure des fichiers de log accessibles. "
            f"En injectant du code PHP/Python dans les User-Agent ou dans des paramètres "
            f"loggés par le serveur, puis en incluant le log via LFI, on obtient une RCE complète.\n"
            f"LFI: {groups[0][0].title}\n"
            f"Log: {groups[1][0].title}"
        ),
        remediation=(
            "Désactiver l'inclusion de fichiers système via LFI (open_basedir). "
            "Restreindre les permissions sur les répertoires de logs. "
            "Utiliser des chemins absolus hardcodés côté serveur."
        ),
        cwe="CWE-98",
        tags=["lfi", "log-poisoning", "rce", "php"],
    ),

    # ── SSTI + CMDi sur même endpoint → RCE multi-vecteur ──────────────────
    CorrelationRule(
        rule_id="CORR-026",
        name="SSTI + CMDi → RCE Multi-vecteur confirmé",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "ssti") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: _has_module(f, "cmdi") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"SSTI ({groups[0][0].url}) et CMDi ({groups[1][0].url}) confirmés. "
            f"Deux vecteurs d'exécution de code distincts sur la même application. "
            f"Si l'un est patché sans l'autre, la RCE reste possible. "
            f"Probabilité de compromission totale du serveur: critique.\n"
            f"SSTI: {groups[0][0].title}\nCMDi: {groups[1][0].title}"
        ),
        remediation=(
            "Patcher les deux vecteurs en parallèle — le patch partiel laisse l'app compromise. "
            "Auditer tous les templates et toutes les fonctions d'exécution système. "
            "Déployer une sandbox (seccomp, AppArmor) pour limiter les dégâts."
        ),
        cwe="CWE-94",
        tags=["ssti", "cmdi", "rce", "critical-chain"],
    ),

    # ── Mass Assignment + IDOR → Privilege Escalation ──────────────────────
    CorrelationRule(
        rule_id="CORR-027",
        name="Mass Assignment + IDOR → Escalade de Privilèges",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "mass_assignment"),
            lambda f: _has_module(f, "idor") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Mass Assignment ({groups[0][0].url}) permet d'injecter des champs arbitraires "
            f"(ex: `role=admin`, `is_admin=true`). Combiné à un IDOR ({groups[1][0].url}) "
            f"permettant d'agir sur d'autres comptes, l'attaquant peut escalader ses privilèges "
            f"sur n'importe quel compte utilisateur → compromission de comptes admin.\n"
            f"Mass Assignment: {groups[0][0].title}\nIDOR: {groups[1][0].title}"
        ),
        remediation=(
            "Utiliser une allowlist stricte des champs acceptés (DTO pattern). "
            "Ne jamais exposer `role`, `is_admin`, `permissions` dans les endpoints publics. "
            "Corriger l'IDOR : valider que l'utilisateur est propriétaire de la ressource."
        ),
        cwe="CWE-915",
        tags=["mass-assignment", "idor", "privilege-escalation"],
    ),

    # ── JWT weak + Mass Assignment → Usurpation totale ─────────────────────
    CorrelationRule(
        rule_id="CORR-028",
        name="JWT faible + Mass Assignment → Usurpation totale de compte",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "jwt", "jwt_advanced") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
            lambda f: _has_module(f, "mass_assignment"),
        ],
        description_fn=lambda groups: (
            f"JWT avec signature faible/forgeable ({groups[0][0].url}) + Mass Assignment "
            f"({groups[1][0].url}) : l'attaquant peut forger un JWT avec `role=admin` "
            f"et pousser ce rôle via Mass Assignment. Double confirmation de l'escalade de privilèges.\n"
            f"JWT: {groups[0][0].title}\nMass Assignment: {groups[1][0].title}"
        ),
        remediation=(
            "Utiliser HS256 avec clé ≥ 256 bits ou RS256. "
            "Valider l'algorithme côté serveur (rejeter 'none' et les algos faibles). "
            "Appliquer une allowlist stricte sur les claims acceptés."
        ),
        cwe="CWE-347",
        tags=["jwt", "mass-assignment", "privilege-escalation", "auth"],
    ),

    # ── Prototype Pollution + XSS → Client-side RCE ─────────────────────────
    CorrelationRule(
        rule_id="CORR-029",
        name="Prototype Pollution + XSS → Client-side RCE persistant",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "prototype_pollution"),
            lambda f: _has_module(f, "xss", "dom_xss") and _has_severity(f, Severity.HIGH, Severity.CRITICAL),
        ],
        description_fn=lambda groups: (
            f"Prototype Pollution ({groups[0][0].url}) + XSS ({groups[1][0].url}) : "
            f"la pollution de prototype permet d'injecter des propriétés sur tous les objets JS, "
            f"pouvant créer un vecteur XSS indirect (ex: `__proto__.innerHTML`) même si le XSS "
            f"direct est partiellement mitigé. Combinaison critique pour l'exécution côté client.\n"
            f"Prototype Pollution: {groups[0][0].title}\nXSS: {groups[1][0].title}"
        ),
        remediation=(
            "Utiliser Object.create(null) pour les objets de config. "
            "Valider et sanitizer les entrées avant merge (lodash merge vulnérable). "
            "Déployer une CSP stricte pour limiter l'impact XSS. "
            "Corriger le XSS sous-jacent en priorité."
        ),
        cwe="CWE-79",
        tags=["prototype-pollution", "xss", "client-side-rce", "javascript"],
    ),

    # ── Race Condition + Business Logic → Fraude financière ─────────────────
    CorrelationRule(
        rule_id="CORR-030",
        name="Race Condition + Business Logic → Fraude / Double-spend",
        severity=Severity.CRITICAL,
        required=[
            lambda f: _has_module(f, "race_condition"),
            lambda f: _has_module(f, "business_logic") and any(
                kw in f.description.lower()
                for kw in ["solde", "crédit", "balance", "redeem", "coupon",
                           "discount", "refund", "transfer", "payment", "credit"]
            ),
        ],
        description_fn=lambda groups: (
            f"Race Condition ({groups[0][0].url}) sur un endpoint de Business Logic financier "
            f"({groups[1][0].url}). Un attaquant peut soumettre N requêtes simultanées pour "
            f"dépenser le même crédit/coupon plusieurs fois (double-spend), "
            f"contournant les vérifications de solde non atomiques.\n"
            f"Race: {groups[0][0].title}\nBusiness Logic: {groups[1][0].title}"
        ),
        remediation=(
            "Utiliser des transactions DB atomiques (SELECT FOR UPDATE / SERIALIZABLE). "
            "Implémenter un verrou optimiste ou pessimiste sur les ressources financières. "
            "Limiter le taux de requêtes par utilisateur sur les endpoints critiques. "
            "Ajouter des idempotency keys sur les opérations financières."
        ),
        cwe="CWE-362",
        tags=["race-condition", "business-logic", "financial-fraud", "double-spend"],
    ),
])
