"""
PhantomScan — OOB Canary Manager (v5.19)
=========================================
Gère les canaries Out-Of-Band pour les vulnérabilités blind :
  - SSRF aveugle (cible callback)
  - XXE aveugle (entité externe vers attaquant)
  - Log4Shell (JNDI lookup)
  - DNS exfiltration (SQL, NoSQL blind)

Sans backend OOB, le scanner ne peut détecter que les vulns avec réponse directe.
Avec OOB, il détecte 30-40% de vulns supplémentaires en bug bounty.

Backends supportés :
  - "interactsh"   : projet OSS de ProjectDiscovery (https://app.interactsh.com)
                     Auto-provision d'un sous-domaine *.oast.fun
  - "burp"         : Burp Collaborator (l'utilisateur fournit le domaine)
  - "custom"       : domaine fourni par l'utilisateur (DNS qu'il monitore)
  - "disabled"     : pas de OOB → mode legacy (default si pas de configuration)

Usage CLI :
    --oob interactsh                    # auto-provision
    --oob burp:abc.burpcollaborator.net # Burp
    --oob custom:my-canary.example.com  # domaine custom

Usage programmatique :
    oob = OOBCanaryManager()
    await oob.start("interactsh")
    canary = oob.new_canary(tag="ssrf-1")
    # Le scanner injecte canary.url dans son payload
    await asyncio.sleep(15)
    hits = await oob.poll_hits(canary.id)
    if hits:
        # OOB callback reçu → vuln confirmée
"""

from __future__ import annotations

import asyncio
import os
import secrets
import time
import uuid
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Canary:
    """Un canary unique pour tracer un test OOB."""
    id: str           # identifiant interne court
    subdomain: str    # ex: "abc123.oast.fun"
    tag: str = ""     # contexte (module + endpoint)
    created_at: float = field(default_factory=time.time)
    hits: list[dict] = field(default_factory=list)

    @property
    def http_url(self) -> str:
        return f"http://{self.subdomain}/"

    @property
    def https_url(self) -> str:
        return f"https://{self.subdomain}/"

    @property
    def dns_name(self) -> str:
        return self.subdomain

    @property
    def jndi_url(self) -> str:
        """Pour Log4Shell : ${jndi:ldap://canary/a}"""
        return f"ldap://{self.subdomain}/a"


class _DisabledBackend:
    """Backend no-op : retourne des canaries inutilisables.
    Permet aux modules de ne pas se soucier de l'état de l'OOB."""

    name = "disabled"

    async def start(self) -> bool:
        return True

    def new_canary(self, tag: str = "") -> Canary | None:
        return None

    async def poll_hits(self, canary_id: str) -> list[dict]:
        return []

    async def close(self) -> None:
        pass


class _CustomBackend:
    """
    Backend "custom" : l'utilisateur fournit un domaine de base qu'il monitore
    lui-même (via tcpdump, DNS log, etc.). Le scanner génère des sous-domaines
    uniques mais ne peut PAS poller les hits (l'utilisateur lit ses logs).

    Utile pour les blue-teams qui veulent une trace immuable côté infra.
    """

    name = "custom"

    def __init__(self, base_domain: str) -> None:
        self.base = base_domain.rstrip(".")
        self._canaries: dict[str, Canary] = {}

    async def start(self) -> bool:
        return bool(self.base)

    def new_canary(self, tag: str = "") -> Canary:
        cid = secrets.token_hex(4)
        sub = f"{cid}.{self.base}"
        c = Canary(id=cid, subdomain=sub, tag=tag)
        self._canaries[cid] = c
        return c

    async def poll_hits(self, canary_id: str) -> list[dict]:
        # Pas de polling possible — l'utilisateur surveille à part
        return []

    async def close(self) -> None:
        pass


class _InteractshBackend:
    """
    Backend Interactsh (projectdiscovery/interactsh).
    Provisionne un sous-domaine *.oast.fun et poll les events via API REST.

    Documentation : https://github.com/projectdiscovery/interactsh

    Note : ce backend implémente le minimum nécessaire (registration + polling).
    Pour une intégration complète avec correlation ID + chiffrement RSA,
    voir le client Go officiel. Notre version utilise le mode "non-correlated"
    qui suffit pour la détection BB (pas pour des engagements red-team
    où l'opérateur veut mapper précisément quel hit appartient à quelle injection).
    """

    name = "interactsh"
    DEFAULT_SERVER = "oast.fun"

    def __init__(self, server: str | None = None) -> None:
        self.server = server or self.DEFAULT_SERVER
        self._correlation_id: str | None = None
        self._secret: str | None = None
        self._registered = False
        self._canaries: dict[str, Canary] = {}
        self._session = None
        # Pour limiter le polling
        self._last_poll = 0.0

    async def start(self) -> bool:
        """Enregistre une session sur le serveur Interactsh."""
        try:
            import aiohttp
            self._session = aiohttp.ClientSession()
            self._correlation_id = secrets.token_hex(10)
            self._secret = str(uuid.uuid4())
            register_url = f"https://{self.server}/register"
            payload = {
                "correlation-id": self._correlation_id,
                "secret-key": self._secret,
                # Note : le vrai client envoie une RSA public-key pour chiffrer
                # les hits. On omet pour simplicité — ça désactive le chiffrement
                # côté serveur mais le service reste fonctionnel.
                "public-key": "",
            }
            async with self._session.post(register_url, json=payload, timeout=10) as resp:
                if resp.status == 200:
                    self._registered = True
                    return True
        except Exception:
            pass
        # Échec → fall through, les modules verront new_canary() retourner None
        if self._session:
            try:
                await self._session.close()
            except Exception:
                pass
            self._session = None
        return False

    def new_canary(self, tag: str = "") -> Canary | None:
        if not self._registered or not self._correlation_id:
            return None
        # Format Interactsh : <correlation-id><random>.oast.fun
        # On utilise un préfixe court pour éviter les troncatures DNS dans
        # les payloads SQLi (max 63 chars par label DNS)
        random_part = secrets.token_hex(3)
        sub = f"{self._correlation_id[:14]}{random_part}.{self.server}"
        cid = random_part
        c = Canary(id=cid, subdomain=sub, tag=tag)
        self._canaries[cid] = c
        return c

    async def poll_hits(self, canary_id: str | None = None) -> list[dict]:
        """
        Récupère les hits côté serveur. Si canary_id est fourni, filtre.
        Sinon retourne tous les hits récents.
        """
        if not self._registered or not self._session or not self._correlation_id:
            return []
        # Throttle : ne pas poller plus d'une fois par seconde
        now = time.monotonic()
        if now - self._last_poll < 1.0:
            return []
        self._last_poll = now

        try:
            poll_url = (
                f"https://{self.server}/poll"
                f"?id={self._correlation_id}&secret={self._secret}"
            )
            async with self._session.get(poll_url, timeout=10) as resp:
                if resp.status != 200:
                    return []
                data = await resp.json()
        except Exception:
            return []

        events = data.get("data") or []
        hits: list[dict] = []
        for ev in events:
            # Format brut Interactsh : ev contient {protocol, full-id, raw-request, timestamp}
            full_id = ev.get("full-id", "")
            # Extract le random_part qu'on a injecté
            for cid, canary in self._canaries.items():
                if cid in full_id or canary.subdomain in str(ev):
                    hit = {
                        "protocol": ev.get("protocol"),
                        "remote_address": ev.get("remote-address", ""),
                        "timestamp": ev.get("timestamp", ""),
                        "raw": ev.get("raw-request", "")[:500],
                    }
                    canary.hits.append(hit)
                    if canary_id is None or canary_id == cid:
                        hits.append(hit)
        return hits

    async def close(self) -> None:
        if self._session:
            try:
                # Désinscrire la session si possible
                if self._registered and self._correlation_id:
                    try:
                        await self._session.post(
                            f"https://{self.server}/deregister",
                            json={"correlation-id": self._correlation_id,
                                  "secret-key": self._secret},
                            timeout=5,
                        )
                    except Exception:
                        pass
                await self._session.close()
            except Exception:
                pass
            self._session = None


class OOBCanaryManager:
    """Façade unifiée pour la gestion OOB. Singleton-ready via Engine."""

    def __init__(self) -> None:
        self._backend = _DisabledBackend()
        self._enabled = False
        self._lock = asyncio.Lock()

    @property
    def enabled(self) -> bool:
        return self._enabled

    @property
    def backend_name(self) -> str:
        return self._backend.name

    async def start(self, spec: str | None) -> bool:
        """
        Démarre le backend OOB.
        spec format :
          - None ou "" ou "disabled" → no-op
          - "interactsh"             → ProjectDiscovery oast.fun
          - "interactsh:server.tld"  → server self-hosted
          - "custom:my.canary.tld"   → domaine custom
        """
        async with self._lock:
            if not spec or spec == "disabled":
                self._backend = _DisabledBackend()
                self._enabled = False
                return True

            kind = spec.split(":", 1)[0]
            arg = spec.split(":", 1)[1] if ":" in spec else None

            if kind == "interactsh":
                self._backend = _InteractshBackend(arg)
            elif kind in ("custom", "burp"):
                if not arg:
                    return False
                self._backend = _CustomBackend(arg)
            else:
                return False

            ok = await self._backend.start()
            self._enabled = ok
            return ok

    def new_canary(self, tag: str = "") -> Canary | None:
        """Génère un nouveau canary unique. Retourne None si OOB désactivé."""
        if not self._enabled:
            return None
        return self._backend.new_canary(tag=tag)

    async def poll_hits(self, canary_id: str | None = None) -> list[dict]:
        """Poll les hits reçus. Retourne [] si OOB désactivé."""
        if not self._enabled:
            return []
        return await self._backend.poll_hits(canary_id)

    async def wait_for_hit(self, canary_id: str, timeout: float = 15.0) -> list[dict]:
        """
        Poll jusqu'à recevoir au moins un hit, ou timeout.
        Utilisé par les modules après injection d'un payload OOB.
        """
        if not self._enabled:
            return []
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            hits = await self.poll_hits(canary_id)
            if hits:
                return hits
            await asyncio.sleep(2.0)
        return []

    async def close(self) -> None:
        await self._backend.close()
