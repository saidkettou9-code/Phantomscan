"""
PhantomScan — CVSS 3.1 Scorer (v5.19)
======================================
Calcul automatique du score CVSS 3.1 basé sur le type de vuln, le contexte,
et l'evidence collectée par les modules.

Pourquoi : les programmes BB exigent un score CVSS dans les rapports.
Sans score, le triage est plus lent et les bounties souvent revus à la baisse.
Avant v5.19, Finding.cvss valait toujours 0.0.

Calculs effectués :
  - Vector string CVSS 3.1 complet : AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N
  - Score base (0.0 - 10.0)
  - Severity rating recalculé (peut écraser la severity du module si discordance)

Les modules n'ont rien à modifier : le scoring s'applique au niveau du Reporter
ou de l'Engine via cvss_score_finding(finding).
"""

from __future__ import annotations

import math
import re

from phantomscan.output.reporter import Finding, Severity


# Vecteur CVSS 3.1 par "famille" de vulnérabilité
# Format : (AV, AC, PR, UI, S, C, I, A)
# AV = Attack Vector       (N=Network, A=Adjacent, L=Local, P=Physical)
# AC = Attack Complexity   (L=Low, H=High)
# PR = Privileges Required (N=None, L=Low, H=High)
# UI = User Interaction    (N=None, R=Required)
# S  = Scope               (U=Unchanged, C=Changed)
# C  = Confidentiality     (N=None, L=Low, H=High)
# I  = Integrity           (N=None, L=Low, H=High)
# A  = Availability        (N=None, L=Low, H=High)

_CVSS_VECTORS: dict[str, tuple] = {
    # ── RCE-class : score max ───────────────────────────────────────────
    "cmdi":              ("N", "L", "N", "N", "U", "H", "H", "H"),  # 9.8
    "ssti":              ("N", "L", "N", "N", "U", "H", "H", "H"),  # 9.8
    "deserialization":   ("N", "L", "N", "N", "U", "H", "H", "H"),  # 9.8
    "log4shell":         ("N", "L", "N", "N", "C", "H", "H", "H"),  # 10.0
    # ── Injection avec lecture/modification serveur ─────────────────────
    "sqli":              ("N", "L", "N", "N", "U", "H", "H", "L"),  # 9.4
    "nosql_injection":   ("N", "L", "N", "N", "U", "H", "H", "L"),  # 9.4
    "xxe":               ("N", "L", "N", "N", "U", "H", "L", "L"),  # 8.6
    "lfi":               ("N", "L", "N", "N", "U", "H", "L", "N"),  # 8.2
    "path_traversal":    ("N", "L", "N", "N", "U", "H", "L", "N"),  # 8.2
    # ── SSRF / chaîne pivot ─────────────────────────────────────────────
    "ssrf":              ("N", "L", "N", "N", "C", "H", "L", "N"),  # 9.3
    "http_smuggling":    ("N", "H", "N", "N", "C", "H", "H", "L"),  # 8.5
    # ── XSS family ──────────────────────────────────────────────────────
    "xss":               ("N", "L", "N", "R", "C", "L", "L", "N"),  # 6.1
    "dom_xss":           ("N", "L", "N", "R", "C", "L", "L", "N"),  # 6.1
    # ── Auth / Access ───────────────────────────────────────────────────
    "auth_bypass":       ("N", "L", "N", "N", "U", "H", "H", "L"),  # 9.4
    "idor":              ("N", "L", "L", "N", "U", "H", "L", "N"),  # 7.7
    "mass_assignment":   ("N", "L", "L", "N", "U", "H", "H", "N"),  # 8.1
    "jwt":               ("N", "L", "N", "N", "U", "H", "H", "N"),  # 9.1
    "jwt_advanced":      ("N", "L", "N", "N", "U", "H", "H", "N"),  # 9.1
    "oauth_misconfig":   ("N", "L", "N", "R", "C", "H", "H", "N"),  # 9.0
    # ── Misconfig / leaks ───────────────────────────────────────────────
    "actuator":          ("N", "L", "N", "N", "U", "H", "L", "N"),  # 7.5
    "s3_enum":           ("N", "L", "N", "N", "U", "H", "L", "N"),  # 7.5
    "api_key_exposure":  ("N", "L", "N", "N", "U", "H", "L", "L"),  # 8.2
    "exposed_panels":    ("N", "L", "N", "N", "U", "L", "L", "N"),  # 5.4
    "subdomain_takeover":("N", "L", "N", "N", "C", "H", "H", "L"),  # 9.6
    # ── Headers / cache / smuggling layer ───────────────────────────────
    "cache_poison":      ("N", "L", "N", "R", "C", "L", "H", "L"),  # 8.0
    "host_header_injection": ("N", "L", "N", "R", "U", "L", "H", "N"), # 6.5
    "open_redirect":     ("N", "L", "N", "R", "C", "N", "L", "N"),  # 4.7
    "open_redirect_chain": ("N", "L", "N", "R", "C", "L", "L", "N"),# 5.4
    "cors":              ("N", "L", "N", "R", "U", "L", "L", "N"),  # 5.4
    "crlf":              ("N", "L", "N", "R", "U", "L", "L", "N"),  # 5.4
    "clickjacking":      ("N", "L", "N", "R", "U", "N", "L", "N"),  # 4.3
    "csrf":              ("N", "L", "N", "R", "U", "L", "L", "N"),  # 5.4
    # ── Network ──────────────────────────────────────────────────────────
    "tls_audit":         ("N", "H", "N", "N", "U", "L", "L", "N"),  # 4.0
    "rate_limit":        ("N", "L", "N", "N", "U", "N", "L", "L"),  # 5.3
    # ── Business logic / multi-step ──────────────────────────────────────
    "race_condition":    ("N", "H", "L", "N", "U", "L", "H", "N"),  # 6.4
    "business_logic":    ("N", "L", "L", "N", "U", "L", "H", "N"),  # 6.5
    "otp_bypass":        ("N", "L", "N", "N", "U", "H", "H", "N"),  # 9.1
    # ── Fallback ─────────────────────────────────────────────────────────
    "default":           ("N", "L", "L", "R", "U", "L", "L", "N"),  # 4.6
}


# Coefficients CVSS 3.1 officiels — https://www.first.org/cvss/v3.1/specification-document
_AV = {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.20}
_AC = {"L": 0.77, "H": 0.44}
_UI = {"N": 0.85, "R": 0.62}
_PR_U = {"N": 0.85, "L": 0.62, "H": 0.27}
_PR_C = {"N": 0.85, "L": 0.68, "H": 0.50}
_CIA = {"N": 0.0, "L": 0.22, "H": 0.56}


def _round_up(x: float) -> float:
    """Arrondi spécifique CVSS : ceil(x * 10) / 10."""
    return math.ceil(x * 10) / 10


def compute_cvss_3_1(av: str, ac: str, pr: str, ui: str, s: str,
                     c: str, i: str, a: str) -> tuple[float, str]:
    """
    Calcule le score base CVSS 3.1 et le vector string.
    Returns: (score, vector_string)
    """
    iss = 1 - ((1 - _CIA[c]) * (1 - _CIA[i]) * (1 - _CIA[a]))
    if s == "U":
        impact = 6.42 * iss
    else:
        impact = 7.52 * (iss - 0.029) - 3.25 * pow(iss - 0.02, 15)

    pr_val = _PR_U[pr] if s == "U" else _PR_C[pr]
    exploitability = 8.22 * _AV[av] * _AC[ac] * pr_val * _UI[ui]

    if impact <= 0:
        score = 0.0
    elif s == "U":
        score = _round_up(min(impact + exploitability, 10))
    else:
        score = _round_up(min(1.08 * (impact + exploitability), 10))

    vector = f"CVSS:3.1/AV:{av}/AC:{ac}/PR:{pr}/UI:{ui}/S:{s}/C:{c}/I:{i}/A:{a}"
    return score, vector


def _module_to_key(module: str) -> str:
    """Extrait la clé canonique depuis 'vulns/xss' ou 'XSSScanner' → 'xss'."""
    m = module.lower()
    # vulns/xss → xss
    if "/" in m:
        m = m.rsplit("/", 1)[-1]
    # XSSScanner → xssscanner → xss
    m = m.replace("scanner", "").replace("analyzer", "")
    # Mappings spéciaux
    for key in _CVSS_VECTORS:
        if key in m or m in key:
            return key
    # Patterns plus larges (ordre = priorité)
    for kw, target in [
        ("smuggling", "http_smuggling"),
        ("traversal", "path_traversal"),
        ("takeover", "subdomain_takeover"),
        ("redirect_chain", "open_redirect_chain"),
        ("redirect", "open_redirect"),
        ("graphql", "sqli"),
        ("websocket", "xss"),
    ]:
        if kw in m:
            return target
    return "default"


def _confidence_modifier(finding: Finding) -> float:
    """
    Ajustement du score selon la confiance de l'evidence.
    - Evidence très forte (sleep, SQL error, exec output) : +0
    - Evidence faible/heuristique : -1.0 à -1.5
    """
    evidence = (finding.evidence or "").lower()
    description = (finding.description or "").lower()
    blob = evidence + " " + description

    # Indicateurs de très forte confiance
    strong = [
        "sleep(", "pg_sleep", "waitfor delay",       # SQLi time-based
        "you have an error in your sql syntax",      # SQLi error
        "uid=", "gid=", "/etc/passwd",                # CMDi / LFI confirmed
        "root:x:0:0",                                  # /etc/passwd
        "<!doctype html><html",                        # XXE entity expansion
        "executable",                                  # XSS context confirmed
        "confirmed", "verified",
    ]
    weak = [
        "potential", "possible", "may be", "suspected",
        "heuristic", "indicator", "presence of",
        "reflected (html-encodé)",
    ]

    if any(s in blob for s in strong):
        return 0.0
    if any(w in blob for w in weak):
        return -1.0
    return -0.3  # par défaut, légère décote


def score_finding(finding: Finding) -> tuple[float, str, Severity]:
    """
    Calcule le CVSS d'un finding et retourne (score, vector, severity_recalculée).

    La severity recalculée peut être différente de finding.severity :
    - score >= 9.0 → CRITICAL
    - score >= 7.0 → HIGH
    - score >= 4.0 → MEDIUM
    - score >= 0.1 → LOW
    - score == 0.0 → INFO
    """
    key = _module_to_key(finding.module)
    av, ac, pr, ui, s, c, i, a = _CVSS_VECTORS.get(key, _CVSS_VECTORS["default"])

    score, vector = compute_cvss_3_1(av, ac, pr, ui, s, c, i, a)

    # Ajustement par la confiance de l'evidence
    score = max(0.0, min(10.0, score + _confidence_modifier(finding)))
    score = round(score, 1)

    # Mapping score → severity
    if score >= 9.0:
        sev = Severity.CRITICAL
    elif score >= 7.0:
        sev = Severity.HIGH
    elif score >= 4.0:
        sev = Severity.MEDIUM
    elif score > 0.0:
        sev = Severity.LOW
    else:
        sev = Severity.INFO

    return score, vector, sev


def annotate_findings(findings: list[Finding], override_severity: bool = False) -> None:
    """
    Annote in-place tous les findings avec leur score CVSS et vector.
    Le vector est stocké dans finding.extra["cvss_vector"].

    Args:
        findings: liste à annoter
        override_severity: si True, écrase la severity par celle calculée par CVSS.
                           Recommandé False par défaut (la severity du module est
                           souvent plus contextuelle).
    """
    for f in findings:
        try:
            score, vector, sev = score_finding(f)
            if f.cvss == 0.0:
                f.cvss = score
            if "cvss_vector" not in f.extra:
                f.extra["cvss_vector"] = vector
            if override_severity:
                f.severity = sev
        except Exception:
            # Échec silencieux : ne pas casser le rapport pour un score
            continue
