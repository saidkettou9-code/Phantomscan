"""
PhantomScan — DedupIndex (v5.19)
=================================
Déduplication cross-modules intelligente.

Problème résolu :
  Avant v5.19, plusieurs scanners testaient indépendamment des endpoints
  qui ne diffèrent que par la valeur de leurs paramètres :
    /api/users?id=1
    /api/users?id=2
    /api/users?id=42
  → Chacun déclenchait XSS+SQLi+SSTI+LFI+SSRF+IDOR... soit 6 modules × 3 URLs
    = 18 séries de tests pour un seul "endpoint canonique".

  Le DedupIndex regroupe ces variantes en une "endpoint signature" et indique
  aux modules quels endpoints peuvent être testés une seule fois.

Signature d'un endpoint :
  (method, scheme + netloc + path, set des noms de params)

Exemples :
  GET https://api.com/v1/users?id=1&format=json
  GET https://api.com/v1/users?id=999&format=xml
  → même signature : ("GET", "https://api.com/v1/users", frozenset({"id","format"}))
  → testé une seule fois

Le scanner doit appeler should_skip(url, method) avant ses tests.
Si False, il marque l'endpoint comme testé via mark_tested(url, method, vuln_type).

Le second mécanisme : skip ciblé par type de vuln.
  Si SemanticParamClassifier dit que `lang=fr` est de rôle FORMAT, c'est
  inutile de le tester pour SQLi mais utile pour SSTI/XXE.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Iterable
from urllib.parse import urlparse, parse_qs


def _endpoint_signature(method: str, url: str) -> tuple[str, str, frozenset]:
    """
    Calcule la signature canonique d'un endpoint.
    Deux URLs avec mêmes params (mêmes NOMS, valeurs ignorées) → même signature.
    """
    parsed = urlparse(url)
    base = f"{parsed.scheme}://{parsed.netloc.lower()}{parsed.path}"
    params = parse_qs(parsed.query, keep_blank_values=True)
    return (method.upper(), base, frozenset(params.keys()))


@dataclass
class _EndpointEntry:
    signature: tuple[str, str, frozenset]
    representative_url: str         # première URL vue (utilisée pour le test)
    tested_vuln_types: set[str] = field(default_factory=set)
    skip_vuln_types: set[str] = field(default_factory=set)
    test_count: int = 0


class DedupIndex:
    """
    Index thread-safe de déduplication d'endpoints.

    Usage typique dans un scanner :
        if await dedup.should_skip(url, "GET", vuln_type="sqli"):
            return  # déjà couvert
        # ... tests ...
        await dedup.mark_tested(url, "GET", vuln_type="sqli")
    """

    def __init__(self) -> None:
        self._entries: dict[tuple[str, str, frozenset], _EndpointEntry] = {}
        self._lock = asyncio.Lock()
        # Stats globales pour le rapport
        self._skip_count = 0
        self._test_count = 0

    async def should_skip(
        self,
        url: str,
        method: str = "GET",
        vuln_type: str = "",
    ) -> bool:
        """
        Retourne True si cet endpoint a déjà été testé pour ce type de vuln.
        Si vuln_type est vide, retourne True dès qu'un module a touché ce endpoint
        (à utiliser uniquement par les modules qui ne se concentrent pas sur un
        type spécifique).
        """
        sig = _endpoint_signature(method, url)
        async with self._lock:
            entry = self._entries.get(sig)
            if entry is None:
                return False

            if vuln_type:
                # Skip explicite (param non pertinent pour ce vuln_type)
                if vuln_type in entry.skip_vuln_types:
                    self._skip_count += 1
                    return True
                # Déjà testé pour ce vuln_type
                if vuln_type in entry.tested_vuln_types:
                    self._skip_count += 1
                    return True
            else:
                if entry.test_count > 0:
                    self._skip_count += 1
                    return True
            return False

    async def mark_tested(
        self,
        url: str,
        method: str = "GET",
        vuln_type: str = "",
    ) -> None:
        """Enregistre qu'un endpoint a été testé."""
        sig = _endpoint_signature(method, url)
        async with self._lock:
            entry = self._entries.get(sig)
            if entry is None:
                entry = _EndpointEntry(signature=sig, representative_url=url)
                self._entries[sig] = entry
            if vuln_type:
                entry.tested_vuln_types.add(vuln_type)
            entry.test_count += 1
            self._test_count += 1

    async def mark_skip(self, url: str, method: str, vuln_types: Iterable[str]) -> None:
        """
        Marque cet endpoint comme à SKIPPER pour les vuln_types donnés.
        Utilisé par l'Engine après classification sémantique : si tous les params
        sont de type LIMIT/FORMAT, on skip XSS/SQLi.
        """
        sig = _endpoint_signature(method, url)
        async with self._lock:
            entry = self._entries.get(sig)
            if entry is None:
                entry = _EndpointEntry(signature=sig, representative_url=url)
                self._entries[sig] = entry
            entry.skip_vuln_types.update(vuln_types)

    def representative_urls(self, method: str = "GET") -> list[str]:
        """Liste les URLs canoniques (une par signature)."""
        method_u = method.upper()
        return [
            entry.representative_url
            for entry in self._entries.values()
            if entry.signature[0] == method_u
        ]

    @property
    def stats(self) -> dict[str, int]:
        return {
            "unique_endpoints": len(self._entries),
            "tests_executed": self._test_count,
            "tests_skipped": self._skip_count,
            "dedup_ratio": round(
                self._skip_count / max(self._test_count + self._skip_count, 1), 3
            ),
        }


# ─────────────────────── Helper : skip rules sémantiques ─────────────────────

# Pour chaque rôle de paramètre (cf SemanticParamClassifier), liste des
# vuln_types qu'il NE FAUT PAS tester (gain de temps massif).
_ROLE_SKIP_RULES: dict[str, set[str]] = {
    # LIMIT (page, count, offset) : pas de XSS/SSTI/CMDi (intégers numériques)
    "limit":     {"xss", "ssti", "cmdi", "lfi", "ssrf", "open_redirect"},
    # FORMAT : enum très contraint → pas SQLi/CMDi
    "format":    {"sqli", "cmdi"},
    # ID numérique : pas SSTI/XSS dans 90% des cas
    "id":        {"ssti"},
    # TOKEN : pas SQLi (sanitized en validation), focus JWT
    "token":     {"sqli", "ssti", "xss"},
    # CALLBACK (jsonp) : pas LFI/CMDi
    "callback":  {"lfi", "cmdi", "ssti"},
}


def vulns_to_skip_for_params(roles: dict[str, str]) -> set[str]:
    """
    Étant donné les rôles de tous les params d'un endpoint, retourne
    les vuln_types qu'on peut sauter.

    Logique : on ne skip que si TOUS les params permettent de skip ce vuln_type.
    Si un seul param est UNKNOWN/QUERY, on ne skip rien (on reste safe).
    """
    if not roles:
        return set()

    # Skip d'un vuln_type si tous les params disent de skip
    candidate_skips: set[str] | None = None
    for role in roles.values():
        skip_for_role = _ROLE_SKIP_RULES.get(role, set())
        if not skip_for_role:
            return set()  # un param ne dit pas de skip → on ne skip rien
        if candidate_skips is None:
            candidate_skips = set(skip_for_role)
        else:
            candidate_skips &= skip_for_role
    return candidate_skips or set()
