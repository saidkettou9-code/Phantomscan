# PhantomScan — CHANGELOG v5.10.0

## Résumé des changements

Version axée sur l'**augmentation de puissance** : 4 nouveaux modules couvrant
des vecteurs critiques absents des versions précédentes.

---

### 1. `modules/vulns/jwt_advanced.py` — JWT Advanced Scanner

**Remplace / complète** le module `jwt.py` existant avec des attaques avancées
que les scanners classiques ne font pas.

#### Techniques couvertes

- **None Algorithm Attack** — forge un JWT signé `alg=none/None/NONE/nOnE` sans secret
- **Weak Secret Brute-Force** — dictionnaire de 200+ secrets courants (flask default, django-insecure, `secret`, `password`, etc.)
  - Si le secret est trouvé : forge immédiatement un token `role=admin, is_admin=True` pour confirmation
- **Claim Privilege Escalation** — modifie `role`, `admin`, `is_admin`, `sub`, `uid` via none-alg / secret vide
- **kid Injection** — path traversal (`../../dev/null`) + SQLi (`' OR '1'='1`) dans le header `kid`
- **JKU / x5u SSRF** — injecte une URL externe dans `jku` / `x5u` pour forcer le serveur à fetch un JWK Set contrôlé
- **JWT Expiry Bypass** — envoie un token avec `exp=1` (1970) pour vérifier si l'expiration est validée
- **JWT Leak Detection** — détecte les JWT exposés dans les réponses HTTP (body, Set-Cookie, Authorization)

#### Flags CLI
- `--no-jwt-advanced` : désactive JWTAdvancedScanner

---

### 2. `modules/vulns/business_logic.py` — Business Logic Scanner

Nouveau module couvrant les vulnérabilités de logique métier — absentes de TOUS
les scanners open-source existants.

#### Techniques couvertes

- **Price Tampering** — modifie les champs `price`, `unit_price`, `amount`, `total` à 0, 0.01, -1
  dans le body JSON et form-urlencoded des endpoints POST
- **Negative Quantity** — injecte `qty=-1`, `qty=-9999` pour créer des crédits non-autorisés
- **Mass Assignment** — injecte des champs non-attendus (`role=admin`, `price=0`, `discount=100`,
  `payment_status=paid`) et vérifie s'ils sont réfléchis dans la réponse
- **Coupon Stacking** — applique le même coupon 3 fois de suite et détecte l'absence de protection
- **Workflow Step Skipping** — accède directement à `/checkout/confirm` sans les étapes précédentes
- **QS Price Tampering** — modifie les paramètres de prix dans les query strings des URLs GET

#### Intégration EndpointBus
Scanne automatiquement les endpoints POST/cart/order/coupon découverts par le crawler.

#### Flags CLI
- `--no-business-logic` : désactive BusinessLogicScanner

---

### 3. `modules/vulns/api_security.py` — API Security Scanner

Techniques spécifiques aux APIs REST modernes.

#### Techniques couvertes

- **Debug/Admin Endpoints Exposed** — probe 30+ paths (`/api/debug`, `/api/admin`, `/api/env`,
  `/api/swagger.json`, `/__debug__`...) et signale ceux accessibles sans auth
- **API Versioning Abuse** — détecte les anciennes versions de l'API (`v0`, `v1`, `beta`, `dev`)
  qui retournent plus de données ou ont moins de contrôles d'accès que la version courante
- **HTTP Method Override** — teste `X-HTTP-Method-Override: DELETE`, `X-Method-Override: PUT`
  pour bypasser les contrôles WAF sur les méthodes HTTP
- **Field Filtering Bypass** — `?fields=*`, `?select=all`, `?expand=*` pour extraire
  tous les champs d'un modèle (Excessive Data Exposure)
- **API Key in URL** — détecte les clés API / tokens passés en query string (loggés partout)
- **Unreferenced Methods (CRUD Discovery)** — teste DELETE/PUT/PATCH sur tous les endpoints
  API découverts par le crawler, signale ceux qui répondent 200/204
- **Content-Type Confusion** — envoie JSON à un endpoint form et vice-versa pour détecter
  les parseurs permissifs qui bypassent des validations

#### Flags CLI
- `--no-api-security` : désactive APISecurityScanner

---

### 4. `modules/recon/param_miner.py` — Param Miner

Inspiré de **Burp Suite Param Miner** — découverte de paramètres cachés ou non-documentés
via analyse différentielle des réponses HTTP.

#### Techniques couvertes

- **Wordlist de ~400 paramètres** : debug, cache, admin, format, feature flags, redirect,
  headers (X-Forwarded-Host, X-Host...), prototype pollution, Spring Boot, PHP legacy
- **Batch injection** par groupes de 30 (réduit le nombre de requêtes ~13x)
- **Bisection récursive** : quand un batch a un effet, bisecte pour isoler le param responsable
- **Modes** : GET (query string) + POST (form-urlencoded)
- **Détection** : changement de status, body-hash, content-length, Set-Cookie, Vary
  + réflexion de la valeur canary dans la réponse
- **Header Cache Poisoning** : injecte `X-Forwarded-Host`, `X-Host`, `Referer`, `X-Forwarded-Prefix`
  avec un domaine attaquant pour détecter les réponses poisonnables

#### Intégration EndpointBus
Mine aussi les endpoints POST découverts par le crawler.

#### Flags CLI
- `--no-param-miner` : désactive ParamMinerScanner (dans `--preset fast`)

---

## Fichiers modifiés / créés

| Fichier | Action | Description |
|---------|--------|-------------|
| `modules/vulns/jwt_advanced.py` | **créé** | JWT avancé : none-alg, weak secret, kid injection, jku SSRF |
| `modules/vulns/business_logic.py` | **créé** | Business logic : price tampering, mass assign, coupon, workflow |
| `modules/vulns/api_security.py` | **créé** | API security : versioning, debug endpoints, method override |
| `modules/recon/param_miner.py` | **créé** | Param Miner : découverte params cachés par diff d'analyse |
| `core/engine.py` | **étendu** | Intégration des 4 nouveaux modules dans les pipelines recon/vulns |
| `config.py` | **étendu** | VERSION 5.10.0, flags + rps overrides pour les nouveaux modules |

---

## Améliorations de couverture

| Catégorie OWASP | Avant | Après |
|----------------|-------|-------|
| A01 Broken Access Control | IDOR, AuthBypass, CORS | + JWT Advanced (claim escalation) |
| A02 Cryptographic Failures | TLS Audit, JWT basic | + JWT none-alg, weak secret BF |
| A03 Injection | SQLi, XSS, SSTI, CMDi... | + kid SQLi injection |
| A04 Insecure Design | Race Condition | + Business Logic (price, qty, workflow) |
| A05 Security Misconfiguration | Actuator, headers... | + API debug endpoints, method override |
| A07 ID & Auth Failures | OTP Bypass, Auth Bypass | + JWT expiry bypass, JWT leak |
| A08 Software Integrity | Deserialization | + JWT alg confusion |
| A09 Logging Failures | — | + API key in URL (logged secrets) |
| Recon | Secrets, Git, Wayback... | + Param Miner (params cachés, cache poison headers) |
