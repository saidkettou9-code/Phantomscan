"""
PhantomScan — CLI v5.15
Point d'entrée principal.

Améliorations v5.15 :
- 3 nouveaux modules Bug Bounty :
  • HostHeaderInjectionScanner : password-reset poisoning, cache poison via Host,
    localhost bypass, port reflection, absolute-URI smuggling
  • DependencyConfusionScanner : détecte les packages internes exposés (npm, PyPI,
    Go, Maven, NuGet…) et les registries privés — une des vulns les mieux payées en BB
  • MassAssignmentScanner : test complet des endpoints API REST/JSON pour les champs
    privilégiés (role, is_admin, balance, email_verified…) avec détection de réflexion
- Flags CLI : --no-host-header, --no-dep-confusion, --no-mass-assignment
- Preset bb : les 3 modules sont activés par défaut
- Preset full : les 3 modules explicitement ON
- --only-vulns : tokens host_header, dep_confusion, mass_assign
- --list-modules : mise à jour catégorie Vulns (business/API)
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

from phantomscan.config import PhantomConfig, NetworkConfig, ScanConfig, VERSION


# ─────────────────────────── Presets ────────────────────────────────────────

PRESETS: dict[str, dict] = {
    "bb": {
        "_desc": "Bug Bounty mode — modules haute valeur, port/vhost OOS off, streaming live",
        # Recon utile en BB
        "no_subdomain": False, "subdomain_bruteforce": False,
        "no_crawl": False, "crawl_depth": 300,
        "no_js": False, "no_tech": False,
        "no_wayback": False, "no_dns": False, "no_secrets": False,
        "google_dork": False,
        # Tous les modules d'injection ON
        "no_sqli": False, "no_xss": False, "no_lfi": False, "no_ssti": False,
        "no_cmdi": False, "no_xxe": False, "no_ssrf": False, "no_crlf": False,
        "no_idor": False, "no_jwt": False, "no_open_redirect": False,
        "no_auth_bypass": False, "no_headers": False, "no_cache_poison": False,
        "no_prototype_pollution": False, "no_graphql": False, "no_file_upload": False,
        "no_actuator": False, "no_waf_fingerprint": False, "no_oauth": False,
        "no_path_traversal": False, "no_log4shell": False, "no_tls_audit": False,
        "no_http_smuggling": False, "no_deserialization": False, "no_s3": False,
        "no_cors": False, "no_forbidden_bypass": False, "no_rate_limit": False,
        "no_dom_xss": False, "no_json_api": False,
        "no_nosql": False, "no_openapi": False, "no_takeover": False, "no_otp": False,
        "no_csrf": False, "no_race_condition": False,
        # Modules faible valeur BB : off
        "no_clickjacking": True,   # P5 partout, peu de programmes
        # v5.15 — nouveaux modules BB (haute valeur)
        "no_host_header": False,         # Password reset poisoning → HIGH/CRIT fréquent
        "no_dep_confusion": False,        # Dependency confusion → souvent $5k-$30k
        "no_mass_assignment": False,      # Mass assignment → API endpoint abuse
        # v5.16 — nouveaux modules BB (haute valeur)
        "no_exposed_panels": False,       # Panneaux admin exposés → CRIT si pas d'auth
        "no_api_key_exposure": False,     # Clés API/secrets exposés → souvent P1/P2
        "no_open_redirect_chain": False,  # Open redirect + OAuth chain → account takeover
        # v5.21 — Nouveaux modules BB haute valeur
        "no_account_takeover": False,     # ATO = P1 partout ($10k-$50k)
        "no_xpath": False,                # XPath injection (XML/SOAP apps)
        "no_email_injection": False,      # Email header injection via contact forms
        "no_api_versioning": False,       # Old API versions
        "no_sitemap_recon": False,        # Découverte endpoints via sitemap
        "no_cloud_recon": False,          # S3/Azure/GCP buckets ouverts → P1
        "no_spa_crawler": False,          # Extraction endpoints JS bundles
        # Rate modéré (respectueux programme)
        "concurrent": 15, "rate": 8.0, "module_timeout": 240, "module_concurrency": 5,
    },
    "fast": {
        "_desc": "Scan rapide (~5-10 min) — modules à haute vélocité uniquement",
        "no_recon": False, "no_vulns": False, "no_fuzz": True,
        "no_subdomain": True, "no_crawl": False, "no_js": True,
        "no_wayback": True, "google_dork": False, "no_dns": True, "no_secrets": True,
        "no_sqli": False, "no_xss": False, "no_lfi": False, "no_ssti": True,
        "no_cmdi": True, "no_xxe": True, "no_ssrf": False, "no_crlf": False,
        "no_idor": False, "no_jwt": False, "no_open_redirect": False,
        "no_auth_bypass": False, "no_headers": False, "no_cache_poison": False,
        "no_prototype_pollution": True, "no_graphql": False, "no_file_upload": True,
        "no_actuator": False, "no_waf_fingerprint": False, "no_oauth": False,
        "no_path_traversal": True, "no_log4shell": False, "no_tls_audit": False,
        "no_nosql": True, "no_openapi": False, "no_otp": True,
        "no_http_smuggling": True, "no_deserialization": True, "no_s3": True,
        "no_dom_xss": True, "no_json_api": False,
        "concurrent": 30, "rate": 20.0, "module_timeout": 60, "module_concurrency": 6,
    },
    "full": {
        "_desc": "Scan complet — tous les modules, profondeur maximale",
        # Recon — tout ON (explicite)
        "no_subdomain": False, "subdomain_bruteforce": True, "crawl_depth": 500,
        "no_crawl": False, "no_js": False, "no_tech": False,
        "no_wayback": False, "no_dns": False, "no_secrets": False,
        "google_dork": True,
        # Vulns injection — tout ON
        "no_sqli": False, "no_xss": False, "no_lfi": False, "no_ssti": False,
        "no_cmdi": False, "no_xxe": False, "no_ssrf": False, "no_crlf": False,
        "no_idor": False, "no_jwt": False, "no_open_redirect": False,
        "no_auth_bypass": False, "no_headers": False, "no_cache_poison": False,
        "no_prototype_pollution": False, "no_graphql": False, "no_file_upload": False,
        "no_actuator": False, "no_waf_fingerprint": False, "no_oauth": False,
        "no_path_traversal": False, "no_log4shell": False, "no_tls_audit": False,
        "no_http_smuggling": False, "no_deserialization": False, "no_s3": False,
        "no_cors": False, "no_forbidden_bypass": False, "no_rate_limit": False,
        "no_dom_xss": False, "no_json_api": False,
        "no_nosql": False, "no_openapi": False, "no_takeover": False, "no_otp": False,
        # v5.9
        "no_csrf": False, "no_clickjacking": False, "no_race_condition": False,
        # v5.10 — manquaient (BUG : full ne les activait pas explicitement)
        "no_websocket": False, "no_jwt_advanced": False,
        "no_business_logic": False, "no_api_security": False,
        "no_param_miner": False, "no_git_exposure": False,
        # Network modules
        "no_vhost": False, "no_port_scan": False,
        # v5.15 — nouveaux modules
        "no_host_header": False, "no_dep_confusion": False, "no_mass_assignment": False,
        # v5.16 — nouveaux modules
        "no_exposed_panels": False, "no_api_key_exposure": False, "no_open_redirect_chain": False,
        # v5.21 — Nouveaux modules
        "no_account_takeover": False, "no_xpath": False, "no_email_injection": False,
        "no_api_versioning": False, "no_sitemap_recon": False, "no_cloud_recon": False,
        "no_spa_crawler": False,
        # Fuzz — profondeur max
        "no_fuzz": False, "fuzz_depth": 5, "lfi_depth": 5,
        # Perf
        "concurrent": 20, "rate": 10.0, "module_timeout": 600, "module_concurrency": 4,
    },
    "stealth": {
        "_desc": "Mode furtif — rate faible, jitter élevé, profil discret",
        "no_recon": False, "no_vulns": False, "no_fuzz": True,
        "no_sqli": False, "no_xss": False, "no_ssrf": False,
        "no_cmdi": True, "no_ssti": True, "no_http_smuggling": True,
        "no_deserialization": True, "no_file_upload": True,
        "concurrent": 3, "rate": 1.0, "module_timeout": 600,
        "no_subdomain": True, "no_wayback": True, "google_dork": False,
        "module_concurrency": 2,
    },
    "api": {
        "_desc": "Scan orienté API REST/GraphQL/JSON/OpenAPI",
        "no_crawl": True, "no_subdomain": True, "no_wayback": True,
        "no_fuzz": True, "no_lfi": True, "no_path_traversal": True,
        "no_file_upload": True, "no_log4shell": False,
        "no_prototype_pollution": False, "no_graphql": False,
        "no_nosql": False, "no_openapi": False, "no_jwt": False,
        "no_ssrf": False, "no_ssti": False, "no_cmdi": False,
        "no_json_api": False, "no_otp": False,
        "concurrent": 20, "rate": 15.0, "module_timeout": 300,
    },
    "recon": {
        "_desc": "Recon pur — aucune attaque, collecte passive uniquement",
        "no_vulns": True, "no_fuzz": True,
        "no_recon": False, "subdomain_bruteforce": False,
        "concurrent": 10, "rate": 5.0,
    },
}

RATE_PRESETS: dict[str, dict] = {
    "low":        {"concurrent": 5,  "rate": 2.0,  "module_timeout": 600},
    "medium":     {"concurrent": 15, "rate": 8.0,  "module_timeout": 300},
    "high":       {"concurrent": 25, "rate": 20.0, "module_timeout": 180},
    "aggressive": {"concurrent": 50, "rate": 50.0, "module_timeout": 90},
}


# ─────────────────────────── Parser ─────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="phantomscan",
        description=f"PhantomScan v{VERSION} — Heuristic Web Pentest Engine",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog=_build_epilog(),
    )

    p.add_argument("target", nargs="?", default=None,
                   help="URL cible (ex: https://example.com)")

    # Meta
    meta = p.add_argument_group("Meta")
    meta.add_argument("--preset", choices=list(PRESETS.keys()), default=None,
                      help="Profil de scan prédéfini (bb|fast|full|stealth|api|recon)")
    meta.add_argument("--rate-preset", choices=list(RATE_PRESETS.keys()), default=None,
                      dest="rate_preset", metavar="LEVEL",
                      help="Rate preset : low|medium|high|aggressive")
    meta.add_argument("--dry-run", action="store_true", dest="dry_run",
                      help="Affiche les modules actifs sans exécuter le scan")
    meta.add_argument("--list-modules", action="store_true", dest="list_modules",
                      help="Liste tous les modules disponibles et quitte")
    meta.add_argument("--save-profile", type=str, default=None, dest="save_profile",
                      metavar="PATH", help="Sauvegarde la configuration en JSON réutilisable")
    meta.add_argument("--load-profile", type=str, default=None, dest="load_profile",
                      metavar="PATH", help="Charge une configuration depuis un fichier JSON")
    # v5.13 — Bug bounty helpers
    meta.add_argument("--early-stop", type=int, default=0, dest="early_stop",
                      metavar="N",
                      help="Arrête après N findings CRITICAL/HIGH et écrit le rapport [0=off]")
    meta.add_argument("--oob-url", type=str, default=None, dest="oob_url",
                      metavar="URL",
                      help="URL OOB interactsh/Burp Collaborator pour SSRF/Log4Shell blind")
    meta.add_argument("--stream", type=str, default=None, dest="stream_output",
                      metavar="PATH",
                      help="Écrit chaque finding en JSONL sur disque en temps réel")
    meta.add_argument("--bb-report", type=str, default=None, dest="bb_report",
                      metavar="PATH",
                      help="Génère un rapport Markdown format Bug Bounty (Hackerone/Bugcrowd)")
    # v5.19 — Bug Bounty intelligence
    meta.add_argument("--auth-profile", action="append", default=[], dest="auth_profiles",
                      metavar="SPEC",
                      help="Profil d'auth 'name:type:value' (ex: 'alice:cookie:session=abc'). "
                           "Répétable. Types : cookie, header, bearer. "
                           "≥2 profils → IDOR/BOLA testés cross-user.")
    meta.add_argument("--oob", type=str, default=None, dest="oob_backend",
                      metavar="SPEC",
                      help="Backend OOB pour vulns blind. Valeurs : "
                           "'interactsh' (auto via oast.fun), "
                           "'interactsh:server.tld' (self-hosted), "
                           "'custom:my.canary.tld' (DNS qu'on monitore)")
    meta.add_argument("--md", type=str, default=None, dest="output_markdown",
                      metavar="PATH",
                      help="Rapport Markdown BB-ready avec PoC curl + Burp request")
    meta.add_argument("--md-per-finding", type=str, default=None,
                      dest="output_markdown_per_finding_dir",
                      metavar="DIR",
                      help="Dossier où écrire un .md par finding (soumissions séparées)")
    meta.add_argument("--cvss-override", action="store_true", dest="cvss_override_severity",
                      help="Force la severity calculée par CVSS (par défaut : on garde "
                           "la severity du module qui est souvent plus contextuelle)")

    # Network
    net = p.add_argument_group("Network")
    net.add_argument("-t", "--timeout",     type=int,   default=15,   help="Timeout (s) [15]")
    net.add_argument("-r", "--retries",     type=int,   default=3,    help="Retries [3]")
    net.add_argument("-c", "--concurrent",  type=int,   default=20,   help="Concurrence max [20]")
    net.add_argument("--rate",              type=float, default=10.0, help="Rate limit req/s [10]")
    net.add_argument("--proxy",             type=str,   default=None,
                     help="Proxy (ex: http://127.0.0.1:8080)")
    net.add_argument("--no-redirect",       action="store_true",
                     help="Ne pas suivre les redirections")
    net.add_argument("--cookie",            type=str,   default=None,
                     help="Cookies session (k=v; k2=v2)")
    net.add_argument("--header",            action="append", default=[], metavar="H",
                     help="Header custom (répétable, ex: -H 'Authorization: Bearer xxx')")
    net.add_argument("--user-agent",        type=str,   default=None, dest="user_agent",
                     help="User-Agent fixe (désactive la rotation automatique)")

    # Modules globaux
    mods = p.add_argument_group("Modules")
    mods.add_argument("--no-recon",    action="store_true", help="Désactiver recon")
    mods.add_argument("--no-vulns",    action="store_true", help="Désactiver scan vulns")
    mods.add_argument("--no-fuzz",     action="store_true", help="Désactiver fuzzing")
    mods.add_argument("--only-vulns",  type=str, default=None,
                      help="Vulns à activer (ex: ssrf,sqli,xss,nosql,otp)")
    mods.add_argument("--wordlist",    type=str, default=None, help="Wordlist custom")
    mods.add_argument("--fuzz-depth",  type=int, default=3,   help="Profondeur fuzzing [3]")
    mods.add_argument("--lfi-depth",   type=int, default=3,   help="Profondeur traversal LFI [3]")
    mods.add_argument("--module-concurrency", type=int, default=4, dest="module_concurrency",
                      help="Modules vulns exécutés en parallèle [4]")
    mods.add_argument("--module-timeout", type=int, default=300,
                      help="Timeout par module (s) [300]")

    # Scope
    scope_grp = p.add_argument_group("Scope")
    scope_grp.add_argument("--scope", type=str, default=None,
                           help="Domaines autorisés (virgule-séparés, ex: example.com,api.example.com)")

    # Vuln module toggles
    vuln_flags = p.add_argument_group("Vuln modules (désactiver)")
    vuln_flags.add_argument("--no-sqli",                action="store_true")
    vuln_flags.add_argument("--no-xss",                 action="store_true")
    vuln_flags.add_argument("--no-lfi",                 action="store_true")
    vuln_flags.add_argument("--no-ssti",                action="store_true")
    vuln_flags.add_argument("--no-cmdi",                action="store_true")
    vuln_flags.add_argument("--no-xxe",                 action="store_true")
    vuln_flags.add_argument("--no-ssrf",                action="store_true")
    vuln_flags.add_argument("--no-crlf",                action="store_true")
    vuln_flags.add_argument("--no-idor",                action="store_true")
    vuln_flags.add_argument("--no-jwt",                 action="store_true")
    vuln_flags.add_argument("--no-open-redirect",       action="store_true", dest="no_open_redirect")
    vuln_flags.add_argument("--no-auth-bypass",         action="store_true", dest="no_auth_bypass")
    vuln_flags.add_argument("--no-headers",             action="store_true", dest="no_headers")
    vuln_flags.add_argument("--no-cache-poison",        action="store_true", dest="no_cache_poison")
    vuln_flags.add_argument("--no-prototype-pollution", action="store_true", dest="no_prototype_pollution")
    vuln_flags.add_argument("--no-graphql",             action="store_true", dest="no_graphql")
    vuln_flags.add_argument("--no-file-upload",         action="store_true", dest="no_file_upload")
    vuln_flags.add_argument("--no-actuator",            action="store_true", dest="no_actuator",
                            help="Désactiver le scan Spring Boot Actuator")
    vuln_flags.add_argument("--no-waf-fingerprint",     action="store_true", dest="no_waf_fingerprint",
                            help="Désactiver le fingerprinting WAF")
    vuln_flags.add_argument("--no-oauth",               action="store_true", dest="no_oauth",
                            help="Désactiver la détection misconfigs OAuth2/OIDC")
    vuln_flags.add_argument("--no-path-traversal",      action="store_true", dest="no_path_traversal",
                            help="Désactiver le scan path traversal avancé")
    vuln_flags.add_argument("--no-log4shell",           action="store_true", dest="no_log4shell",
                            help="Désactiver le scan Log4Shell (CVE-2021-44228)")
    vuln_flags.add_argument("--log4shell-canary",       type=str, default=None, dest="log4shell_canary",
                            metavar="HOST",
                            help="Canary OOB Log4Shell (ex: XXXX.oastify.com)")
    vuln_flags.add_argument("--no-tls-audit",           action="store_true", dest="no_tls_audit",
                            help="Désactiver l'audit TLS/SSL")
    vuln_flags.add_argument("--no-http-smuggling",      action="store_true", dest="no_http_smuggling",
                            help="Désactiver le scan HTTP Request Smuggling (CL.TE / TE.CL)")
    vuln_flags.add_argument("--no-deserialization",     action="store_true", dest="no_deserialization",
                            help="Désactiver le scan désérialisation non sécurisée (Java/PHP/Pickle)")
    vuln_flags.add_argument("--no-s3",                  action="store_true", dest="no_s3",
                            help="Désactiver l'énumération buckets S3/GCS/Azure Blob")
    vuln_flags.add_argument("--no-cors",                action="store_true", dest="no_cors",
                            help="Désactiver le scan CORS")
    vuln_flags.add_argument("--no-forbidden-bypass",    action="store_true", dest="no_forbidden_bypass",
                            help="Désactiver le bypass 403/401 (headers, verbs, path tricks)")
    vuln_flags.add_argument("--no-rate-limit",          action="store_true", dest="no_rate_limit",
                            help="Désactiver le test de rate limiting")
    # v5.7
    vuln_flags.add_argument("--no-dom-xss",             action="store_true", dest="no_dom_xss",
                            help="Désactiver l'analyse DOM XSS source→sink statique")
    vuln_flags.add_argument("--no-json-api",            action="store_true", dest="no_json_api",
                            help="Désactiver le fuzzing JSON/REST API body injection")
    # v5.8
    vuln_flags.add_argument("--no-nosql",               action="store_true", dest="no_nosql",
                            help="Désactiver le scan NoSQL Injection (MongoDB, Firebase, CouchDB)")
    vuln_flags.add_argument("--no-openapi",             action="store_true", dest="no_openapi",
                            help="Désactiver le recon OpenAPI/Swagger (spec exposée, endpoints unauth)")
    vuln_flags.add_argument("--no-takeover",            action="store_true", dest="no_takeover",
                            help="Désactiver la détection subdomain takeover (50+ providers)")
    vuln_flags.add_argument("--no-otp",                 action="store_true", dest="no_otp",
                            help="Désactiver le scan 2FA/OTP bypass (brute, skip, race, null)")
    vuln_flags.add_argument("--no-csrf",                action="store_true", dest="no_csrf",
                            help="Désactiver le scan CSRF (tokens, SameSite, Origin validation)")
    vuln_flags.add_argument("--no-clickjacking",        action="store_true", dest="no_clickjacking",
                            help="Désactiver le scan clickjacking (X-Frame-Options, CSP frame-ancestors)")
    vuln_flags.add_argument("--no-race",                action="store_true", dest="no_race_condition",
                            help="Désactiver le scan race conditions (TOCTOU, double-spend, parallel submit)")
    # v5.10 — flags manquants (BUG : ces modules existaient dans engine mais n'étaient pas contrôlables en CLI)
    vuln_flags.add_argument("--no-websocket",       action="store_true", dest="no_websocket",
                            help="Désactiver le scan WebSocket (CSWSH, WS injection, auth bypass)")
    vuln_flags.add_argument("--no-jwt-advanced",    action="store_true", dest="no_jwt_advanced",
                            help="Désactiver le scan JWT avancé (none-alg, weak secret, kid injection, jku SSRF)")
    vuln_flags.add_argument("--no-business-logic",  action="store_true", dest="no_business_logic",
                            help="Désactiver le scan business logic (price tampering, mass assignment, coupon stacking)")
    vuln_flags.add_argument("--no-api-security",    action="store_true", dest="no_api_security",
                            help="Désactiver le scan API security (versioning abuse, debug endpoints, method override)")
    vuln_flags.add_argument("--no-param-miner",     action="store_true", dest="no_param_miner",
                            help="Désactiver le Param Miner (découverte de paramètres cachés)")
    vuln_flags.add_argument("--no-git-exposure",    action="store_true", dest="no_git_exposure",
                            help="Désactiver la détection Git/SVN/HG exposés + extraction secrets")
    # v5.15 — nouveaux modules BB
    vuln_flags.add_argument("--no-host-header",     action="store_true", dest="no_host_header",
                            help="Désactiver le scan Host Header Injection (reset poisoning, cache poison, vhost bypass)")
    vuln_flags.add_argument("--no-dep-confusion",   action="store_true", dest="no_dep_confusion",
                            help="Désactiver le scan Dependency Confusion (packages internes exposés, registries privés)")
    vuln_flags.add_argument("--no-mass-assignment", action="store_true", dest="no_mass_assignment",
                            help="Désactiver le scan Mass Assignment (champs privilégiés acceptés sur API REST/JSON)")
    # v5.16 — nouveaux modules BB
    vuln_flags.add_argument("--no-exposed-panels",      action="store_true", dest="no_exposed_panels",
                            help="Désactiver la détection de panneaux admin/monitoring exposés (Jenkins, Grafana, phpMyAdmin...)")
    vuln_flags.add_argument("--no-api-key-exposure",    action="store_true", dest="no_api_key_exposure",
                            help="Désactiver la détection de clés API/secrets exposés (AWS, Stripe, JWT, .env files)")
    vuln_flags.add_argument("--no-open-redirect-chain", action="store_true", dest="no_open_redirect_chain",
                            help="Désactiver le scan Open Redirect avancé (OAuth chain, bypass, account takeover)")
    vuln_flags.add_argument("--no-account-takeover",   action="store_true", dest="no_account_takeover",
                            help="Désactiver le scanner Account Takeover")
    vuln_flags.add_argument("--no-xpath",               action="store_true", dest="no_xpath",
                            help="Désactiver le scanner XPath Injection")
    vuln_flags.add_argument("--no-email-injection",     action="store_true", dest="no_email_injection",
                            help="Désactiver le scanner Email Header Injection")
    vuln_flags.add_argument("--no-api-versioning",      action="store_true", dest="no_api_versioning",
                            help="Désactiver le scanner API Versioning")
    vuln_flags.add_argument("--no-sitemap-recon",       action="store_true", dest="no_sitemap_recon",
                            help="Désactiver le Sitemap/robots.txt recon")
    vuln_flags.add_argument("--no-cloud-recon",         action="store_true", dest="no_cloud_recon",
                            help="Désactiver la découverte de buckets cloud")
    vuln_flags.add_argument("--no-spa-crawler",         action="store_true", dest="no_spa_crawler",
                            help="Désactiver le SPA endpoint extractor")


    # Network modules toggles
    network_mods = p.add_argument_group("Network modules")
    network_mods.add_argument("--no-vhost",      action="store_true", dest="no_vhost",
                              help="Désactiver la découverte de virtual hosts")
    network_mods.add_argument("--no-port-scan",  action="store_true", dest="no_port_scan",
                              help="Désactiver le port scan")

    # Recon toggles
    recon_flags = p.add_argument_group("Recon toggles")
    recon_flags.add_argument("--no-subdomain",         action="store_true")
    recon_flags.add_argument("--no-crawl",             action="store_true")
    recon_flags.add_argument("--no-js",                action="store_true")
    recon_flags.add_argument("--no-tech",              action="store_true")
    recon_flags.add_argument("--subdomain-bruteforce", action="store_true", dest="subdomain_bruteforce",
                             help="Activer le brute-force DNS (wordlist intégrée ou --wordlist)")
    recon_flags.add_argument("--no-wayback",           action="store_true", dest="no_wayback",
                             help="Désactiver le scraping Wayback Machine")
    recon_flags.add_argument("--dork",                 action="store_true", dest="google_dork",
                             help="Activer le Google Dorking (désactivé par défaut)")
    recon_flags.add_argument("--no-dns",               action="store_true", dest="no_dns",
                             help="Désactiver l'énumération DNS (SPF, DKIM, DMARC, AXFR)")
    recon_flags.add_argument("--no-secrets",           action="store_true", dest="no_secrets",
                             help="Désactiver le scan de fichiers publics pour secrets")
    recon_flags.add_argument("--crawl-depth",          type=int, default=200, dest="crawl_depth",
                             help="Nombre max de pages à crawler [200]")

    # IDOR session swap
    idor_flags = p.add_argument_group("IDOR session swap")
    idor_flags.add_argument("--alt-cookie",    type=str, default=None, metavar="COOKIES",
                            help="Cookies du second compte pour session swap IDOR (k=v; k2=v2)")
    idor_flags.add_argument("--alt-bearer",    type=str, default=None, metavar="TOKEN",
                            help="Bearer token du second compte pour session swap IDOR")

    # Heuristic
    heur = p.add_argument_group("Heuristic")
    heur.add_argument("--baseline-n",     type=int, default=5)
    heur.add_argument("--no-waf",         action="store_true")

    # Output
    out = p.add_argument_group("Output")
    out.add_argument("-o", "--output",      type=str, default=None,
                    help="Fichier de sortie (extension auto selon --format)")
    out.add_argument("--output-dir",        type=str, default=None, dest="output_dir",
                    help="Dossier de sortie (nom horodaté si --output absent)")
    out.add_argument("--format",            type=str, default="json",
                    choices=["json", "html", "markdown", "all"], dest="report_format",
                    help="Format du rapport : json|html|markdown|all [json]")
    out.add_argument("-v", "--verbose",     action="count", default=0,
                    help="Verbosité : -v normal, -vv très verbeux, -vvv debug")
    out.add_argument("-s", "--silent",      action="store_true",
                    help="Masquer les findings INFO")
    out.add_argument("--no-color",          action="store_true", dest="no_color",
                    help="Désactiver les couleurs ANSI")

    return p


def _build_epilog() -> str:
    lines = [
        "Exemples:",
        "  phantomscan https://example.com --preset fast -o /tmp/report",
        "  phantomscan https://api.example.com --preset api --format all --output-dir ./results",
        "  phantomscan https://example.com --only-vulns sqli,xss,nosql --scope example.com",
        "  phantomscan https://example.com --preset stealth --proxy http://127.0.0.1:8080",
        "  phantomscan https://example.com --dry-run",
        "  phantomscan --list-modules",
        "",
        "Presets disponibles:",
    ]
    for name, preset in PRESETS.items():
        lines.append(f"  {name:<12}  {preset['_desc']}")
    return "\n".join(lines)


# ─────────────────────────── Helpers ────────────────────────────────────────

def parse_cookies(cookie_str: str | None) -> dict:
    if not cookie_str:
        return {}
    cookies = {}
    for part in cookie_str.split(";"):
        part = part.strip()
        if "=" in part:
            k, _, v = part.partition("=")
            cookies[k.strip()] = v.strip()
    return cookies


def parse_headers(header_list: list[str]) -> dict:
    headers = {}
    for item in header_list:
        if ":" in item:
            k, _, v = item.partition(":")
            headers[k.strip()] = v.strip()
    return headers


def parse_scope(scope_str: str | None) -> list[str]:
    if not scope_str:
        return []
    return [d.strip().lower() for d in scope_str.split(",") if d.strip()]


_VULN_MAP: dict[str, str] = {
    "idor": "idor",
    "auth_bypass": "auth_bypass", "auth": "auth_bypass",
    "headers": "headers_injection",
    "cache": "cache_poison", "cache_poison": "cache_poison",
    "crlf": "crlf",
    "ssrf": "ssrf",
    "redirect": "open_redirect", "open_redirect": "open_redirect",
    "sqli": "sqli", "sql": "sqli",
    "xss": "xss",
    "xxe": "xxe",
    "ssti": "ssti",
    "cmdi": "cmdi", "cmd": "cmdi",
    "jwt": "jwt",
    "proto": "prototype_pollution", "prototype_pollution": "prototype_pollution",
    "graphql": "graphql_injection", "graphql_injection": "graphql_injection",
    "upload": "file_upload", "file_upload": "file_upload",
    "lfi": "lfi",
    "actuator": "actuator", "spring": "actuator",
    "waf": "waf_fingerprint", "waf_fingerprint": "waf_fingerprint",
    "oauth": "oauth_misconfig", "oauth_misconfig": "oauth_misconfig",
    "path_traversal": "path_traversal", "traversal": "path_traversal",
    "log4shell": "log4shell", "log4j": "log4shell",
    "tls": "tls_audit", "tls_audit": "tls_audit", "ssl": "tls_audit",
    "smuggling": "http_smuggling", "http_smuggling": "http_smuggling",
    "deserialization": "deserialization", "deser": "deserialization",
    "s3": "s3_enum", "s3_enum": "s3_enum",
    "cors": "cors",
    "forbidden": "forbidden_bypass", "forbidden_bypass": "forbidden_bypass",
    "rate_limit": "rate_limit", "ratelimit": "rate_limit",
    "dom_xss": "dom_xss", "domxss": "dom_xss",
    "json_api": "json_api", "jsonapi": "json_api",
    # v5.8
    "nosql": "nosql_injection", "nosql_injection": "nosql_injection",
    "openapi": "open_api_recon", "swagger": "open_api_recon",
    "open_api_recon": "open_api_recon",
    "takeover": "subdomain_takeover", "subdomain_takeover": "subdomain_takeover",
    "otp": "otp_bypass", "2fa": "otp_bypass", "mfa": "otp_bypass",
    "otp_bypass": "otp_bypass",
    # v5.9
    "csrf": "csrf",
    "clickjacking": "clickjacking", "xframe": "clickjacking",
    "race": "race_condition", "race_condition": "race_condition", "toctou": "race_condition",
    # v5.10
    "websocket": "websocket_scan", "ws": "websocket_scan", "websocket_scan": "websocket_scan",
    "jwt_advanced": "jwt_advanced", "jwt_adv": "jwt_advanced",
    "business_logic": "business_logic", "bizlogic": "business_logic", "logic": "business_logic",
    "api_security": "api_security", "apisec": "api_security",
    # v5.15
    "host_header": "host_header_injection", "host_header_injection": "host_header_injection",
    "reset_poison": "host_header_injection", "hostheader": "host_header_injection",
    "dep_confusion": "dependency_confusion", "dependency_confusion": "dependency_confusion",
    "depcnf": "dependency_confusion", "supply_chain": "dependency_confusion",
    "mass_assign": "mass_assignment", "mass_assignment": "mass_assignment",
    "massassign": "mass_assignment", "over_posting": "mass_assignment",
    # v5.16
    "panels": "exposed_panels", "exposed_panels": "exposed_panels",
    "admin_panel": "exposed_panels", "jenkins": "exposed_panels",
    "grafana": "exposed_panels", "kibana": "exposed_panels",
    "api_key": "api_key_exposure", "api_key_exposure": "api_key_exposure",
    "secrets": "api_key_exposure", "leaked_keys": "api_key_exposure",
    "env_file": "api_key_exposure", "credentials": "api_key_exposure",
    "redirect_chain": "open_redirect_chain", "open_redirect_chain": "open_redirect_chain",
    "oauth_redirect": "open_redirect_chain", "redirect_bypass": "open_redirect_chain",
}

_ALL_VULN_ATTRS: list[str] = [
    "idor", "auth_bypass", "headers_injection", "cache_poison", "crlf",
    "ssrf", "open_redirect", "sqli", "xss", "xxe", "ssti", "cmdi",
    "jwt", "prototype_pollution", "graphql_injection", "file_upload", "lfi",
    "actuator", "waf_fingerprint", "oauth_misconfig", "path_traversal",
    "log4shell", "tls_audit", "http_smuggling", "deserialization", "s3_enum",
    "cors", "forbidden_bypass", "rate_limit", "dom_xss", "json_api",
    "nosql_injection", "open_api_recon", "subdomain_takeover", "otp_bypass",
    # v5.9
    "csrf", "clickjacking", "race_condition",
    # v5.10
    "websocket_scan", "jwt_advanced", "business_logic", "api_security",
    # v5.15
    "host_header_injection", "dependency_confusion", "mass_assignment",
    # v5.16
    "exposed_panels", "api_key_exposure", "open_redirect_chain", "account_takeover", "xpath_injection", "email_injection", "api_versioning"
]


def parse_only_vulns(only: str | None, scan: ScanConfig) -> None:
    if only is None:
        return
    for attr in _ALL_VULN_ATTRS:
        setattr(scan, attr, False)
    for token in only.split(","):
        token = token.strip().lower()
        if token in _VULN_MAP:
            setattr(scan, _VULN_MAP[token], True)
        else:
            print(f"[!] Vuln inconnue ignorée : '{token}'. Tokens valides: {', '.join(sorted(set(_VULN_MAP.keys())))}", file=sys.stderr)


def apply_preset(args: argparse.Namespace, preset_name: str) -> None:
    preset = dict(PRESETS[preset_name])
    preset.pop("_desc", None)
    for key, val in preset.items():
        if not hasattr(args, key):
            setattr(args, key, val)
        else:
            # Pour les booléens flags (action="store_true"), le default est False.
            # Le preset écrase uniquement si l'utilisateur n'a pas explicitement mis True.
            current = getattr(args, key)
            if isinstance(val, bool) and isinstance(current, bool):
                # Si la valeur courante est toujours le défaut False, appliquer le preset
                if current is False and val is True:
                    setattr(args, key, val)
                elif current is True and val is False:
                    # L'utilisateur a mis True, on respecte ça
                    pass
            else:
                setattr(args, key, val)


def apply_rate_preset(args: argparse.Namespace, rate_preset_name: str) -> None:
    for key, val in RATE_PRESETS[rate_preset_name].items():
        setattr(args, key, val)


# ─────────────────────────── Build config ───────────────────────────────────

def _resolve_output(args: argparse.Namespace, fmt: str) -> str | None:
    from datetime import datetime
    output = getattr(args, "output", None)
    output_dir = getattr(args, "output_dir", None)
    ext = {"json": "json", "html": "html", "markdown": "md"}.get(fmt, fmt)

    if output:
        # Supprimer l'extension si déjà présente
        base = str(output)
        for e in (".json", ".html", ".md", ".markdown"):
            if base.endswith(e):
                base = base[:-len(e)]
                break
        return f"{base}.{ext}"

    elif output_dir:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        target_slug = (
            args.target
            .replace("https://", "").replace("http://", "")
            .replace("/", "_").rstrip("_")[:30]
        )
        path = Path(output_dir) / f"phantomscan_{target_slug}_{ts}.{ext}"
        return str(path)

    return None


def build_config(args: argparse.Namespace) -> PhantomConfig:
    if getattr(args, "rate_preset", None):
        apply_rate_preset(args, args.rate_preset)

    network = NetworkConfig(
        timeout=args.timeout,
        max_retries=args.retries,
        max_concurrent=args.concurrent,
        rate_limit_rps=args.rate,
        follow_redirects=not args.no_redirect,
    )

    scan = ScanConfig(
        recon=not args.no_recon,
        fuzz=not args.no_fuzz,
        vulns=not args.no_vulns,
        fuzz_depth=args.fuzz_depth,
        lfi_depth=args.lfi_depth,
        baseline_requests=args.baseline_n,
        waf_detect=not args.no_waf,
        module_timeout=args.module_timeout,
        module_concurrency=args.module_concurrency,
        output_json=_resolve_output(args, "json"),
        verbose=args.verbose > 0,
        silent=args.silent,
        crawl_max_pages=getattr(args, "crawl_depth", 200),
        # Vulns
        sqli=not args.no_sqli,
        xss=not args.no_xss,
        lfi=not args.no_lfi,
        ssti=not args.no_ssti,
        cmdi=not args.no_cmdi,
        xxe=not args.no_xxe,
        ssrf=not args.no_ssrf,
        crlf=not args.no_crlf,
        idor=not args.no_idor,
        jwt=not args.no_jwt,
        open_redirect=not args.no_open_redirect,
        auth_bypass=not args.no_auth_bypass,
        headers_injection=not args.no_headers,
        cache_poison=not args.no_cache_poison,
        prototype_pollution=not args.no_prototype_pollution,
        graphql_injection=not args.no_graphql,
        file_upload=not args.no_file_upload,
        actuator=not args.no_actuator,
        waf_fingerprint=not args.no_waf_fingerprint,
        oauth_misconfig=not args.no_oauth,
        path_traversal=not args.no_path_traversal,
        log4shell=not args.no_log4shell,
        tls_audit=not args.no_tls_audit,
        # v5.4 (manquaient dans l'ancien CLI)
        http_smuggling=not getattr(args, "no_http_smuggling", False),
        deserialization=not getattr(args, "no_deserialization", False),
        s3_enum=not getattr(args, "no_s3", False),
        # Offensive (manquaient aussi)
        cors=not getattr(args, "no_cors", False),
        forbidden_bypass=not getattr(args, "no_forbidden_bypass", False),
        rate_limit=not getattr(args, "no_rate_limit", False),
        # v5.7
        dom_xss=not getattr(args, "no_dom_xss", False),
        json_api=not getattr(args, "no_json_api", False),
        # v5.8
        nosql_injection=not getattr(args, "no_nosql", False),
        open_api_recon=not getattr(args, "no_openapi", False),
        subdomain_takeover=not getattr(args, "no_takeover", False),
        otp_bypass=not getattr(args, "no_otp", False),
        # v5.9
        csrf=not getattr(args, "no_csrf", False),
        clickjacking=not getattr(args, "no_clickjacking", False),
        race_condition=not getattr(args, "no_race_condition", False),
        # v5.10 — BUG FIX : ces modules n'étaient pas passés depuis le CLI
        websocket_scan=not getattr(args, "no_websocket", False),
        jwt_advanced=not getattr(args, "no_jwt_advanced", False),
        business_logic=not getattr(args, "no_business_logic", False),
        api_security=not getattr(args, "no_api_security", False),
        param_miner=not getattr(args, "no_param_miner", False),
        git_exposure=not getattr(args, "no_git_exposure", False),
        # v5.15 — nouveaux modules BB
        host_header_injection=not getattr(args, "no_host_header", False),
        dependency_confusion=not getattr(args, "no_dep_confusion", False),
        mass_assignment=not getattr(args, "no_mass_assignment", False),
        # v5.16 — nouveaux modules BB
        exposed_panels=not getattr(args, "no_exposed_panels", False),
        api_key_exposure=not getattr(args, "no_api_key_exposure", False),
        open_redirect_chain=not getattr(args, "no_open_redirect_chain", False),
        # v5.21 — Nouveaux modules
        account_takeover=not getattr(args, "no_account_takeover", False),
        xpath_injection=not getattr(args, "no_xpath", False),
        email_injection=not getattr(args, "no_email_injection", False),
        api_versioning=not getattr(args, "no_api_versioning", False),
        sitemap_recon=not getattr(args, "no_sitemap_recon", False),
        cloud_recon=not getattr(args, "no_cloud_recon", False),
        spa_crawler=not getattr(args, "no_spa_crawler", False),
        # Network modules
        vhost_discovery=not getattr(args, "no_vhost", False),
        port_scan=not getattr(args, "no_port_scan", False),
        # Recon
        subdomain_enum=not args.no_subdomain,
        crawl=not args.no_crawl,
        js_analysis=not args.no_js,
        tech_detect=not args.no_tech,
        subdomain_bruteforce=args.subdomain_bruteforce,
        wayback_scrape=not args.no_wayback,
        google_dork=args.google_dork,
        dns_enum=not args.no_dns,
        secrets_finder=not args.no_secrets,
        # Scope
        scope_domains=parse_scope(getattr(args, "scope", None)),
        # v5.13 — Bug bounty
        early_stop_after=getattr(args, "early_stop", 0),
        stream_output=getattr(args, "stream_output", None),
        ssrf_oob_url=getattr(args, "oob_url", None) or "",
        # v5.19 — Bug Bounty intelligence
        auth_profiles=getattr(args, "auth_profiles", []) or [],
        oob_backend=getattr(args, "oob_backend", None),
        output_markdown=getattr(args, "output_markdown", None) or getattr(args, "bb_report", None),
        output_markdown_per_finding_dir=getattr(args, "output_markdown_per_finding_dir", None),
        cvss_override_severity=getattr(args, "cvss_override_severity", False),
    )

    parse_only_vulns(args.only_vulns, scan)

    return PhantomConfig(
        target=args.target,
        network=network,
        scan=scan,
        proxy=args.proxy,
        cookies=parse_cookies(args.cookie),
        headers=parse_headers(args.header),
        wordlist_path=args.wordlist,
        alt_cookies=parse_cookies(args.alt_cookie),
        alt_bearer_token=args.alt_bearer,
        log4shell_canary=args.log4shell_canary,
    )


# ─────────────────────────── Dry run / list ─────────────────────────────────

def dry_run(config: PhantomConfig) -> None:
    scan = config.scan
    print(f"\n  PhantomScan v{VERSION} — DRY RUN")
    print(f"  Target    : {config.target}")
    print(f"  Proxy     : {config.proxy or 'None'}")
    print(f"  Rate      : {config.network.rate_limit_rps} req/s")
    print(f"  Concurrent: {config.network.max_concurrent}")
    print(f"  Scope     : {scan.scope_domains or 'All'}")
    print()

    if scan.recon:
        recon_modules = {
            "SubdomainEnumerator": scan.subdomain_enum,
            "Crawler":             scan.crawl,
            "JSAnalyzer":          scan.js_analysis,
            "TechDetector":        scan.tech_detect,
            "WaybackScraper":      scan.wayback_scrape,
            "GoogleDorker":        scan.google_dork,
            "DNSEnumerator":       scan.dns_enum,
            "SecretsFinder":       scan.secrets_finder,
        }
        print("  RECON:")
        for name, enabled in recon_modules.items():
            print(f"    {'✓' if enabled else '✗'} {name}")

    if scan.vulns:
        vuln_modules = [
            ("SQLiScanner",               scan.sqli),
            ("XSSScanner",                scan.xss),
            ("LFIScanner",                scan.lfi),
            ("SSTIScanner",               scan.ssti),
            ("CMDiScanner",               scan.cmdi),
            ("XXEScanner",                scan.xxe),
            ("SSRFScanner",               scan.ssrf),
            ("CRLFScanner",               scan.crlf),
            ("IDORScanner",               scan.idor),
            ("JWTScanner",                scan.jwt),
            ("RedirectScanner",           scan.open_redirect),
            ("AuthBypassScanner",         scan.auth_bypass),
            ("HeadersScanner",            scan.headers_injection),
            ("CachePoisonScanner",        scan.cache_poison),
            ("PrototypePollutionScanner", scan.prototype_pollution),
            ("GraphQLInjectionScanner",   scan.graphql_injection),
            ("FileUploadScanner",         scan.file_upload),
            ("ActuatorScanner",           scan.actuator),
            ("WAFFingerprintScanner",     scan.waf_fingerprint),
            ("OAuth2MisconfigScanner",    scan.oauth_misconfig),
            ("PathTraversalScanner",      scan.path_traversal),
            ("Log4ShellScanner",          scan.log4shell),
            ("TLSAuditScanner",           scan.tls_audit),
            ("HTTPSmugglingScanner",      scan.http_smuggling),
            ("DeserializationScanner",    scan.deserialization),
            ("S3EnumScanner",             scan.s3_enum),
            ("CORSScanner",               scan.cors),
            ("ForbiddenBypassScanner",    scan.forbidden_bypass),
            ("RateLimitScanner",          scan.rate_limit),
            ("DOMXSSAnalyzer",            scan.dom_xss),
            ("JSONAPIScanner",            scan.json_api),
            ("NoSQLInjectionScanner",     scan.nosql_injection),
            ("OpenAPIReconScanner",       scan.open_api_recon),
            ("SubdomainTakeoverScanner",  scan.subdomain_takeover),
            ("OTPBypassScanner",          scan.otp_bypass),
            # v5.9
            ("CSRFScanner",               scan.csrf),
            ("ClickjackingScanner",       scan.clickjacking),
            ("RaceConditionScanner",      scan.race_condition),
            # v5.10
            ("WebSocketScanner",          scan.websocket_scan),
            ("JWTAdvancedScanner",        scan.jwt_advanced),
            ("BusinessLogicScanner",      scan.business_logic),
            ("APISecurityScanner",        scan.api_security),
        ]
        enabled_count = sum(1 for _, e in vuln_modules if e)
        print(f"\n  VULNS ({enabled_count}/{len(vuln_modules)} actifs):")
        for name, enabled in vuln_modules:
            print(f"    {'✓' if enabled else '✗'} {name}")

    if scan.fuzz:
        print(f"\n  FUZZ:")
        print(f"    ✓ SmartFuzzer (depth={scan.fuzz_depth})")

    # Recon extra (v5.10)
    recon_extra = {
        "ParamMinerScanner":  getattr(scan, "param_miner", True),
        "GitExposureScanner": getattr(scan, "git_exposure", True),
    }
    if any(recon_extra.values()):
        print(f"\n  RECON EXTRA (v5.10):")
        for name, enabled in recon_extra.items():
            print(f"    {'✓' if enabled else '✗'} {name}")

    # Network modules
    network_mods = {
        "VHostDiscovery": getattr(scan, "vhost_discovery", True),
        "PortScanner":    getattr(scan, "port_scan", True),
    }
    print(f"\n  NETWORK:")
    for name, enabled in network_mods.items():
        print(f"    {'✓' if enabled else '✗'} {name}")

    print()


def list_modules() -> None:
    print(f"\n  PhantomScan v{VERSION} — Modules disponibles\n")
    categories = {
        "Recon": [
            "SubdomainEnumerator", "Crawler", "JSAnalyzer", "TechDetector",
            "WaybackScraper", "GoogleDorker", "DNSEnumerator", "SecretsFinder",
            "GitExposureScanner [v5.10]", "ParamMinerScanner [v5.10]",
        ],
        "Vulns (injection)": [
            "SQLiScanner", "NoSQLInjectionScanner [v5.8]", "XSSScanner",
            "SSTIScanner", "CMDiScanner", "XXEScanner", "LFIScanner",
            "PathTraversalScanner", "SSRFScanner", "CRLFScanner",
        ],
        "Vulns (auth/session)": [
            "IDORScanner", "JWTScanner", "JWTAdvancedScanner [v5.10]",
            "AuthBypassScanner", "OAuth2MisconfigScanner",
            "OTPBypassScanner [v5.8]", "ForbiddenBypassScanner",
        ],
        "Vulns (web/infra)": [
            "HeadersScanner", "CachePoisonScanner", "PrototypePollutionScanner",
            "GraphQLInjectionScanner", "FileUploadScanner", "RedirectScanner",
            "CORSScanner", "DOMXSSAnalyzer [v5.7]", "JSONAPIScanner [v5.7]",
            "CSRFScanner [v5.9]", "ClickjackingScanner [v5.9]",
            "RaceConditionScanner [v5.9]", "WebSocketScanner [v5.10]",
        ],
        "Vulns (infra/cloud)": [
            "ActuatorScanner", "WAFFingerprintScanner", "Log4ShellScanner",
            "TLSAuditScanner", "HTTPSmugglingScanner", "DeserializationScanner",
            "S3EnumScanner", "OpenAPIReconScanner [v5.8]",
            "SubdomainTakeoverScanner [v5.8]", "RateLimitScanner",
        ],
        "Vulns (business/API)": [
            "BusinessLogicScanner [v5.10]", "APISecurityScanner [v5.10]",
            "MassAssignmentScanner [v5.15]",
        ],
        "Vulns (supply chain / infra)": [
            "HostHeaderInjectionScanner [v5.15]",
            "DependencyConfusionScanner [v5.15]",
            "ExposedPanelsScanner [v5.16]",
            "APIKeyExposureScanner [v5.16]",
            "MassAssignmentScanner [v5.15]",
        ],
        "Vulns (redirect / OAuth / ATO)": [
            "OpenRedirectChainScanner [v5.16]",
            "AccountTakeoverScanner [v5.21]",
        ],
        "Vulns (injection spécialisée)": [
            "XPathInjectionScanner [v5.21]",
            "EmailInjectionScanner [v5.21]",
            "APIVersioningScanner [v5.21]",
        ],
        "Network": [
            "VHostDiscovery", "PortScanner",
        ],
        "Recon (cloud + SPA)": [
            "SitemapReconScanner [v5.21]",
            "CloudReconScanner [v5.21]",
            "SPACrawler [v5.21]",
        ],
        "Fuzz": ["SmartFuzzer"],
        "Post-scan": ["CorrelationEngine (12 règles composites)"],
    }
    for cat, mods in categories.items():
        print(f"  {cat}:")
        for m in mods:
            print(f"    • {m}")
        print()


# ─────────────────────────── Profile ────────────────────────────────────────

def save_profile(args: argparse.Namespace, path: str) -> None:
    skip = {"save_profile", "load_profile", "dry_run", "list_modules"}
    data = {k: v for k, v in vars(args).items() if k not in skip}
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)
    print(f"  [+] Profil sauvegardé → {path}")


def load_profile(args: argparse.Namespace, path: str) -> None:
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    for k, v in data.items():
        # Ne pas écraser les valeurs déjà posées par l'utilisateur en CLI
        if getattr(args, k, None) in (None, False, 0):
            setattr(args, k, v)
    print(f"  [+] Profil chargé ← {path}")


# ─────────────────────────── Main ───────────────────────────────────────────

async def async_main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    # --list-modules (pas besoin de target)
    if getattr(args, "list_modules", False):
        list_modules()
        return 0

    # --load-profile avant tout le reste
    if args.load_profile:
        load_profile(args, args.load_profile)

    # Valider la target
    if not args.target:
        parser.print_help()
        print("\n[!] Erreur : URL cible requise.", file=sys.stderr)
        return 1

    # Normaliser l'URL
    if not args.target.startswith(("http://", "https://")):
        args.target = "https://" + args.target

    # Appliquer preset (après que les args CLI sont parsés, le preset ne gagne
    # que sur les valeurs encore à leur défaut)
    if args.preset:
        apply_preset(args, args.preset)

    # Couleurs
    if getattr(args, "no_color", False):
        os.environ["NO_COLOR"] = "1"

    # Créer output_dir
    output_dir = getattr(args, "output_dir", None)
    if output_dir:
        Path(output_dir).mkdir(parents=True, exist_ok=True)

    config = build_config(args)

    # --save-profile
    if args.save_profile:
        save_profile(args, args.save_profile)

    # --dry-run
    if getattr(args, "dry_run", False):
        dry_run(config)
        return 0

    from phantomscan.core.engine import Engine
    engine = Engine(config)

    try:
        result = await engine.run()

        # Export multi-format
        fmt = getattr(args, "report_format", "json")
        formats_to_write = ["json", "html", "markdown"] if fmt == "all" else [fmt]
        for f in formats_to_write:
            path = _resolve_output(args, f)
            if not path:
                continue
            if f == "json":
                engine._reporter.write_json(result, path)
            elif f == "html":
                if hasattr(engine._reporter, "write_html"):
                    engine._reporter.write_html(result, path)
                else:
                    print(f"  [!] Format HTML non disponible dans ce build", file=sys.stderr)
            elif f == "markdown":
                if hasattr(engine._reporter, "write_markdown"):
                    engine._reporter.write_markdown(result, path)
                else:
                    print(f"  [!] Format Markdown non disponible dans ce build", file=sys.stderr)

        # v5.13 — Bug Bounty report
        # v5.19 — bb-report et --md sont maintenant gérés directement par l'Engine
        # via cfg.scan.output_markdown (cf bb_markdown.write_markdown_report).
        # On garde un fallback pour les builds anciens qui exposeraient write_bb_report.
        bb_report_path = getattr(args, "bb_report", None)
        if bb_report_path and hasattr(engine._reporter, "write_bb_report"):
            try:
                engine._reporter.write_bb_report(result, bb_report_path)
                print(f"  [BB] Rapport bug bounty → {bb_report_path}")
            except Exception:
                pass  # silencieux : le nouveau chemin via Engine a déjà écrit le rapport

        if result.critical_count > 0:
            return 2
        if result.high_count > 0:
            return 1
        return 0

    except KeyboardInterrupt:
        print("\n[!] Interrompu par l'utilisateur.")
        return 130
    except asyncio.CancelledError:
        print("\n[!] Tâche annulée.")
        return 130
    except Exception as e:
        print(f"[FATAL] {e}", file=sys.stderr)
        if args.verbose >= 2:
            import traceback
            traceback.print_exc()
        return 1


def main():
    sys.exit(asyncio.run(async_main()))


if __name__ == "__main__":
    main()
