# PhantomScan — CHANGELOG v5.13.0 (bug bounty edition)

## Résumé

Cinq améliorations ciblées pour un usage bug bounty : nouveau preset dédié,
arrêt anticipé sur findings exploitables, streaming JSONL live, scoring
d'endpoints enrichi, et rapport Markdown format soumission directe.

---

## 1. Preset `--preset bb` (CLI + config)

### Problème
Les presets existants (`fast`, `full`, `stealth`) n'étaient pas optimisés pour
les programmes bug bounty : `fast` désactiverait des modules à haute valeur
(SSTI, CMDi, LFI, deserialization, HTTP smuggling), et `full` inclut le
port_scan et le vhost_discovery qui sont hors scope dans la majorité des
programmes.

### Changements
- Nouveau preset `bb` dans `PRESETS` : tous les modules injection/auth/logic ON,
  clickjacking OFF (P5, rarement accepté), rate modéré (8 rps, 15 concurrent)
  pour ne pas déclencher de ban automatique.
- `crawl_depth` à 300 (plus exhaustif que `fast` mais moins que `full`).
- Compatible avec `--early-stop` et `--oob-url` pour un workflow BB complet.

**Usage typique :**
```bash
phantomscan https://target.com --preset bb --oob-url https://xxxx.oast.fun \
  --early-stop 3 --stream /tmp/live.jsonl --bb-report report.md
```

---

## 2. `--early-stop N` — arrêt après N findings HIGH/CRITICAL

### Problème
En bug bounty, trouver le premier finding exploitable est souvent plus
rentable que finir un scan complet. Un scan `full` de 40+ modules peut
prendre 30-60 min ; si un SQLi CRITICAL est trouvé à la 5e minute, les
55 minutes restantes sont inutiles.

### Changements
- Nouveau flag CLI `--early-stop N` (défaut 0 = désactivé).
- Nouveau champ `ScanConfig.early_stop_after: int = 0`.
- `Engine._flush_pending()` incrémente un compteur `_high_critical_count`.
  Quand `>= early_stop_after`, lève un flag `_early_stop_triggered`.
- `_collect()` et `_collect_and_feed_bus()` vérifient le flag avant chaque
  itération et interrompent proprement leur générateur.

---

## 3. Streaming JSONL live — `--stream PATH`

### Problème
Les findings n'étaient écrits sur disque qu'à la fin du scan. Sur un scan
long (30+ min), impossible de grepper/monitorer les résultats en cours
d'exécution, ou d'intégrer PhantomScan dans un pipeline (ex : alert webhook
dès qu'un CRITICAL est trouvé).

### Changements
- Nouveau flag CLI `--stream PATH`.
- Nouveau champ `ScanConfig.stream_output: str | None = None`.
- Dans `Engine._flush_pending()` : chaque finding accepté est immédiatement
  sérialisé en JSON et appendé à `stream_output` (1 ligne = 1 finding).
- Compatible avec `tail -f` et `jq` pour monitoring live :
  ```bash
  tail -f /tmp/live.jsonl | jq 'select(.severity == "CRITICAL")'
  ```

---

## 4. Scoring d'endpoints amélioré (`core/intelligence.py`)

### Problème
Le scoring précédent ne prenait en compte que les noms de paramètres.
Des endpoints à fort potentiel bug bounty (admin panel, auth, checkout,
upload) sans paramètres connus étaient scorés 0.1, donc relégués en bas
de la file des vulns à tester.

### Changements
- **Nouvelle fonction `score_endpoint(url, method, params) → float`** :
  agrège un score de path + score de params + bonus méthode + bonus count.
- **`_HIGH_VALUE_PATH_PATTERNS`** : 8 familles de paths à fort enjeu BB
  (auth/login, admin, api, upload, payment, user data, config/secrets, SSRF-prone).
- **`_SENSITIVE_PARAM_PATTERNS` enrichi** : 3 nouveaux groupes (business logic,
  admin/debug params, IDOR uuids comme `uid`, `pid`, `oid`).
- **Bonus count params** : `min(0.15, n_params × 0.03)` — un endpoint avec 5
  params score +0.15 vs un endpoint avec 0 param.
- **`EndpointBus.publish()`** appelle `score_endpoint()` automatiquement si
  `ep.score == 0.0`, garantissant que tous les endpoints ont un score utile.

---

## 5. Rapport Bug Bounty Markdown — `--bb-report PATH`

### Problème
Le `write_markdown()` existant produisait un rapport technique interne mais
pas directement soumettable sur HackerOne/Bugcrowd/Intigriti : pas de CVSS,
pas de "Steps to Reproduce" formatés, structure non standard pour les plateformes.

### Changements
- **`Reporter.write_bb_report(result, path)`** : génère un rapport au format
  attendu par les plateformes BB.
- **CVSS auto-calculé** via `Reporter._auto_cvss(finding)` :
  - Utilise `finding.cvss` si déjà défini.
  - Sinon, mappe le titre/module sur `_CVSS_MAP` (60+ entrées : RCE=9.8,
    SSRF=8.6, XSS=6.1, Clickjacking=4.3, etc.).
  - Fallback sur un score par sévérité (CRITICAL→9.0, HIGH→7.5, etc.).
- **Structure par finding** : tableau metadata, Description, PoC/Evidence,
  Steps to Reproduce, Remediation — chaque section prête à copier-coller.
- **Findings INFO exclus** du rapport BB (valeur nulle pour les soumissions).
- **Flag CLI `--bb-report PATH`** : génère le rapport en fin de scan,
  en plus du rapport JSON/Markdown classique.

---

## Nouveaux flags CLI

| Flag | Défaut | Description |
|------|--------|-------------|
| `--preset bb` | — | Preset bug bounty (tous modules inj/auth, rate modéré) |
| `--early-stop N` | `0` | Arrêt après N CRITICAL/HIGH (0 = désactivé) |
| `--oob-url URL` | — | URL interactsh/Collaborator (alias de `ssrf_oob_url`) |
| `--stream PATH` | — | Streaming JSONL live des findings |
| `--bb-report PATH` | — | Rapport Markdown format HackerOne/Bugcrowd |

---

## Fichiers modifiés

| Fichier | Changements |
|---------|-------------|
| `config.py` | `early_stop_after`, `stream_output`, version 5.13.0 |
| `cli/main.py` | Preset `bb`, `--early-stop`, `--oob-url`, `--stream`, `--bb-report` |
| `core/engine.py` | Early stop dans `_flush_pending`/`_collect`, streaming JSONL |
| `core/intelligence.py` | `score_endpoint()`, `_HIGH_VALUE_PATH_PATTERNS`, params enrichis |
| `output/reporter.py` | `write_bb_report()`, `_auto_cvss()`, `_CVSS_MAP` |
