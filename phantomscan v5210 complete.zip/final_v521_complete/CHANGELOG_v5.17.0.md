# PhantomScan v5.17.0 — Changelog

## Intelligence améliorée

### ContextualMutator (`core/intelligence.py`)
Génère des payloads adaptés au **contexte de réflexion** détecté dans la réponse baseline,
au lieu d'utiliser des listes génériques pour tous les endpoints.

**Fonctionnement :**
- Envoie un sentinel inoffensif (`ph4nt0m_s3nt1nel`) sur l'endpoint
- Analyse la réponse pour détecter OÙ la valeur est réfléchie :
  `JSON_VALUE`, `XML_NODE`, `HTML_ATTR`, `HEADER_VALUE`, `PATH_SEGMENT`, `QUERY_PARAM`, `COOKIE`
- Retourne des payloads XSS/SQLi/SSTI/SSRF optimisés pour ce contexte précis

**Exemple :** un paramètre réfléchi dans un JSON body reçoit des payloads de breakout JSON
(`","xss":"<script>`) plutôt que des payloads HTML bruts — bien plus efficaces et moins
susceptibles d'être bloqués par les WAF.

```python
mutator = ContextualMutator()
ctx = mutator.detect_context(resp.body, sentinel, resp.content_type)
payloads = mutator.mutate("test", ctx, vuln_type="xss")
```

---

### SmartRetryOracle (`core/intelligence.py`)
Quand un payload est **bloqué par un WAF** (403/406/429), génère automatiquement des
variantes encodées/obfusquées pour contourner les signatures superficielles.

**10 stratégies d'encodage :**
1. Double URL-encoding (`%3C` → `%253C`)
2. Mixed case (`<ScRiPt>`)
3. SQL comment injection (`SE/**/LECT`)
4. HTML entities (`<` → `&#60;`)
5. Unicode escape (`\u003c`)
6. Null byte injection (`%00<`)
7. Newline injection (`%0a`)
8. Tab substitution
9. Sélection adaptée au contexte d'injection

```python
oracle = SmartRetryOracle()
for variant in oracle.variants(blocked_payload, context="sqli"):
    resp = await req.get(url, params={"id": variant})
    if not is_waf_block(resp):
        break
```

---

### PatternMemory (`core/intelligence.py`)
**Mémoire persistante** des payloads confirmés pendant le scan. Les patterns qui ont
fonctionné sur un endpoint sont proposés en priorité pour les endpoints similaires.

**Logique :**
- Un SQLi time-based confirmé sur `/api/users?id=` → mémorisation du payload + param + contexte
- Quand un module teste `/api/orders?id=` → PatternMemory suggère ce payload avec un score de confiance élevé
- Gestion des scores (boost sur même param + même contexte, bonus sur prefix de chemin similaire)
- `hot_prefixes()` expose les zones à forte densité de vulns pour l'Engine

```python
memory.record_success("sqli", "id", "1 AND SLEEP(5)--", QUERY_PARAM, "/api/users")
suggestions = memory.suggest_payloads("sqli", "id", QUERY_PARAM, "/api/orders")
# → [("1 AND SLEEP(5)--", 0.95), ...]
```

---

### TimingOracle (`core/heuristic.py`)
Oracle statistique robuste pour les attaques **blind time-based** (SQLi, CMDi, SSTI).

**Problèmes résolus par rapport au timing heuristic basique :**
- **Variance réseau** : calibration sur N mesures baseline par endpoint, pas une valeur globale
- **Seuil adaptatif** : si le réseau est instable (stdev élevée), le seuil monte automatiquement
- **Multi-probe** : N mesures sous payload + cohérence requise pour confirmer
- **Score de confiance 0-100** multi-critères :
  - Délai absolu ≥ seuil
  - Ratio vs baseline ≥ 2.5x
  - Delta ≈ expected_delay
  - Cohérence multi-probes
  - Variance faible des probes

```python
oracle = TimingOracle(heuristic)
await oracle.calibrate(req, url, params={"id": "1"}, n=3)
result = await oracle.probe(req, url, params={"id": "1 AND SLEEP(5)--"}, expected_delay=5.0)
if result.is_delay_confirmed:
    print(f"Time-based confirmed: delta={result.delta:.1f}s, confidence={result.confidence}%")
```

---

## 8 Nouvelles règles de corrélation (`core/correlation.py`)

| ID | Règle | Sévérité |
|---|---|---|
| CORR-017 | CORS permissif + OAuth misconfig → Vol de token OAuth | CRITICAL |
| CORR-018 | XSS + Absence de CSP → Exfiltration de session | CRITICAL |
| CORR-019 | LFI + Log Poisoning → RCE via log contaminé | CRITICAL |
| CORR-020 | SQLi + Credentials JS → Compromission DB complète | CRITICAL |
| CORR-021 | SSRF + Cache interne (Redis) → RCE gopher:// | CRITICAL |
| CORR-022 | Host Header Injection + Password Reset → Reset Poisoning | CRITICAL |
| CORR-023 | Open Redirect + OAuth → Account Takeover P1 BB | CRITICAL |
| CORR-024 | Dependency Confusion + CI/CD Exposé → Supply Chain RCE | CRITICAL |

Le moteur de corrélation passe de **16 → 24 règles** (+50%).

---

## Fichiers modifiés
- `core/intelligence.py` : +579 lignes (`ContextualMutator`, `SmartRetryOracle`, `PatternMemory`)
- `core/heuristic.py` : +180 lignes (`TimingOracle`)
- `core/correlation.py` : +248 lignes (CORR-017 à CORR-024)
- `config.py` : VERSION → 5.17.0
