# PhantomScan — CHANGELOG v5.7.0

## Résumé des changements

---

### 1. Phase passive avant attaque + Baselines par endpoint
**Fichiers modifiés :** `core/heuristic.py`, `core/engine.py`

**Problème résolu :**
Le scanner passait directement à l'attaque sans phase d'apprentissage. La
baseline était construite sur une seule requête vers la homepage — un endpoint
`/api/users/42` comparait ses réponses à la page d'accueil, générant des faux
positifs massifs sur les tailles et status codes.

**Solution :**
- `HeuristicEngine.build_endpoint_baselines(urls, n=3)` : nouvelle méthode qui
  envoie N requêtes normales sur chaque endpoint découvert et construit un
  `Baseline` individuel (status, taille, timing, dynamisme) par URL.
- `HeuristicEngine.get_baseline_for(url)` : retourne la baseline spécifique à
  l'URL testée si disponible, sinon fallback sur la baseline globale.
- `HeuristicEngine.analyze()` et `is_real_hit()` : utilisent désormais
  `get_baseline_for(resp.url)` au lieu de `self._baseline` directement.
- Dans `Engine.run()` : nouvelle phase "Passive crawl" qui lance le crawler
  silencieusement AVANT les modules d'attaque, alimente le bus, puis appelle
  `build_endpoint_baselines()` sur tous les endpoints découverts.

**Impact :** Réduction drastique des faux positifs sur les endpoints dont le
comportement diffère de la homepage. Chaque endpoint est jugé par rapport à
lui-même, pas à une page arbitraire.

---

### 2. DOM XSS Analyzer
**Nouveau fichier :** `modules/vulns/dom_xss.py` → `DOMXSSAnalyzer`
**Activé par :** `ScanConfig.dom_xss = True`

**Problème résolu :**
Le XSSScanner ne testait que le XSS réfléchi côté serveur. Les vulnérabilités
DOM XSS (via `document.location`, `innerHTML`, `eval()`, sources/sinks JS)
passaient complètement à travers.

**Solution :**
Analyseur statique JS qui :
1. Découvre tous les fichiers `.js` via le bus d'endpoints et les balises
   `<script src>` de la page cible.
2. Pour chaque fichier JS, identifie les **sources DOM** contrôlables par
   l'attaquant : `location.search`, `location.hash`, `document.referrer`,
   `window.name`, `URLSearchParams`, `postMessage data`, etc.
3. Identifie les **sinks dangereux** : `innerHTML`, `eval()`, `document.write`,
   `Function()`, `setTimeout(string)`, `location.href =`, etc.
4. Corrèle source→sink dans une fenêtre de 30 lignes, pénalise si un
   sanitiseur (`DOMPurify`, `encodeURIComponent`, `textContent`) est détecté.
5. Score de confiance 0–100% selon la proximité source/sink.

**Catégories de sinks :**
| Sink | Sévérité |
|------|----------|
| `eval()`, `Function()` | CRITICAL |
| `innerHTML`, `document.write`, `insertAdjacentHTML` | HIGH |
| `location.href =`, `src =`, `jQuery .html()` | MEDIUM |

---

### 3. JSON/REST API Scanner
**Nouveau fichier :** `modules/vulns/json_api.py` → `JSONAPIScanner`
**Activé par :** `ScanConfig.json_api = True`

**Problème résolu :**
Les modules SQLi, XSS, SSTI n'injectaient qu'en form-urlencoded ou query
string. Si la cible répond en `application/json` et consomme des corps JSON,
aucun payload n'était testé dans le body JSON.

**Solution :**
- Détection automatique : endpoints qui retournent `application/json` ou
  acceptent `Content-Type: application/json`.
- Inférence de schéma depuis la réponse GET (`_infer_schema()`).
- Injection dans chaque champ string du body JSON :
  - **SQLi** : error-based (messages d'erreur DB) + time-based (double confirmation)
  - **XSS** : réflexion du marker dans la réponse JSON/HTML
  - **SSTI** : `{{7*7}}`, `${7*7}`, `<%= 7*7 %>` → résultat `49`
  - **SSRF** : URLs IMDS/loopback → indicateurs dans la réponse
  - **Path traversal** : `../../../etc/passwd` → `root:x:0:0`
- Fonction `_inject_at_path()` pour injecter profondément dans des objets JSON
  imbriqués.

---

### 4. Corrélation inter-findings
**Nouveau fichier :** `core/correlation.py` → `CorrelationEngine`

**Problème résolu :**
Les findings étaient indépendants. Aucune logique ne détectait qu'un SSRF + un
S3 bucket ouvert = exfiltration possible, ou qu'un JWT faible + un IDOR =
usurpation d'identité complète.

**Solution :**
12 règles de corrélation post-scan implémentées :

| ID | Règle | Sévérité |
|----|-------|----------|
| CORR-001 | SSRF + S3 ouvert → Exfiltration | CRITICAL |
| CORR-002 | SSRF + IMDS → Vol de rôle IAM | CRITICAL |
| CORR-003 | XSS + absence CSP → Exploitation sans contrainte | HIGH |
| CORR-004 | SQLi + Credentials exposés → Compromission DB | CRITICAL |
| CORR-005 | OAuth misconfig + CORS ouvert → Vol de tokens | CRITICAL |
| CORR-006 | JWT vulnérable + IDOR → Usurpation cross-user | CRITICAL |
| CORR-007 | HTTP Smuggling + XSS → Cache empoisonné | CRITICAL |
| CORR-008 | Deserialization + CMDi → RCE multi-vecteur | CRITICAL |
| CORR-009 | Path Traversal + LFI → Lecture fichiers double vecteur | HIGH |
| CORR-010 | SSTI + CMDi → RCE multi-moteur | CRITICAL |
| CORR-011 | Open Redirect + XSS → Phishing / Account takeover | HIGH |
| CORR-012 | LFI + Secrets exposés → Credential dump | CRITICAL |

Les findings composites sont générés en fin de scan (phase "Correlation") et
injectés dans `result.findings` avec `module="correlation"` et le préfixe
`[COMPOSITE]` dans le titre.

---

### 5. Rate adaptatif par module
**Fichiers modifiés :** `config.py`, `core/requester.py`, `core/engine.py`

**Problème résolu :**
Tous les modules partageaient le même rate limit global. Les modules lents
(SQLi time-based = 15s/req, HTTP smuggling) consommaient le budget des modules
rapides, allongeant inutilement la durée totale du scan.

**Solution :**
- `ScanConfig.module_rps_overrides` : dict `{cls_name: float}` définissant le
  budget rps propre à chaque module.
- `Requester.set_active_module(cls_name)` : méthode appelée par l'engine avant
  et après chaque module (`try/finally`).
- Dans `Requester.send()` : si un module actif a son propre `TokenBucket`,
  c'est celui-là qui est consommé (pas le bucket global).

**Budgets par défaut (configurables) :**
| Module | RPS |
|--------|-----|
| SQLiScanner | 1.0 |
| HTTPSmugglingScanner | 0.5 |
| CMDiScanner | 2.0 |
| DeserializationScanner | 1.0 |
| Log4ShellScanner | 1.0 |
| HeadersScanner | 20.0 |
| CRLFScanner | 15.0 |
| CORSScanner | 15.0 |
| JSONAPIScanner | 5.0 |
| DOMXSSAnalyzer | 8.0 |

---

## Fichiers créés / modifiés

| Fichier | Action | Description |
|---------|--------|-------------|
| `modules/vulns/dom_xss.py` | **NOUVEAU** | DOM XSS source→sink analyzer |
| `modules/vulns/json_api.py` | **NOUVEAU** | JSON/REST API injection scanner |
| `core/correlation.py` | **NOUVEAU** | Post-scan correlation engine (12 règles) |
| `core/heuristic.py` | modifié | Baselines par endpoint, `build_endpoint_baselines()` |
| `core/engine.py` | modifié | Phase passive, correlation, module rate tracking |
| `core/requester.py` | modifié | `set_active_module()`, module TokenBuckets |
| `config.py` | modifié | `module_rps_overrides`, `dom_xss`, `json_api` flags |
