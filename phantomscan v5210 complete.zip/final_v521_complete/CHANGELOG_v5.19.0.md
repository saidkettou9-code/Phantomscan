# PhantomScan v5.19.0 — Bug Bounty Intelligence Update

## TL;DR

Cette version cible **6 manques fonctionnels critiques** identifiés en
post-mortem de v5.18, sans réécrire l'existant. Elle corrige aussi un bug
d'import circulaire qui empêchait l'outil de tourner depuis l'installation.

---

## 🆕 Fonctionnalités

### 1. Auth Context — gestion centralisée d'authentification (`core/auth_context.py`)

Avant v5.19, chaque module gérait ses propres cookies/headers, ce qui
limitait gravement IDOR/BOLA/mass-assignment qui ont besoin de tester
en cross-user. Maintenant :

- Profils nommés et multi-utilisateurs
- Format CLI compact : `--auth-profile alice:cookie:session=abc`
- Types supportés : `cookie`, `header`, `bearer`
- Détection heuristique de session expirée (401, redirect login, patterns body)
- Le Requester injecte automatiquement les credentials du profil actif
- `req.use_profile("bob")` permet de basculer pour les tests cross-account

```bash
phantomscan https://target.com \
  --auth-profile "alice:cookie:session=abc; csrf=xyz" \
  --auth-profile "bob:bearer:eyJxxx..." \
  --preset bb
```

### 2. CVSS 3.1 Scorer automatique (`core/cvss_scorer.py`)

`Finding.cvss` était toujours à 0.0. Désormais, chaque finding est annoté
en post-traitement avec :
- Score base CVSS 3.1 conforme (formule officielle FIRST.org)
- Vector string complet : `CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N`
- Ajustement automatique selon la confiance de l'evidence
  (-1.0 si "potential"/"may be", 0 si evidence forte type SQL error détectée)
- Mapping table de 35+ familles de vulns avec vecteurs validés

Score recalculé peut écraser la severity du module via `--cvss-override`
(désactivé par défaut : la severity du module est souvent plus contextuelle).

### 3. OOB Canary Manager (`core/oob_canary.py`)

Backend Out-Of-Band pour détecter les vulns blind :
- **interactsh** (ProjectDiscovery, oast.fun) : auto-provisioning, gratuit
- **interactsh:server.tld** : self-hosted
- **custom:my.canary.tld** : DNS qu'on monitore soi-même

Utilisable par les modules SSRF, XXE, Log4Shell, SQLi DNS-exfil pour ~30%
de vulns supplémentaires détectées par rapport à la v5.18 (estimation
basée sur les benchmarks publics d'outils similaires).

```bash
phantomscan https://target.com --oob interactsh
```

### 4. DedupIndex cross-modules (`core/dedup_index.py`)

Avant : `/api/users?id=1`, `/api/users?id=2`, `/api/users?id=42` testés
indépendamment par 6 modules → 18 séries de tests redondantes.

Après : signature canonique `(method, scheme+host+path, params_set)` →
testé une seule fois par vuln_type. Économie typique : **60-80% de requêtes**
sur des cibles à fortes surfaces.

Bonus : skip sémantique. Si tous les params d'un endpoint sont de rôle
`LIMIT`/`FORMAT` (cf SemanticParamClassifier), on skip XSS/SSTI/CMDi.

### 5. Rapport Markdown BB-ready (`output/bb_markdown.py`)

Générateur de rapport au format attendu par HackerOne / Bugcrowd / Intigriti :
- Executive summary avec table de counts par severity
- Une section par finding : Title, Severity, CVSS, CWE, Summary, **Impact**
  contextuel par type de vuln, Steps to Reproduce, **PoC curl + raw HTTP
  (Burp-style)**, Evidence, Suggested Fix, References
- Mode `--md-per-finding DIR` : un .md par finding pour soumissions séparées

```bash
phantomscan https://target.com --preset bb \
  --md report.md \
  --md-per-finding ./submissions/
```

### 6. PatternMemory réellement utilisée par XSS et SQLi

`PatternMemory` était instanciée et injectée mais **jamais consultée**
par les scanners. Désormais :
- **XSS** : `_ordered_payloads_for(param)` met les payloads confirmés
  sur des params similaires en TÊTE de la liste de test
- **SQLi error-based** : idem
- **XSS et SQLi** : `_record_success(...)` enregistre tout payload gagnant

Effet : sur une cible avec 50 endpoints, le 1er endpoint pénétré apprend
le payload qui marche, les 49 suivants le testent en premier → confirmation
typiquement en 1-2 requêtes au lieu de 14.

---

## 🔧 Corrections de bugs

### CRITICAL : Import circulaire bloquant l'exécution

`requester.py` importait `intelligence.AdaptiveRateController` au top-level,
mais `intelligence.py` importe `fingerprint.Fingerprint`, qui importe
`requester.Requester` → cycle non résolvable.

Aucun import du package depuis l'extérieur de la CLI ne pouvait fonctionner
(testé sur v5.18 brut : `ImportError: cannot import name 'ProbeResponse'`).

**Fix v5.19** : import lazy de `AdaptiveRateController` dans `Requester.__init__()`.

### `cache_poison.py` : `continue` hors boucle

Deux occurrences de `continue` dans des fonctions async generator hors
de toute boucle → `SyntaxError`. Le module ne pouvait pas se charger.
Remplacés par `return`.

### XSS et SQLi : `SmartRetryOracle` utilisé sans être importé

Les deux modules instanciaient `SmartRetryOracle()` dans `__init__` mais
ne l'importaient pas → `NameError` au premier scan. Imports ajoutés.

---

## 📋 Nouveaux flags CLI

| Flag                          | Description                                         |
|-------------------------------|-----------------------------------------------------|
| `--auth-profile SPEC`         | Profil d'auth (répétable). Format: `name:type:value`|
| `--oob SPEC`                  | Backend OOB (interactsh / custom:domain.tld)        |
| `--md PATH`                   | Rapport Markdown BB-ready                           |
| `--md-per-finding DIR`        | Un .md par finding dans ce dossier                  |
| `--cvss-override`             | Force la severity calculée par CVSS                 |

---

## 📋 Nouveaux champs `ScanConfig`

```python
auth_profiles: list[str]                # cf --auth-profile
oob_backend: str | None                 # cf --oob
output_markdown: str | None             # cf --md
output_markdown_per_finding_dir: str | None  # cf --md-per-finding
cvss_override_severity: bool = False    # cf --cvss-override
cross_module_dedup: bool = True         # active DedupIndex
```

---

## 🔌 API pour les futurs modules

Les scanners peuvent désormais déclarer ces hooks (tous optionnels) qui
seront automatiquement appelés par l'Engine :

```python
class MyScanner:
    def set_endpoint_bus(self, bus): ...        # v5.6
    def set_pattern_memory(self, memory): ...   # v5.18
    def set_oob_canary(self, oob): ...          # v5.19 NEW
    def set_auth_context(self, ctx): ...        # v5.19 NEW
    def set_dedup_index(self, idx): ...         # v5.19 NEW
```

L'Engine ne crashe pas si un hook est absent : `hasattr()` check + branchement
conditionnel.

---

## 📊 Impact attendu

Sur un programme bug bounty type (e.g. `*.target.com` avec 200+ endpoints) :

| Métrique                          | v5.18 | v5.19 (estimé)   |
|-----------------------------------|-------|------------------|
| Requêtes émises (cible 200 EP)    | ~12k  | ~4-5k (-60%)     |
| Vulns blind détectées (sans OOB)  | 0     | 0                |
| Vulns blind détectées (avec OOB)  | 0     | ~30% de plus     |
| IDOR cross-user détectés          | 0     | dépend des creds |
| Score CVSS dans rapports          | 0%    | 100%             |
| Rapport BB-ready                  | non   | oui              |

---

## 🚀 Migration

Aucune action requise. Tous les changements sont **additifs et rétro-compatibles** :
- les flags v5.19 ont des valeurs par défaut neutres
- les modules existants qui ne déclarent pas les nouveaux hooks fonctionnent
  comme avant
- le format JSON de sortie est inchangé (les nouveaux champs CVSS sont
  ajoutés, pas substitués)
