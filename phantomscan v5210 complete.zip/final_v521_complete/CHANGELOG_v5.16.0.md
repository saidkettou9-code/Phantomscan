# PhantomScan v5.16.0 — Changelog

## Nouveaux modules Bug Bounty (v5.16)

### ExposedPanelsScanner
Détecte les panneaux d'administration et de monitoring exposés sans authentification
ou accessibles avec des credentials par défaut.

**Panneaux couverts (50+) :**
- **DevOps/CI** : Jenkins, Portainer, ArgoCD, Grafana, Drone CI, Concourse CI
- **Monitoring** : Kibana, Prometheus, Netdata, Traefik Dashboard, Jaeger, Zipkin
- **Database Admin** : phpMyAdmin, Adminer, pgAdmin, MongoDB Express, Redis Commander,
  Elasticsearch (`/_cat/indices`, `/_cluster/health`), CouchDB, RabbitMQ Management
- **Infra/Cloud** : Consul UI, Vault UI/API, Nomad UI, etcd, Kong Admin, Eureka
- **API Docs** : Swagger UI, OpenAPI/SpringDoc, Spring Boot Admin, Spring Actuator (`/actuator/env`, `/actuator/heapdump`)
- **App Admin** : Django Admin, Laravel Telescope/Horizon, Rails Info, Strapi Admin,
  Keycloak Admin, WordPress Admin, Tomcat Manager, JBoss JMX Console

**Détections :**
- Accès direct non authentifié → **CRITICAL**
- Credentials par défaut valides (Grafana, Portainer, Kibana testés automatiquement) → **CRITICAL**
- Panel exposé sur Internet avec auth → **MEDIUM**

**Flags CLI :**
```
--no-exposed-panels    Désactiver Exposed Panels scanner
```

**Tokens --only-vulns :** `panels`, `exposed_panels`, `admin_panel`, `jenkins`, `grafana`, `kibana`

---

### APIKeyExposureScanner
Détecte les clés API, tokens secrets et credentials exposés dans les réponses HTTP,
fichiers JS, fichiers de configuration exposés et headers.

**Patterns couverts (80+) :**
- **Cloud** : AWS Access Key ID + Secret, GCP API Key, Google Service Account JSON,
  Azure Storage Key + SAS Token, Cloudflare API Key/Token
- **Paiement** : Stripe Live/Test secret + publishable + webhook, Braintree, PayPal
- **Communication** : Twilio SID + Auth Token, Sendgrid, Mailgun, Mailchimp, Mandrill
- **Auth/Identity** : JWT tokens hardcodés, JWT secret, Auth0 client secret
- **Messaging** : Slack Bot/User tokens, Slack Webhooks, Discord Bot Token + Webhook, Telegram Bot Token
- **VCS** : GitHub PAT (ghp/gho/ghu/ghs), GitLab Personal Access Token
- **Monitoring** : Datadog API Key, Sentry DSN, New Relic License Key
- **Maps** : Google Maps API Key, Mapbox Token
- **Crypto** : Binance API Key, Coinbase API Key
- **Generic** : passwords hardcodés, generic API keys, Bearer tokens, Basic Auth en URL

**Sources scannées :**
- Page principale + headers de réponse
- Fichiers config exposés : `.env`, `.env.local`, `.env.production`, `config.js`, `config.json`,
  `appsettings.json`, `docker-compose.yml`, `.npmrc`, et 15+ autres
- Bundles JS courants (`/static/js/main.js`, `/dist/app.js`...)

**Flags CLI :**
```
--no-api-key-exposure    Désactiver API Key Exposure scanner
```

**Tokens --only-vulns :** `api_key`, `api_key_exposure`, `secrets`, `leaked_keys`, `env_file`, `credentials`

---

### OpenRedirectChainScanner
Détecte les open redirects exploitables avec confirmation de l'exploitabilité réelle
et tests de chaînage vers account takeover.

**Vecteurs testés :**
- **20+ techniques de bypass** : direct, protocol-relative (`//`), quad-slash, backslash Windows,
  `@` trick (user@host), CRLF injection, null byte, double URL encoding, points encodés (%2E),
  Unicode homoglyphes, Data URI, JavaScript URI, espaces leader/trailer, path traversal
- **OAuth redirect_uri chain** : teste les endpoints OAuth/OIDC connus
  (`/oauth/authorize`, `/oauth2/authorize`, `/connect/authorize`...) avec un `redirect_uri`
  arbitraire — si accepté = CRITICAL (account takeover via code/token theft)
- **Path-based redirects** : `/redirect/URL`, `/go/URL`, `/out/URL`, `/track?redirect=`
- **Token leakage** : détection du domaine canary dans le body (meta refresh, JS location)

**Sévérité :**
- OAuth `redirect_uri` non validé → **CRITICAL** (CVSS 9.3, souvent P1 en BB)
- Open redirect sur param OAuth → **CRITICAL**
- Open redirect standard confirmé → **HIGH** (CVSS 6.1)
- Open redirect body-only → **MEDIUM**

**Flags CLI :**
```
--no-open-redirect-chain    Désactiver Open Redirect Chain scanner
```

**Tokens --only-vulns :** `redirect_chain`, `open_redirect_chain`, `oauth_redirect`, `redirect_bypass`

---

## Mise à jour globale

- `config.py` : 3 nouveaux attributs `ScanConfig` (défaut ON), RPS overrides ajoutés
- `engine.py` : 3 entrées dans `module_map` avec lazy-import
- `cli/main.py` : 3 flags `--no-*`, `_VULN_MAP` et `_ALL_VULN_ATTRS` mis à jour,
  preset `bb` et `full` mis à jour, `list_modules()` mis à jour
- `VERSION` → 5.16.0
