"""
PhantomScan — Configuration globale
"""

from __future__ import annotations
from dataclasses import dataclass, field

VERSION = "5.19.0"

USER_AGENTS: list[str] = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/124.0.0.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.82 Mobile Safari/537.36",
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
    "curl/8.7.1",
]


@dataclass
class NetworkConfig:
    timeout: int = 15
    max_retries: int = 3
    retry_delay: float = 1.0
    max_concurrent: int = 20
    rate_limit_rps: float = 10.0
    per_host_rps: float = 5.0
    follow_redirects: bool = True
    max_redirects: int = 5
    verify_ssl: bool = False


@dataclass
class ScanConfig:
    # Modules globaux
    recon: bool = True
    fuzz: bool = True
    vulns: bool = True

    # Modules vulns individuels
    idor: bool = True
    auth_bypass: bool = True
    headers_injection: bool = True
    cache_poison: bool = True
    crlf: bool = True
    ssrf: bool = True
    open_redirect: bool = True
    sqli: bool = True
    xss: bool = True
    xxe: bool = True
    ssti: bool = True
    cmdi: bool = True
    jwt: bool = True
    prototype_pollution: bool = True
    graphql_injection: bool = True
    file_upload: bool = True
    lfi: bool = True

    # Nouveau module Spring Boot Actuator
    actuator: bool = True

    # Nouveaux modules v5.4
    http_smuggling: bool = True     # CL.TE / TE.CL / TE.TE request smuggling
    s3_enum: bool = True            # Énumération buckets S3/GCS/Azure mal configurés
    deserialization: bool = True    # Détection désérialisation non sécurisée (Java/PHP/Pickle/Ruby)

    # Nouveaux modules v5.5
    waf_fingerprint: bool = True    # Fingerprinting précis du WAF (Cloudflare, Akamai, F5, Imperva...)
    oauth_misconfig: bool = True    # Misconfigs OAuth2 (open redirect redirect_uri, PKCE, token leakage)
    path_traversal: bool = True     # Path traversal avancé (encodé, double-encodé, unicode bypass)
    log4shell: bool = True          # CVE-2021-44228 Log4Shell via JNDI canary OOB
    tls_audit: bool = True          # Audit TLS/SSL (versions, ciphers, HSTS, cert expiry)

    # Offensive modules
    cors: bool = True
    forbidden_bypass: bool = True
    rate_limit: bool = True
    vhost_discovery: bool = True
    port_scan: bool = True

    # Network module options
    vhost_concurrency: int = 30
    vhost_wordlist: list = None
    port_scan_timeout: float = 3.0
    port_scan_concurrency: int = 100
    port_scan_extra_ports: list = None

    # Recon
    subdomain_enum: bool = True
    crawl: bool = True
    js_analysis: bool = True
    tech_detect: bool = True

    # Nouveaux modules recon v5.3
    wayback_scrape: bool = True     # Wayback Machine endpoint discovery
    google_dork: bool = False       # Google Dorking (désactivé par défaut — requêtes externes)
    dns_enum: bool = True           # Énumération DNS complète (SPF/DKIM/DMARC/AXFR)
    secrets_finder: bool = True     # Scan fichiers publics pour secrets/credentials

    # v5.10 — Nouveaux modules
    websocket_scan: bool = True     # Détection CSWSH, WS injection, auth bypass, mass assignment
    git_exposure: bool = True       # Détection dépôts Git/SVN/HG exposés + extraction secrets

    # OOB/Blind SSRF collaborator URL (ex: interactsh, Burp Collaborator)
    # Si défini, le SSRFScanner injecte cette URL dans les params suspects
    ssrf_oob_url: str = ""          # Ex: "https://xxxx.oast.fun"

    # Subdomain options
    subdomain_bruteforce: bool = False   # brute-force DNS (wordlist intégrée ou cfg.wordlist_path)
    subdomain_resolve: bool = True       # résolution DNS de confirmation
    subdomain_takeover: bool = True      # CNAME fingerprinting pour subdomain takeover

    # Fuzz
    smart_fuzz: bool = True
    crawl_max_pages: int = 200
    fuzz_depth: int = 3
    lfi_depth: int = 3

    # Heuristic
    baseline_requests: int = 5  # fix v5.10.2: 8 → 5 (8 surchauffe le timing stdev, faux négatifs timing)
    # v5.12 — Intervalle (en requêtes) entre deux purges du ResponseCache expiré
    # Réduire pour limiter la RAM sur scans très longs (>500 endpoints uniques)
    cache_evict_every: int = 100
    waf_detect: bool = True
    module_timeout: int = 300
    module_concurrency: int = 4

    # v5.7 — Rate adaptatif par module
    # Budget de requêtes/s propre à chaque module (None = utiliser rate_limit global)
    # Les modules lents (time-based SQLi, HTTP smuggling) ont leur propre budget
    # pour ne pas bloquer les modules rapides qui partagent le même semaphore global.
    module_rps_overrides: dict = field(default_factory=lambda: {
        # Modules lents — budget restreint pour ne pas saturer le rate limit global
        "SQLiScanner":          1.0,   # time-based peut durer 15s par requête
        "HTTPSmugglingScanner": 0.5,   # requêtes longues (CL.TE timing)
        "CMDiScanner":          2.0,   # payloads lents (sleep-based)
        "SSTIScanner":          2.0,
        "DeserializationScanner": 1.0,
        "Log4ShellScanner":     1.0,   # OOB, latence variable
        # Modules rapides — peuvent aller plus vite que le global
        "HeadersScanner":       20.0,
        "CRLFScanner":          15.0,
        "RedirectScanner":      15.0,
        "TLSAuditScanner":      5.0,   # connexions TLS, pas de payloads
        "WAFFingerprintScanner":8.0,
        "CORSScanner":          15.0,
        # DOM XSS et JSON API — vitesse modérée
        "DOMXSSAnalyzer":       8.0,
        "JSONAPIScanner":       5.0,
        # v5.8
        "NoSQLInjectionScanner": 3.0,   # time-based sleeps possibles
        "OpenAPIReconScanner":   10.0,  # lecture passive de spec
        "CORSScanner":           15.0,
        "ForbiddenBypassScanner": 8.0,
        "RateLimitScanner":       4.0,  # envoie 20+ req pour tester rate limit
        "SubdomainTakeoverScanner": 8.0,  # DNS + HTTP probes
        "OTPBypassScanner":         3.0,  # brute force léger avec délais
        "CSRFScanner":              8.0,  # probes passifs + POST test
        "ClickjackingScanner":      12.0, # lecture headers uniquement
        "RaceConditionScanner":      2.0, # envoie 20 req simultanées par endpoint
        # v5.10
        "JWTAdvancedScanner":         3.0,  # brute force secret — modéré
        "BusinessLogicScanner":       2.0,  # multiples probes par endpoint
        "APISecurityScanner":         8.0,  # lectures + probes rapides
        "ParamMinerScanner":          5.0,  # batches de 30 params
        # v5.15
        "HostHeaderInjectionScanner":  6.0,  # tests rapides, peu de payloads
        "DependencyConfusionScanner":  8.0,  # GET passifs sur fichiers statiques
        "MassAssignmentScanner":       3.0,  # PUT/PATCH par endpoint, modéré
        # v5.16
        "ExposedPanelsScanner":        5.0,  # GET par path, peu de requêtes
        "APIKeyExposureScanner":       8.0,  # GET passifs, lecture de fichiers JS/config
        "OpenRedirectChainScanner":    4.0,  # payloads multiples par param
    })

    # v5.7 — Nouveaux modules
    dom_xss: bool = True        # Analyse statique DOM XSS source→sink dans les fichiers JS
    json_api: bool = True       # Fuzzing des endpoints REST/JSON (SQLi, XSS, SSTI en body JSON)

    # v5.8 — Nouveaux modules
    nosql_injection: bool = True  # Injection NoSQL (MongoDB $ne/$gt/$where, auth bypass, time-based)
    open_api_recon: bool = True   # Recon OpenAPI/Swagger (spec exposed, unauth endpoints, secrets)
    subdomain_takeover: bool = True  # Subdomain takeover (50+ providers, NS takeover, dangling CNAME)
    otp_bypass: bool = True           # 2FA/OTP bypass (null bypass, brute force, reuse, race condition, skip)

    # v5.10 — Nouveaux modules (puissance+)
    jwt_advanced: bool = True       # JWT avancé : none-alg, weak secret brute-force, kid injection, jku SSRF
    business_logic: bool = True     # Business logic : price tampering, negative qty, mass assignment, coupon stacking
    api_security: bool = True       # API security : versioning abuse, debug endpoints, method override, field bypass
    param_miner: bool = True        # Param Miner : découverte de paramètres cachés (Burp Param Miner style)

    # v5.9 — Nouveaux modules
    csrf: bool = True             # CSRF (token manquant, SameSite absent, Origin/Referer non validé)
    clickjacking: bool = True     # Clickjacking (X-Frame-Options, CSP frame-ancestors, double-frame bypass)
    race_condition: bool = True   # Race conditions (TOCTOU, double-spend, coupon reuse, parallel submit)

    # v5.15 — Nouveaux modules BB
    host_header_injection: bool = True   # Host Header Injection (reset poisoning, cache poison, vhost bypass)
    dependency_confusion: bool = True    # Dependency Confusion (packages internes exposés, registries privés)
    mass_assignment: bool = True         # Mass Assignment (champs privilégiés acceptés sur API REST/JSON)

    # v5.16 — Nouveaux modules BB
    exposed_panels: bool = True          # Exposed Admin/Service Panels (Jenkins, Grafana, Kibana, phpMyAdmin…)
    api_key_exposure: bool = True        # API Key / Secret Exposure (AWS, Stripe, JWT, tokens dans JS/config)
    open_redirect_chain: bool = True     # Open Redirect Chain (OAuth chain, bypass, account takeover)
    # v5.21 — Nouveaux modules vuln
    account_takeover: bool = True        # Account Takeover (reset poison, session, email change)
    xpath_injection: bool = True         # XPath Injection (XML/SOAP backends)
    email_injection: bool = True         # Email Header Injection via contact forms
    api_versioning: bool = True          # Old API versions still active
    # v5.21 — Nouveaux modules recon
    sitemap_recon: bool = True           # Sitemap.xml + robots.txt parser
    cloud_recon: bool = True             # S3/Azure/GCP/Firebase bucket discovery
    spa_crawler: bool = True             # SPA endpoint extractor (React/Vue/Angular)

    # Scope filtering
    scope_domains: list[str] = field(default_factory=list)

    # Output
    output_json: str | None = None
    output_dir: str = "./phantomscan_results"
    verbose: bool = False
    silent: bool = False

    # v5.13 — Bug bounty helpers
    # Arrête le scan après N findings CRITICAL ou HIGH (0 = désactivé)
    early_stop_after: int = 0
    # Chemin vers un fichier JSONL pour le streaming live des findings (None = désactivé)
    stream_output: str | None = None

    # v5.19 — Bug Bounty intelligence
    # Liste de profils d'auth au format "name:type:value" (cf AuthContext.add_from_string)
    # ex: ["alice:cookie:session=abc", "bob:bearer:eyJ..."]
    # Permet aux modules IDOR/BOLA/mass-assignment de tester en cross-user.
    auth_profiles: list[str] = field(default_factory=list)
    # Backend OOB pour SSRF blind / Log4Shell / blind XXE
    # Valeurs : None / "interactsh" / "interactsh:server.tld" / "custom:my.canary.tld"
    oob_backend: str | None = None
    # Si True, le score CVSS recalculé écrase la severity du module.
    # Désactivé par défaut : la severity du module reste prioritaire (souvent
    # plus contextuelle que la formule générique).
    cvss_override_severity: bool = False
    # Rapport Markdown BB-ready (HackerOne/Bugcrowd style)
    output_markdown: str | None = None
    # Si défini, écrit aussi un fichier .md par finding dans ce dossier
    output_markdown_per_finding_dir: str | None = None
    # Active la dédup cross-modules (v5.19) — recommandé en mode bb pour scans
    # à fortes surfaces (>500 endpoints)
    cross_module_dedup: bool = True


@dataclass
class PhantomConfig:
    target: str = ""
    network: NetworkConfig = field(default_factory=NetworkConfig)
    scan: ScanConfig = field(default_factory=ScanConfig)
    proxy: str | None = None
    cookies: dict[str, str] = field(default_factory=dict)
    headers: dict[str, str] = field(default_factory=dict)
    wordlist_path: str | None = None

    # IDOR session swap — second jeu de credentials pour confirmer l'accès cross-account
    alt_cookies: dict[str, str] = field(default_factory=dict)
    alt_bearer_token: str | None = None

    # Log4Shell canary OOB (ex: "XXXX.oastify.com" ou Burp Collaborator)
    log4shell_canary: str | None = None

    # Output étendu — v5.8 CLI
    report_format: str = "json"       # json | html | markdown | all
    output_dir: str | None = None     # dossier de sortie auto-horodaté
    verbosity: int = 0                # 0=normal, 1=verbose, 2=très verbeux, 3=debug
    user_agent: str | None = None     # User-Agent fixe (None = rotation)
