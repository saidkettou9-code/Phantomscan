# PhantomScan v5.18.0 — Changelog

## Résumé

Version centrée sur l'**intelligence profonde** : classification sémantique des
paramètres, analyse d'entropie des réponses, graphe de flux inter-endpoints,
contrôle de taux adaptatif et payloads chaînés multi-requêtes.

---

## 1. `SemanticParamClassifier` (`core/intelligence.py`)

Classifie chaque paramètre HTTP par **rôle sémantique** pour orienter
automatiquement la sélection de payloads.

**12 rôles** : `ID`, `URL`, `PATH`, `TEMPLATE`, `CMD`, `TOKEN`, `CALLBACK`,
`QUERY`, `EMAIL`, `DATA`, `LIMIT`, `FORMAT`.

**Impact concret :**
- `file=` → LFI + Path Traversal prioritaires (pas XSS)
- `url=` → SSRF + Open Redirect (pas SQLi)
- `template=` → SSTI en priorité 1
- `cmd=` → CMDi immédiat
- `callback=` → JSONP XSS + Open Redirect

```python
clf = SemanticParamClassifier()
roles = clf.classify_params(["user_id", "redirect_url", "tpl"])
# → {"user_id": "id", "redirect_url": "url", "tpl": "template"}

modules = clf.recommended_modules_for_params(roles)
# → ["idor", "sqli", "ssrf", "open_redirect", "ssti"]

high_value = clf.high_value_params(["id", "file", "q", "debug"])
# → ["file"]  ← priorité absolue car PATH role
```

---

## 2. `ResponseEntropyAnalyzer` (`core/intelligence.py`)

Analyse l'**entropie de Shannon** des réponses HTTP pour détecter des anomalies
subtiles impossibles à voir avec du pattern matching.

**Métriques calculées :**
- `entropy` (0-8 bits) : entropie Shannon du corps
- `is_encrypted` : entropie > 7.2 = données chiffrées/compressées (oracle crypto ?)
- `is_structured` : JSON/XML/HTML structuré attendu
- `lang_hint` : `json | xml | html | sql | binary | text`
- `token_density` : densité de tokens sensibles (credentials, paths système...)

**Cas d'usage clé :**
```python
analyzer = ResponseEntropyAnalyzer()

# Détecter un oracle de chiffrement blind
diff = analyzer.compare_entropy(baseline_body, probed_body)
if diff["is_significant"] and diff["direction"] == "higher":
    # Payload a généré une sortie plus chiffrée → possible oracle

# Détecter un leak dans une réponse
result = analyzer.analyze(response_body, content_type)
if result.token_density > 0.3:
    # Beaucoup de tokens sensibles → leak potentiel
```

---

## 3. `FlowGraphAnalyzer` (`core/intelligence.py`)

Construit un **graphe orienté des flux inter-endpoints** pour identifier
les chemins d'attaque multi-étapes que les scanners traditionnels ratent.

**Graphe modélise :**
- Redirections (`redirect` edges)
- Actions de formulaires (`form_action` edges)
- Flux OAuth (`oauth_flow` edges)
- Liens envoyés par email (`email_link` edges)

**Chemins d'attaque détectés automatiquement :**
| Pattern | Attack Type | Score |
|---|---|---|
| OAuth + redirect non validé | `oauth_account_takeover` | 0.95 |
| Redirects multiples (≥2) | `open_redirect_chain` | 0.75 |
| Email link + redirect | `password_reset_poisoning` | 0.90 |

```python
flow = FlowGraphAnalyzer()
flow.ingest_bus(bus)
for path in flow.find_attack_paths():
    print(f"[{path.risk_score:.2f}] {path.attack_type}: {' → '.join(path.steps)}")
```

---

## 4. `AdaptiveRateController` (`core/intelligence.py`)

Contrôle adaptatif du taux de requêtes **par module** avec backoff exponentiel.

**Problèmes résolus vs jitter v5.7 :**
- Backoff exponentiel sur blocs WAF consécutifs (7 niveaux : 1x → 30x)
- Cooldown **indépendant par module** (XSS ralenti ≠ headers ralenti)
- Respect du header `Retry-After` (429)
- Mode **stealth automatique** si ≥5 blocs consécutifs
- Jitter ±20% pour éviter la détection de pattern temporel

```python
ctrl = AdaptiveRateController()
await ctrl.wait(module="sqli", url=target_url)
resp = await req.get(url)
ctrl.record_response(
    module="sqli",
    status=resp.status,
    latency_ms=resp.elapsed * 1000,
    retry_after=int(resp.headers.get("Retry-After", 0))
)
# Si trop de 429 → stealth mode automatique
if ctrl.is_stealth_active():
    print("Mode stealth activé — délais renforcés")
```

---

## 5. `GraphPayloadChain` (`core/intelligence.py`)

Générateur de **payloads chaînés multi-requêtes** pour les vulnérabilités
qui nécessitent plusieurs étapes dans un ordre précis.

**4 chaînes implémentées :**

| Chaîne | Étapes | Vuln |
|---|---|---|
| CSRF Harvest → Exploit | GET (récolte token) → POST (exploit) | CSRF |
| IDOR Read → Write | GET own → GET foreign → PUT foreign | IDOR |
| Race Condition | N×POST simultanés (last-byte sync) | Race Condition |
| OAuth PKCE Downgrade | GET /authorize sans code_challenge → POST /token sans verifier | OAuth |

```python
chain_gen = GraphPayloadChain()
chains = chain_gen.chains_for_endpoint(endpoint, tech_hints=["php"])
# → [ChainedPayload(name="IDOR Read→Write via `user_id`", steps=[...])]
```

---

## 6. Nouvelles règles de corrélation (CORR-025 à CORR-030)

| ID | Règle | Sévérité |
|---|---|---|
| CORR-025 | LFI + Logs accessibles → Log Poisoning → RCE | CRITICAL |
| CORR-026 | SSTI + CMDi → RCE Multi-vecteur confirmé | CRITICAL |
| CORR-027 | Mass Assignment + IDOR → Escalade de Privilèges | CRITICAL |
| CORR-028 | JWT faible + Mass Assignment → Usurpation totale | CRITICAL |
| CORR-029 | Prototype Pollution + XSS → Client-side RCE | CRITICAL |
| CORR-030 | Race Condition + Business Logic → Fraude / Double-spend | CRITICAL |

Le moteur de corrélation passe de **24 → 30 règles** (+25%).

---

## Fichiers modifiés

- `core/intelligence.py` : +899 lignes
  (`SemanticParamClassifier`, `ResponseEntropyAnalyzer`, `FlowGraphAnalyzer`,
   `AdaptiveRateController`, `GraphPayloadChain`)
- `core/correlation.py` : +165 lignes (CORR-025 à CORR-030)
- `config.py` : VERSION → 5.18.0

## Stats globales

| Métrique | v5.17.0 | v5.18.0 | Delta |
|---|---|---|---|
| Lignes `core/intelligence.py` | 1 235 | 2 134 | +899 |
| Lignes `core/correlation.py` | 953 | 1 118 | +165 |
| Règles de corrélation | 24 | 30 | +6 |
| Classes d'intelligence | 7 | 12 | +5 |
| Rôles de paramètres | 0 | 12 | +12 |

## FP-Fix Patch — phantomscan_v5180_bb_fixed5 → fixed6

### Modules corrigés

**core/heuristic.py**
- `is_real_hit`: tolérance soft-404 remplacée par un calcul adaptatif selon la taille
  de la page (< 2 KB → 8%, < 20 KB → 5%, ≥ 20 KB → 3%) au lieu d'un 6% fixe.

**modules/vulns/crlf.py**
- `_test_param`, `_test_path`, `_test_headers`: ajout de `is_real_hit(min_confidence=35)`
  avant chaque `yield Finding` — élimine les soft-404 et pages catch-all qui réfléchissent
  n'importe quel input.

**modules/vulns/redirect.py**
- `_test_param`, `_test_common_endpoints`: ajout de `is_real_hit(min_confidence=40)`
  avant chaque `yield Finding` — filtre les 302 génériques des CDN/SPA.

**modules/vulns/headers.py**
- `_host_header_injection`, `_forwarded_header_abuse`: ajout de `is_real_hit(min_confidence=35)`
  avant les checks de réflexion CANARY.

**modules/vulns/actuator.py**
- Nouveau helper `_looks_like_actuator_json()`: pour les endpoints non-triviaux
  (hors `health`, `info`, `logfile`), exige la présence de clés JSON caractéristiques
  de Spring Boot Actuator (`propertySources`, `contexts`, `threads`, etc.).
  Élimine les soft-404 JSON génériques `{"status":"ok"}`.

**modules/vulns/api_key_exposure.py**
- `_FP_VALUES` étendue (+20 placeholders courants dans les docs et templates).
- Nouveau helper `_shannon_entropy()`: filtre les patterns génériques
  (Generic API Key, Generic Secret, Bearer Token, Hardcoded Password, JWT Secret)
  dont l'entropie < 3.5 bits/char — élimine les chaînes répétitives et pseudo-clés.

**modules/vulns/cors.py**
- Check "Dangerous methods": ajout de la condition `acao != "*"` — conforme à la spec
  CORS (wildcard sans credentials n'est pas exploitable depuis un navigateur).
