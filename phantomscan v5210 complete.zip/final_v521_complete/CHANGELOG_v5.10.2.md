# PhantomScan — CHANGELOG v5.10.2 (false-positive reduction)

## Problème : faux positifs excessifs sur 6 modules

---

## Corrections

### 1. `modules/vulns/headers.py` — 3 fixes

#### Host Header Injection : `host_val in resp.body` → FP massifs
La condition `CANARY in resp.body or host_val in resp.body` déclenchait sur
n'importe quelle page contenant "localhost" ou "attacker.com" (pages d'erreur,
footers de dev, docs embarquées).

**Fix** : seule la réflexion du CANARY unique (`phantomscan-*.invalid`) déclenche.
Les valeurs génériques ("localhost", "attacker.com") ne sont plus testées via
`host_val in resp.body`.

#### `_forwarded_header_abuse` : doublon avec `_xfwd_host_cache_poisoning`
`X-Forwarded-Host` était testé dans deux méthodes, produisant deux findings
distincts pour le même vecteur.

**Fix** : suppression de `X-Forwarded-Host` dans `_forwarded_header_abuse` —
entièrement couvert par `_xfwd_host_cache_poisoning` (qui valide aussi la
cacheabilité).

#### SSRF metadata : seuil de croissance trop bas (20%)
`resp_len > orig_len * 1.2` déclenchait sur des CDN/proxy qui ajoutent des
infos de debug dans certaines réponses.

**Fix** : seuil 50% (`* 1.5`) + vérification de patterns cloud metadata réels
(`ami-id`, `instance-id`, `iam/security-credentials`) dans le body.

---

### 2. `modules/vulns/cors.py` — 2 fixes

#### Double finding `null_origin` avec credentials
Quand `label=null_origin + acac=true`, le bloc "credentials exposed" ET le
bloc dédié "null acceptée" s'exécutaient tous les deux → 2 findings identiques.

**Fix** : le bloc dédié null utilise `elif` (garde exclusive).

#### "Dangerous methods" redondant sur findings credentials
Le bloc "Dangerous methods allowed cross-origin" déclenchait même quand un
finding "credentials exposed" plus sévère venait d'être émis pour la même
origin.

**Fix** : condition `acac != "true"` — les méthodes dangereuses ne sont
signalées que si les credentials ne l'ont pas déjà été.

---

### 3. `modules/vulns/redirect.py` — 1 fix

#### `_test_common_endpoints` : endpoints déjà redirecteurs → FP
`/logout`, `/auth/callback`, etc. redirigent souvent vers un domaine externe
par défaut. Sans baseline, n'importe quel payload déclenchait un finding.

**Fix** : baseline de l'endpoint avec une valeur neutre avant les payloads.
Si le endpoint redirige déjà vers un hôte externe, il est skippé.

---

### 4. `modules/vulns/sqli.py` — 1 fix

#### Error-based : pas de vérification baseline pour les erreurs SQL pré-existantes
Sur des apps déjà buguées (erreur SQL sur la homepage), tous les params
déclenchaient en error-based même sans injection réelle.

**Fix** : pre-check du body baseline — si une signature SQL error est déjà
présente avant injection, le paramètre est ignoré pour l'error-based.

---

### 5. `modules/vulns/lfi.py` — 1 fix

#### `_body_changed` : seuil 20% fixe sur pages dynamiques → FP
Sur les pages avec variation naturelle (CSRF token, timestamps), un écart de
25% sur une requête normale déclenchait le signal de changement.

**Fix** : seuil adaptatif — 40% sur pages dynamiques (détectées par
`HeuristicEngine.baseline.is_dynamic`), 20% sur pages statiques.

---

### 6. `modules/vulns/path_traversal.py` — 1 fix

#### Ratio taille 2.5x/0.2x non adapté aux pages dynamiques
Même problème que lfi.py — variation naturelle sur pages dynamiques.

**Fix** : seuils adaptatifs — 3.5x/0.15x sur pages dynamiques,
2.5x/0.20x sur pages statiques.

---

## Fichiers modifiés

| Fichier | Fixes |
|---------|-------|
| `modules/vulns/headers.py` | Host injection FP, doublon XFH, SSRF threshold |
| `modules/vulns/cors.py` | null dedup, dangerous methods guard |
| `modules/vulns/redirect.py` | baseline common endpoints |
| `modules/vulns/sqli.py` | SQL error pre-check |
| `modules/vulns/lfi.py` | `_body_changed` dynamic threshold |
| `modules/vulns/path_traversal.py` | ratio dynamic thresholds |
