# PhantomScan v5.14.0 — Changelog

## Bug fixes critiques

### --preset full ne faisait PAS "tout tout tout"
Le preset `full` ne définissait que 6 paramètres (`no_fuzz`, `fuzz_depth`, `lfi_depth`,
`subdomain_bruteforce`, `crawl_depth`, `google_dork`). Il ne forçait **pas** explicitement
les modules v5.9 et v5.10, qui restaient à leur valeur par défaut — ce qui fonctionnait
tant que le défaut était `True`, mais était fragile et trompeur.

**Modules maintenant explicitement forcés ON dans `--preset full` :**
- Tous les modules v5.8 (nosql, openapi, takeover, otp)
- v5.9 : `csrf`, `clickjacking`, `race_condition`
- v5.10 : `websocket_scan`, `jwt_advanced`, `business_logic`, `api_security`,
  `param_miner`, `git_exposure`
- Network : `vhost_discovery`, `port_scan`
- Recon : tous (subdomain, crawl, js, tech, wayback, dns, secrets)

### build_config() ne passait pas les modules v5.10 à ScanConfig
Les modules `websocket_scan`, `jwt_advanced`, `business_logic`, `api_security`,
`param_miner`, `git_exposure`, `vhost_discovery`, `port_scan` n'étaient pas
propagés depuis les args CLI vers `ScanConfig`. Il était donc **impossible** de les
désactiver avec un flag `--no-*` (le flag n'existait pas, et build_config ignorait tout).

## Nouveaux flags CLI

```
--no-websocket         Désactiver WebSocket scanner (CSWSH, injection, auth bypass)
--no-jwt-advanced      Désactiver JWT avancé (none-alg, weak secret, kid, jku SSRF)
--no-business-logic    Désactiver Business Logic (price tamper, mass assign, coupon)
--no-api-security      Désactiver API Security (versioning, debug endpoints, override)
--no-param-miner       Désactiver Param Miner
--no-git-exposure      Désactiver détection Git/SVN/HG exposés
--no-vhost             Désactiver Virtual Host discovery
--no-port-scan         Désactiver Port Scanner
```

## dry_run() — affichage complet
Affiche maintenant tous les modules actifs y compris v5.9, v5.10 et Network,
au lieu de s'arrêter à OTPBypassScanner.

## --only-vulns — nouveaux tokens
`websocket`, `ws`, `jwt_advanced`, `jwt_adv`, `business_logic`, `bizlogic`, `logic`,
`api_security`, `apisec`, `csrf`, `clickjacking`, `xframe`, `race`, `race_condition`, `toctou`

## --list-modules — mise à jour complète
Toutes les catégories reflètent désormais la réalité du code (v5.9, v5.10, Network).
