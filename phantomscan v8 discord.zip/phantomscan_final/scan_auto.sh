#!/bin/bash
# ============================================================
# PhantomScan v6 — Script de lancement automatique
# Usage: ./scan_auto.sh https://target.com [options]
# ============================================================

TARGET="$1"
PRESET="${2:-bb}"
WEBHOOK="${PHANTOMSCAN_WEBHOOK:-https://discord.com/api/webhooks/1501662475601576097/7T5J29c_amBgqkWlkpW42WPNEUXIUzVOa77nFDUNPN4PgBTA5mi0gg-giP9AEYKLlK11}"
REPORT_DIR="./reports"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
TARGET_CLEAN=$(echo "$TARGET" | sed 's|https\?://||' | sed 's|/.*||' | sed 's|[^a-zA-Z0-9.-]|_|g')
REPORT_FILE="${REPORT_DIR}/${TARGET_CLEAN}_${TIMESTAMP}.md"
H1_DIR="${REPORT_DIR}/${TARGET_CLEAN}_${TIMESTAMP}_hackerone"

# Couleurs
RED='\033[0;31m'
ORANGE='\033[0;33m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔══════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     PhantomScan v6 — Auto Scanner    ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════╝${NC}"
echo ""
echo -e "🎯 Target   : ${GREEN}${TARGET}${NC}"
echo -e "⚡ Preset   : ${GREEN}${PRESET}${NC}"
echo -e "📋 Rapport  : ${GREEN}${REPORT_FILE}${NC}"
if [ -n "$WEBHOOK" ]; then
    echo -e "🔔 Webhook  : ${GREEN}Activé${NC}"
fi
echo ""

# Créer le dossier reports
mkdir -p "$REPORT_DIR"

if [ -z "$TARGET" ]; then
    echo "Usage: $0 <target_url> [preset]"
    echo "Presets: bb, fast, full, stealth, api, recon"
    echo ""
    echo "Exemples:"
    echo "  $0 https://target.com bb"
    echo "  $0 https://api.target.com api"
    echo "  PHANTOMSCAN_WEBHOOK=https://discord.com/api/webhooks/xxx $0 https://target.com bb"
    exit 1
fi

# Construire la commande
CMD="python3 cli/main.py $TARGET --preset $PRESET --bb-report $REPORT_FILE --h1-reports $H1_DIR"

if [ -n "$WEBHOOK" ]; then
    CMD="$CMD --webhook $WEBHOOK"
fi

if [ -n "$PHANTOMSCAN_COOKIE" ]; then
    CMD="$CMD --cookie \"$PHANTOMSCAN_COOKIE\""
fi

if [ -n "$PHANTOMSCAN_HEADER" ]; then
    CMD="$CMD --header \"$PHANTOMSCAN_HEADER\""
fi

# Ajouter rate/concurrent depuis env si défini
RATE="${PHANTOMSCAN_RATE:-1.0}"
CONCURRENT="${PHANTOMSCAN_CONCURRENT:-3}"
CMD="$CMD --rate $RATE --concurrent $CONCURRENT"

echo -e "🚀 Lancement du scan..."
echo -e "Commande: ${BLUE}${CMD}${NC}"
echo ""

# Lancer le scan
eval $CMD
EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✅ Scan terminé !${NC}"
    echo -e "📋 Rapport BB    : ${GREEN}${REPORT_FILE}${NC}"
    echo -e "📁 Rapports H1   : ${GREEN}${H1_DIR}/${NC}"
    
    # Push sur GitHub si configuré
    if [ -n "$PHANTOMSCAN_GIT_PUSH" ]; then
        echo ""
        echo "📤 Push sur GitHub..."
        git add "$REPORT_FILE" "$H1_DIR" 2>/dev/null
        git commit -m "scan ${TARGET_CLEAN} $(date)" 2>/dev/null
        git push 2>/dev/null
        echo -e "${GREEN}✅ Pushé sur GitHub !${NC}"
    fi
else
    echo -e "${RED}❌ Le scan a échoué (code: $EXIT_CODE)${NC}"
fi
