"""
PhantomScan — Webhook Notifier
Envoie les findings en temps réel vers Discord, Slack, Telegram, ou n'importe quel webhook.
Configure via --webhook URL ou PHANTOMSCAN_WEBHOOK=URL dans l'environnement.
"""
from __future__ import annotations
import asyncio
import json
import os
import time
import urllib.request
import urllib.error
from dataclasses import dataclass
from typing import Optional

SEVERITY_EMOJI = {
    "CRITICAL": "🔴",
    "HIGH": "🟠", 
    "MEDIUM": "🟡",
    "LOW": "🟢",
    "INFO": "ℹ️",
}

SEVERITY_COLOR = {
    "CRITICAL": 15158332,  # Rouge
    "HIGH": 15105570,       # Orange
    "MEDIUM": 16776960,     # Jaune
    "LOW": 3066993,         # Vert
    "INFO": 3447003,        # Bleu
}


@dataclass
class WebhookConfig:
    url: str
    min_severity: str = "MEDIUM"   # Seuil minimum pour notifier
    webhook_type: str = "auto"      # auto, discord, slack, telegram, generic


class WebhookNotifier:
    """
    Notificateur webhook universel.
    Supporte Discord, Slack, Telegram, et webhooks génériques.
    
    Usage:
        notifier = WebhookNotifier(WebhookConfig(url="https://discord.com/api/webhooks/..."))
        await notifier.send_finding(finding)
        await notifier.send_scan_summary(target, findings_list)
    """

    SEVERITY_ORDER = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0}

    def __init__(self, config: WebhookConfig):
        self.config = config
        self._type = self._detect_type(config.url)
        self._queue: list[dict] = []
        self._last_send = 0.0
        self._rate_limit = 1.0  # Secondes entre envois

    def _detect_type(self, url: str) -> str:
        if self.config.webhook_type != "auto":
            return self.config.webhook_type
        if "discord.com/api/webhooks" in url:
            return "discord"
        if "hooks.slack.com" in url:
            return "slack"
        if "api.telegram.org" in url:
            return "telegram"
        return "generic"

    def _should_notify(self, severity: str) -> bool:
        min_level = self.SEVERITY_ORDER.get(self.config.min_severity, 2)
        finding_level = self.SEVERITY_ORDER.get(severity.upper(), 0)
        return finding_level >= min_level

    def _format_discord(self, finding) -> dict:
        severity = str(finding.severity.name) if hasattr(finding.severity, 'name') else str(finding.severity)
        emoji = SEVERITY_EMOJI.get(severity, "⚪")
        color = SEVERITY_COLOR.get(severity, 0)
        
        fields = [
            {"name": "🎯 URL", "value": f"`{finding.url[:100]}`", "inline": False},
            {"name": "📦 Module", "value": f"`{finding.module}`", "inline": True},
            {"name": "🔢 Severity", "value": f"{emoji} **{severity}**", "inline": True},
        ]
        if finding.cwe:
            fields.append({"name": "📋 CWE", "value": f"[{finding.cwe}](https://cwe.mitre.org/data/definitions/{finding.cwe.replace('CWE-', '')}.html)", "inline": True})
        if finding.evidence:
            evidence_short = finding.evidence[:200] + "..." if len(finding.evidence) > 200 else finding.evidence
            fields.append({"name": "🔍 Evidence", "value": f"```{evidence_short}```", "inline": False})
        if finding.remediation:
            fields.append({"name": "🔧 Remediation", "value": finding.remediation[:200], "inline": False})

        return {
            "embeds": [{
                "title": f"{emoji} {finding.title}",
                "description": finding.description[:500] if finding.description else "",
                "color": color,
                "fields": fields,
                "footer": {"text": "PhantomScan v6 — Bug Bounty Scanner"},
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime()),
            }]
        }

    def _format_slack(self, finding) -> dict:
        severity = str(finding.severity.name) if hasattr(finding.severity, 'name') else str(finding.severity)
        emoji = SEVERITY_EMOJI.get(severity, "⚪")
        
        return {
            "text": f"{emoji} *{finding.title}*",
            "attachments": [{
                "color": "#FF0000" if severity == "CRITICAL" else "#FF8C00" if severity == "HIGH" else "#FFD700",
                "fields": [
                    {"title": "URL", "value": finding.url[:100], "short": False},
                    {"title": "Module", "value": finding.module, "short": True},
                    {"title": "Severity", "value": severity, "short": True},
                    {"title": "Description", "value": finding.description[:300] if finding.description else "", "short": False},
                ],
                "footer": "PhantomScan v6",
            }]
        }

    def _format_telegram(self, finding) -> dict:
        severity = str(finding.severity.name) if hasattr(finding.severity, 'name') else str(finding.severity)
        emoji = SEVERITY_EMOJI.get(severity, "⚪")
        
        # Extraire le chat_id de l'URL Telegram
        # Format: https://api.telegram.org/bot{TOKEN}/sendMessage?chat_id={CHAT_ID}
        text = (
            f"{emoji} *{finding.title}*\n\n"
            f"🎯 `{finding.url[:100]}`\n"
            f"📦 Module: `{finding.module}`\n"
            f"🔢 Severity: *{severity}*\n"
        )
        if finding.evidence:
            text += f"\n🔍 Evidence:\n```{finding.evidence[:200]}```"
        
        # Extraire chat_id de l'URL si présent
        chat_id = ""
        if "chat_id=" in self.config.url:
            chat_id = self.config.url.split("chat_id=")[1].split("&")[0]
        
        return {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": "Markdown",
        }

    def _format_generic(self, finding) -> dict:
        severity = str(finding.severity.name) if hasattr(finding.severity, 'name') else str(finding.severity)
        return {
            "scanner": "PhantomScan v6",
            "title": finding.title,
            "severity": severity,
            "url": finding.url,
            "module": finding.module,
            "description": finding.description,
            "evidence": finding.evidence[:300] if finding.evidence else "",
            "cwe": finding.cwe,
            "remediation": finding.remediation,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }

    def _send_http(self, url: str, payload: dict) -> bool:
        try:
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                url,
                data=data,
                headers={"Content-Type": "application/json", "User-Agent": "PhantomScan/6.0"},
                method="POST"
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                return resp.status in (200, 201, 204)
        except Exception as e:
            print(f"[Webhook] Erreur envoi: {e}")
            return False

    async def send_finding(self, finding) -> bool:
        severity = str(finding.severity.name) if hasattr(finding.severity, 'name') else str(finding.severity)
        if not self._should_notify(severity):
            return False

        # Rate limiting
        elapsed = time.time() - self._last_send
        if elapsed < self._rate_limit:
            await asyncio.sleep(self._rate_limit - elapsed)

        webhook_url = self.config.url
        if self._type == "discord":
            payload = self._format_discord(finding)
        elif self._type == "slack":
            payload = self._format_slack(finding)
        elif self._type == "telegram":
            payload = self._format_telegram(finding)
            # Pour Telegram, utiliser l'URL de base sans chat_id
            if "?" in webhook_url:
                webhook_url = webhook_url.split("?")[0]
        else:
            payload = self._format_generic(finding)

        success = await asyncio.get_event_loop().run_in_executor(
            None, self._send_http, webhook_url, payload
        )
        self._last_send = time.time()
        return success

    async def send_scan_start(self, target: str) -> bool:
        payload = self._format_scan_event("start", target)
        return await asyncio.get_event_loop().run_in_executor(
            None, self._send_http, self.config.url, payload
        )

    async def send_scan_summary(self, target: str, findings: list) -> bool:
        critical = sum(1 for f in findings if str(getattr(f.severity, 'name', f.severity)) == "CRITICAL")
        high = sum(1 for f in findings if str(getattr(f.severity, 'name', f.severity)) == "HIGH")
        medium = sum(1 for f in findings if str(getattr(f.severity, 'name', f.severity)) == "MEDIUM")
        low = sum(1 for f in findings if str(getattr(f.severity, 'name', f.severity)) == "LOW")

        if self._type == "discord":
            payload = {
                "embeds": [{
                    "title": f"✅ Scan terminé — {target}",
                    "description": f"**{len(findings)} findings** détectés",
                    "color": 15158332 if critical > 0 else 15105570 if high > 0 else 16776960,
                    "fields": [
                        {"name": "🔴 Critical", "value": str(critical), "inline": True},
                        {"name": "🟠 High", "value": str(high), "inline": True},
                        {"name": "🟡 Medium", "value": str(medium), "inline": True},
                        {"name": "🟢 Low", "value": str(low), "inline": True},
                        {"name": "🎯 Target", "value": f"`{target}`", "inline": False},
                    ],
                    "footer": {"text": "PhantomScan v6 — Bug Bounty Scanner"},
                    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime()),
                }]
            }
        else:
            payload = {
                "scanner": "PhantomScan v6",
                "event": "scan_complete",
                "target": target,
                "summary": {
                    "total": len(findings),
                    "critical": critical,
                    "high": high,
                    "medium": medium,
                    "low": low,
                },
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            }

        return await asyncio.get_event_loop().run_in_executor(
            None, self._send_http, self.config.url, payload
        )

    def _format_scan_event(self, event: str, target: str) -> dict:
        if self._type == "discord":
            return {
                "embeds": [{
                    "title": f"🚀 Scan démarré — {target}",
                    "color": 3447003,
                    "fields": [
                        {"name": "🎯 Target", "value": f"`{target}`", "inline": False},
                    ],
                    "footer": {"text": "PhantomScan v6"},
                    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime()),
                }]
            }
        return {"scanner": "PhantomScan v6", "event": event, "target": target}


def get_notifier_from_env() -> Optional[WebhookNotifier]:
    """Crée un notifier depuis les variables d'environnement."""
    url = os.environ.get("PHANTOMSCAN_WEBHOOK", "")
    if not url:
        return None
    min_sev = os.environ.get("PHANTOMSCAN_WEBHOOK_MIN_SEVERITY", "HIGH")
    return WebhookNotifier(WebhookConfig(url=url, min_severity=min_sev))
