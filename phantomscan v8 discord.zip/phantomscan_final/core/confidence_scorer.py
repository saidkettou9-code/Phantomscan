"""
PhantomScan — Confidence Scorer
Attribue un score de confiance 0-100% à chaque finding.
"""
from __future__ import annotations
import re
from core.fp_filter import FPFilter

_HIGH_CONFIDENCE_INDICATORS = {
    "ssrf": [
        re.compile(r"ami-id|instance-id|AccessKeyId|SecretAccessKey", re.I),
        re.compile(r"computeMetadata|gserviceaccount", re.I),
        re.compile(r"subscriptionId|resourceGroupName", re.I),
    ],
    "sqli": [
        re.compile(r"SQL syntax.*MySQL|ORA-[0-9]+", re.I),
        re.compile(r"Microsoft OLE DB|Unclosed quotation", re.I),
        re.compile(r"PostgreSQL.*ERROR", re.I),
    ],
    "lfi": [
        re.compile(r"root:x:0:0"),
        re.compile(r"\[boot loader\]"),
    ],
    "xss": [
        re.compile(r"<script[^>]*>alert\(1\)"),
        re.compile(r"<img[^>]+onerror=['\"]?alert"),
    ],
    "secrets": [
        re.compile(r"AKIA[0-9A-Z]{16}"),
        re.compile(r"BEGIN.*PRIVATE KEY"),
        re.compile(r"ghp_[a-zA-Z0-9]{36}"),
    ],
}

_LOW_CONFIDENCE_INDICATORS = [
    re.compile(r"botdefense|heatpipe|token_retry", re.I),
    re.compile(r"d3i4yxtzktqr9n\.cloudfront\.net", re.I),
    re.compile(r"<!doctype html>.*<title>", re.I | re.S),
]


def score_finding(finding_module: str, evidence: str, body: str) -> int:
    """
    Retourne un score de confiance 0-100.
    100 = certitude absolue (preuve irréfutable)
    0   = faux positif certain
    """
    if not evidence and not body:
        return 20

    # Vérifier les indicateurs de FP
    if FPFilter.is_cloudflare(body or evidence):
        return 5
    for pattern in _LOW_CONFIDENCE_INDICATORS:
        if pattern.search(evidence or ""):
            return 10

    # Extraire le type de vuln du module
    vuln_type = finding_module.split("/")[-1].replace(".py", "").lower()
    for key in _HIGH_CONFIDENCE_INDICATORS:
        if key in vuln_type:
            for pattern in _HIGH_CONFIDENCE_INDICATORS[key]:
                if pattern.search(body or evidence or ""):
                    return 95

    # Score par défaut selon le type
    default_scores = {
        "ssrf": 30,
        "sqli": 40,
        "lfi": 35,
        "xss": 45,
        "auth_bypass": 50,
        "idor": 55,
        "secrets": 60,
        "sensitive_data": 65,
        "cors": 70,
        "csrf": 65,
        "clickjacking": 75,
        "subdomain_takeover": 80,
        "graphql": 60,
    }
    for key, score in default_scores.items():
        if key in vuln_type:
            return score

    return 40


def confidence_label(score: int) -> str:
    if score >= 90:
        return "✅ Confirmé"
    elif score >= 70:
        return "🔶 Probable"
    elif score >= 50:
        return "⚠️ À vérifier"
    elif score >= 30:
        return "❓ Douteux"
    else:
        return "❌ Faux positif probable"
