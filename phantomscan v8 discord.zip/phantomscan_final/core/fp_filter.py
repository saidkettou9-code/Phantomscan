"""
PhantomScan — Global False Positive Filter v1.0
================================================
Filtre centralisé pour éliminer les faux positifs liés aux WAF,
CDN (Cloudflare, Akamai, Fastly), et pages génériques.

Usage dans n'importe quel module :
    from phantomscan.core.fp_filter import FPFilter
    if FPFilter.is_fp(resp.body, resp.status, url):
        continue
"""

from __future__ import annotations

import re
import hashlib
from dataclasses import dataclass
from typing import Optional


# ── Patterns Cloudflare / CDN ────────────────────────────────────────────────

_CLOUDFLARE_PATTERNS = [
    re.compile(r"d3i4yxtzktqr9n\.cloudfront\.net", re.I),
    re.compile(r"botdefense", re.I),
    re.compile(r"heatpipe", re.I),
    re.compile(r"token_retry", re.I),
    re.compile(r"s-hp-botdefense", re.I),
    re.compile(r"s-m3-botdefense", re.I),
    re.compile(r"__cf_bm", re.I),
    re.compile(r"cf-ray", re.I),
    re.compile(r"cloudflare\.com/cdn-cgi", re.I),
    re.compile(r"recaptcha\.net|grecaptcha", re.I),
    re.compile(r"cf-mitigated", re.I),
    re.compile(r"attention required.*cloudflare", re.I | re.S),
]

_WAF_BLOCK_PATTERNS = [
    re.compile(r"Request Rejected", re.I),
    re.compile(r"Your support ID is", re.I),
    re.compile(r"Access Denied", re.I),
    re.compile(r"Forbidden by policy", re.I),
    re.compile(r"mod_security|cloudflare.*blocked|blocked by", re.I),
    re.compile(r"This page isn.t working", re.I),
    re.compile(r"403 Forbidden|401 Unauthorized", re.I),
    re.compile(r"<title>[^<]*(403|forbidden|rejected|blocked|unauthorized)[^<]*</title>", re.I),
]

_GENERIC_PAGE_PATTERNS = [
    re.compile(r"404 Not Found|Page Not Found|not found", re.I),
    re.compile(r"Something went wrong|Oops|Sorry", re.I),
    re.compile(r"Internal Server Error.*500", re.I),
    re.compile(r"nginx|Apache/\d", re.I),
    # Pages HTML génériques sans contenu utile
    re.compile(r"^<!DOCTYPE html>.*<body>\s*</body>", re.I | re.S),
]

# Patterns qui confirment un VRAI contenu sensible (pour SSRF, LFI, etc.)
_REAL_SSRF_INDICATORS = [
    # AWS IMDS
    re.compile(r"ami-id|instance-id|local-ipv4|public-hostname", re.I),
    re.compile(r"iam/security-credentials|AccessKeyId|SecretAccessKey", re.I),
    re.compile(r"placement/availability-zone|instance-type", re.I),
    # GCP
    re.compile(r"computeMetadata|gserviceaccount\.com", re.I),
    re.compile(r'"access_token"\s*:\s*"ya29\.', re.I),
    # Azure
    re.compile(r"subscriptionId|resourceGroupName|vmId", re.I),
    # Internal services
    re.compile(r"root:x:0:0|daemon:x:", re.I),
    re.compile(r"redis_version|redis_mode|connected_clients", re.I),
    re.compile(r'"version"\s*:\s*\{"number"', re.I),  # Elasticsearch
    re.compile(r"ssh-rsa |ssh-ed25519 |ecdsa-sha2-", re.I),
    re.compile(r"220.*FTP|230 Login successful", re.I),
    re.compile(r"mysql.*Ver.*Distrib|MariaDB", re.I),
]

_REAL_LFI_INDICATORS = [
    re.compile(r"root:x:0:0:root:/root", re.I),
    re.compile(r"daemon:x:[0-9]+:[0-9]+", re.I),
    re.compile(r"\[boot loader\]|\[operating systems\]", re.I),
    re.compile(r"PATH=.*HOME=|USER=.*SHELL=", re.I),
]

_REAL_XSS_INDICATORS = [
    re.compile(r"<script[^>]*>alert\(", re.I),
    re.compile(r"<img[^>]+onerror\s*=\s*['\"]?alert", re.I),
    re.compile(r"javascript:alert\(", re.I),
]

_REAL_SQLI_INDICATORS = [
    re.compile(r"SQL syntax.*MySQL|mysql_fetch|ORA-[0-9]+", re.I),
    re.compile(r"Microsoft OLE DB.*SQL|Unclosed quotation mark", re.I),
    re.compile(r"PostgreSQL.*ERROR|pg_query\(\)|Warning.*pg_", re.I),
    re.compile(r"SQLite.*error|sqlite_query", re.I),
    re.compile(r"Syntax error.*SQL|SQL command not properly ended", re.I),
]

_REAL_SECRETS_INDICATORS = [
    re.compile(r"(api[_-]?key|apikey|api[_-]?secret)\s*[=:]\s*['\"]?[a-zA-Z0-9_\-]{16,}", re.I),
    re.compile(r"(password|passwd|pwd)\s*[=:]\s*['\"]?[^\s'\"]{8,}", re.I),
    re.compile(r"(secret|token)\s*[=:]\s*['\"]?[a-zA-Z0-9_\-\.]{16,}", re.I),
    re.compile(r"BEGIN (RSA |EC |DSA )?PRIVATE KEY", re.I),
    re.compile(r"AKIA[0-9A-Z]{16}", re.I),  # AWS Access Key
    re.compile(r"ghp_[a-zA-Z0-9]{36}|github_pat_", re.I),  # GitHub token
    re.compile(r"sk-[a-zA-Z0-9]{48}", re.I),  # OpenAI key
]


class FPFilter:
    """
    Filtre centralisé anti-faux-positifs.
    
    Méthodes principales :
    - is_cloudflare(body) → True si la réponse vient de Cloudflare/CDN
    - is_waf_block(body) → True si bloqué par WAF
    - is_generic_page(body) → True si page générique sans contenu utile
    - is_fp(body, status, url) → True si faux positif certain
    - has_real_ssrf(body) → True si vraie SSRF confirmée
    - has_real_lfi(body) → True si vraie LFI confirmée
    - has_real_xss(body, payload) → True si vrai XSS réfléchi
    - has_real_sqli(body) → True si vraie SQLi confirmée
    - has_real_secrets(body) → True si vrais secrets exposés
    - body_diff_ratio(body1, body2) → ratio de différence entre 2 corps
    - is_same_page(body1, body2, threshold) → True si pages similaires
    """

    @staticmethod
    def is_cloudflare(body: str) -> bool:
        """Détecte si la réponse est une page Cloudflare/CDN."""
        sample = body[:3000]
        return any(p.search(sample) for p in _CLOUDFLARE_PATTERNS)

    @staticmethod
    def is_waf_block(body: str) -> bool:
        """Détecte un blocage WAF déguisé en 200."""
        sample = body[:2000]
        return any(p.search(sample) for p in _WAF_BLOCK_PATTERNS)

    @staticmethod
    def is_generic_page(body: str) -> bool:
        """Détecte une page générique sans contenu utile."""
        sample = body[:1000]
        return any(p.search(sample) for p in _GENERIC_PAGE_PATTERNS)

    @staticmethod
    def is_fp(body: str, status: int, url: str = "") -> bool:
        """
        Retourne True si la réponse est un faux positif certain.
        À utiliser comme premier filtre dans tous les modules.
        """
        if status in (404, 410, 400, 429, 503):
            return True
        if FPFilter.is_cloudflare(body):
            return True
        if FPFilter.is_waf_block(body):
            return True
        return False

    @staticmethod
    def has_real_ssrf(body: str) -> bool:
        """Retourne True si la réponse contient une vraie preuve de SSRF."""
        # Rejeter d'abord si Cloudflare
        if FPFilter.is_cloudflare(body):
            return False
        return any(p.search(body) for p in _REAL_SSRF_INDICATORS)

    @staticmethod
    def has_real_lfi(body: str) -> bool:
        """Retourne True si la réponse contient une vraie preuve de LFI."""
        if FPFilter.is_cloudflare(body):
            return False
        return any(p.search(body) for p in _REAL_LFI_INDICATORS)

    @staticmethod
    def has_real_xss(body: str, payload: str = "") -> bool:
        """Retourne True si le payload XSS est réellement réfléchi/exécutable."""
        if FPFilter.is_cloudflare(body):
            return False
        # Vérifier que le payload brut est présent dans la réponse
        if payload and payload in body:
            return True
        return any(p.search(body) for p in _REAL_XSS_INDICATORS)

    @staticmethod
    def has_real_sqli(body: str) -> bool:
        """Retourne True si la réponse contient un vrai message d'erreur SQL."""
        if FPFilter.is_cloudflare(body):
            return False
        return any(p.search(body) for p in _REAL_SQLI_INDICATORS)

    @staticmethod
    def has_real_secrets(body: str) -> bool:
        """Retourne True si la réponse contient de vrais secrets exposés."""
        if FPFilter.is_cloudflare(body):
            return False
        return any(p.search(body) for p in _REAL_SECRETS_INDICATORS)

    @staticmethod
    def body_hash(body: str) -> str:
        """Hash MD5 du body pour comparaison rapide."""
        return hashlib.md5(body.encode("utf-8", errors="ignore")).hexdigest()

    @staticmethod
    def is_same_page(body1: str, body2: str, threshold: float = 0.85) -> bool:
        """
        Retourne True si les deux corps sont trop similaires
        (indique probablement un faux positif).
        Utilise un ratio de Jaccard sur les tokens.
        """
        if not body1 or not body2:
            return False
        # Comparaison rapide par hash
        if FPFilter.body_hash(body1) == FPFilter.body_hash(body2):
            return True
        # Jaccard sur les mots
        tokens1 = set(re.findall(r'\w+', body1[:5000]))
        tokens2 = set(re.findall(r'\w+', body2[:5000]))
        if not tokens1 or not tokens2:
            return False
        intersection = len(tokens1 & tokens2)
        union = len(tokens1 | tokens2)
        similarity = intersection / union if union > 0 else 0
        return similarity >= threshold

    @staticmethod
    def normalize_body(body: str) -> str:
        """
        Normalise le body en supprimant les éléments dynamiques
        (nonces, timestamps, CSRF tokens) pour une comparaison stable.
        """
        body = re.sub(r'nonce="[^"]{8,}"', 'nonce="NONCE"', body)
        body = re.sub(r'csrf[_-]?token["\s]*[=:]["\s]*[a-zA-Z0-9_\-]{16,}', 'CSRF_TOKEN', body, flags=re.I)
        body = re.sub(r'\d{10,13}', 'TIMESTAMP', body)  # Unix timestamps
        body = re.sub(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', 'UUID', body, flags=re.I)
        return body

    @staticmethod
    def extract_evidence(body: str, pattern: re.Pattern, context: int = 100) -> str:
        """Extrait un extrait de preuve autour du match d'un pattern."""
        m = pattern.search(body)
        if not m:
            return ""
        start = max(0, m.start() - context)
        end = min(len(body), m.end() + context)
        return body[start:end].strip()
