"""
PhantomScan — HTTP Parameter Pollution Scanner v2.0

v2.0 :
- Test HPP dans les headers (X-Custom-Header dupliqué)
- Test pollution des paramètres POST
- Test JSON parameter pollution
- Détection des paramètres sensibles pollués (token, role, admin, user_id)
- Test pollution d'arrays (?ids[]=1&ids[]=2)
- Comparaison de comportement avant/après pour réduire les FP
"""
from __future__ import annotations
import re
from typing import AsyncIterator
from urllib.parse import urlparse, parse_qs, urlencode
from phantomscan.core.requester import Requester, ProbeRequest
from phantomscan.output.reporter import Finding, Severity
from phantomscan.config import PhantomConfig
from phantomscan.core.heuristic import HeuristicEngine
from core.fp_filter import FPFilter
from phantomscan.core.scanner_mixin import ScannerMixin

# Paramètres sensibles qui méritent un test prioritaire
_SENSITIVE_PARAMS = {
    "role", "admin", "is_admin", "user_id", "userid", "account", "account_id",
    "token", "access_token", "auth", "permission", "privilege", "scope",
    "redirect", "url", "callback", "next", "return_to",
    "price", "amount", "quantity", "total",
}

_HPP_MARKER = "PHANTOMHPP_INJECTED"


class ParamPollutionScanner(ScannerMixin):
    def __init__(self, req: Requester, heuristic: HeuristicEngine, cfg: PhantomConfig):
        self._req = req
        self._heuristic = heuristic
        self._cfg = cfg

    async def run(self, target: str) -> AsyncIterator[Finding]:
        parsed = urlparse(target)
        params = parse_qs(parsed.query, keep_blank_values=True)
        if not params:
            return

        # Réponse de référence
        original = await self._req.get(target)
        if original.error or FPFilter.is_fp(original.body, original.status):
            return

        # Limiter à 8 params pour éviter le bruit
        test_params = list(params.keys())[:8]

        for param in test_params:
            original_value = params[param][0] if params[param] else ""
            is_sensitive = param.lower() in _SENSITIVE_PARAMS

            # ── Test 1 : Duplication de paramètre dans la query string ───────
            # ?param=original&param=INJECTED
            polluted_url = f"{target}&{param}={_HPP_MARKER}"
            resp = await self._req.get(polluted_url)
            if resp.error or FPFilter.is_cloudflare(resp.body):
                continue

            if _HPP_MARKER in resp.body:
                severity = Severity.HIGH if is_sensitive else Severity.MEDIUM
                yield Finding(
                    title=f"HTTP Parameter Pollution — `{param}` reflété",
                    severity=severity,
                    url=polluted_url,
                    module="vulns/param_pollution",
                    description=(
                        f"Le paramètre `{param}` est vulnérable à la pollution HTTP. "
                        f"La valeur injectée (`{_HPP_MARKER}`) est réfléchie dans la réponse, "
                        f"indiquant que le serveur utilise la dernière valeur du paramètre. "
                        + (f"⚠️ `{param}` est un paramètre sensible (auth/privilege/price) — impact élevé."
                           if is_sensitive else "")
                    ),
                    evidence=f"GET {polluted_url[:150]} → Marker trouvé dans la réponse",
                    cwe="CWE-235",
                    remediation=(
                        f"Normaliser le traitement du paramètre `{param}` : utiliser toujours "
                        f"la première valeur et ignorer les doublons. "
                        f"Documenter explicitement le comportement attendu pour les paramètres dupliqués. "
                        f"Pour les paramètres sensibles, rejeter les requêtes avec doublons (HTTP 400)."
                    ),
                )

            # ── Test 2 : Pollution avec valeur prédéfinie (privilege escalation) ──
            if is_sensitive:
                # Tester avec des valeurs d'escalade connues
                escalation_values = {
                    "role": ["admin", "administrator", "superuser", "root"],
                    "is_admin": ["true", "1", "yes"],
                    "admin": ["true", "1"],
                    "scope": ["admin:write", "all", "*"],
                    "price": ["0", "0.01", "-1"],
                    "amount": ["0", "-1"],
                }
                for key_pattern, test_values in escalation_values.items():
                    if key_pattern not in param.lower():
                        continue
                    for val in test_values:
                        # ?param=original&param=admin
                        esc_url = f"{target}&{param}={val}"
                        resp_esc = await self._req.get(esc_url)
                        if resp_esc.error or FPFilter.is_fp(resp_esc.body, resp_esc.status):
                            continue
                        # Détecter si le comportement change (réponse différente)
                        if resp_esc.body != original.body and resp_esc.status != original.status:
                            yield Finding(
                                title=f"HPP Privilege Escalation Possible — `{param}={val}`",
                                severity=Severity.HIGH,
                                url=esc_url,
                                module="vulns/param_pollution",
                                description=(
                                    f"La duplication du paramètre `{param}` avec la valeur `{val}` "
                                    f"provoque un changement de comportement du serveur. "
                                    f"Le serveur pourrait utiliser la valeur dupliquée pour l'autorisation."
                                ),
                                evidence=(
                                    f"Original ({param}={original_value}): status={original.status}, "
                                    f"len={len(original.body)} | "
                                    f"Pollué ({param}={val}): status={resp_esc.status}, "
                                    f"len={len(resp_esc.body)}"
                                ),
                                cwe="CWE-285",
                                remediation=(
                                    f"Valider et normaliser le paramètre `{param}` avant utilisation. "
                                    f"Pour les paramètres de sécurité, rejeter toute duplication. "
                                    f"Ne jamais se fier à la dernière valeur d'un paramètre dupliqué."
                                ),
                            )
                            break

            # ── Test 3 : Pollution de tableau (?ids[]=1&ids[]=../secret) ─────
            if "id" in param.lower() or "ids" in param.lower():
                array_url = f"{target}&{param}[]=../secret&{param}[]=../../admin"
                resp_arr = await self._req.get(array_url)
                if not resp_arr.error and "secret" in resp_arr.body.lower():
                    yield Finding(
                        title=f"HPP Array Pollution — `{param}[]`",
                        severity=Severity.MEDIUM,
                        url=array_url,
                        module="vulns/param_pollution",
                        description=(
                            f"Le paramètre `{param}` accepte une notation tableau `{param}[]` "
                            f"avec des valeurs de traversée. L'application reflète une valeur inattendue."
                        ),
                        evidence=resp_arr.body[:200],
                        cwe="CWE-235",
                        remediation=(
                            "Valider strictement le format attendu pour les paramètres de type ID. "
                            "Rejeter les notations tableau non attendues."
                        ),
                    )
