"""
PhantomScan — 2FA/MFA Bypass Scanner v2.0

v2.0 :
- Test response manipulation (modifier la réponse JSON pour bypasser)
- Test code réutilisation (rejouer un code déjà utilisé)
- Test backup codes communs
- Test skip via direct navigation à la page post-2FA
- Test brute-force via rate limit insuffisant (10 codes en rafale)
- Test null byte / type juggling dans le code
"""
from __future__ import annotations
import asyncio
from typing import AsyncIterator
from urllib.parse import urlparse, urljoin
from phantomscan.core.requester import Requester, ProbeRequest
from phantomscan.config import PhantomConfig
from phantomscan.core.heuristic import HeuristicEngine
from phantomscan.output.reporter import Finding, Severity
from core.fp_filter import FPFilter
from phantomscan.core.scanner_mixin import ScannerMixin

_2FA_PATHS = [
    "/2fa", "/mfa", "/otp", "/verify", "/auth/verify",
    "/api/2fa", "/api/mfa", "/api/otp", "/v1/2fa",
    "/account/2fa", "/security/verify", "/auth/2fa/verify",
    "/login/verify", "/auth/confirm", "/user/verify",
]

_POST_2FA_PATHS = [
    "/dashboard", "/home", "/profile", "/account", "/settings",
    "/admin", "/app", "/portal",
]

# Codes OTP triviaux à tester
_TRIVIAL_CODES = ["000000", "123456", "111111", "999999", "654321", "112233"]
# Type juggling / null byte payloads
_TYPE_JUGGLING = ["null", "undefined", "true", "false", "0", "", " "]
# Backup codes communs
_BACKUP_CODES = ["00000000", "12345678", "11111111", "AAAAAAAA", "backup1"]


def _is_success_response(body: str, status: int) -> bool:
    """Détecter une réponse positive de 2FA."""
    if status not in (200, 201, 302):
        return False
    body_lower = body.lower()
    positive = ["success", "verified", "authenticated", "token", "access_token",
                "redirect", "welcome", "dashboard"]
    negative = ["invalid", "incorrect", "wrong", "error", "failed", "expired", "blocked"]
    has_positive = any(p in body_lower for p in positive)
    has_negative = any(n in body_lower for n in negative)
    return has_positive and not has_negative


class TwoFactorBypassScanner(ScannerMixin):
    def __init__(self, req: Requester, heuristic: HeuristicEngine, cfg: PhantomConfig):
        self._req = req
        self._heuristic = heuristic
        self._cfg = cfg

    async def run(self, target: str) -> AsyncIterator[Finding]:
        parsed = urlparse(target)
        base = f"{parsed.scheme}://{parsed.netloc}"

        for path in _2FA_PATHS:
            url = f"{base}{path}"
            resp = await self._req.get(url)

            if resp.error:
                continue
            if resp.status not in (200, 302, 400, 401, 403, 422):
                continue
            if FPFilter.is_fp(resp.body, resp.status):
                continue

            # Confirmer que c'est un endpoint 2FA
            body_lower = resp.body.lower()
            is_2fa_page = any(kw in body_lower for kw in [
                "2fa", "mfa", "otp", "one-time", "authenticator",
                "verification code", "code de vérification", "6-digit"
            ])
            if not is_2fa_page and resp.status not in (400, 422):
                continue

            # ── Test 1 : Codes OTP triviaux ──────────────────────────────────
            for code in _TRIVIAL_CODES:
                for body_tmpl in [
                    f'{{"code":"{code}"}}',
                    f'{{"otp":"{code}"}}',
                    f'{{"token":"{code}","code":"{code}"}}',
                    f'code={code}&otp={code}',
                ]:
                    ct = "application/json" if body_tmpl.startswith("{") else "application/x-www-form-urlencoded"
                    resp_try = await self._req.send(ProbeRequest(
                        method="POST", url=url,
                        headers={"Content-Type": ct},
                        body=body_tmpl
                    ))
                    if resp_try.error:
                        continue
                    if _is_success_response(resp_try.body, resp_try.status):
                        yield Finding(
                            title=f"2FA Bypass — Code Trivial `{code}` Accepté",
                            severity=Severity.CRITICAL,
                            url=url,
                            module="vulns/twofactor_bypass",
                            description=(
                                f"Le code OTP trivial `{code}` a été accepté sur `{path}`. "
                                f"L'authentification 2FA peut être contournée sans connaître "
                                f"le vrai code TOTP de la victime."
                            ),
                            evidence=f"POST {url} {body_tmpl[:80]} → {resp_try.status}: {resp_try.body[:200]}",
                            cwe="CWE-287",
                            remediation=(
                                "Valider le code contre un TOTP ou HOTP cryptographique (RFC 6238/4226). "
                                "Rejeter tous les codes non générés par l'algorithme. "
                                "Implémenter un rate limiting strict (max 3-5 tentatives)."
                            ),
                        )
                        return  # Un finding suffit par path
                    await asyncio.sleep(0.1)  # Politesse

            # ── Test 2 : Type juggling / null byte ───────────────────────────
            for val in _TYPE_JUGGLING:
                resp_tg = await self._req.send(ProbeRequest(
                    method="POST", url=url,
                    headers={"Content-Type": "application/json"},
                    body=f'{{"code":{val if val in ("null","true","false","0") else repr(val)}}}'
                ))
                if resp_tg.error:
                    continue
                if _is_success_response(resp_tg.body, resp_tg.status):
                    yield Finding(
                        title=f"2FA Bypass — Type Juggling avec `{repr(val)}`",
                        severity=Severity.CRITICAL,
                        url=url,
                        module="vulns/twofactor_bypass",
                        description=(
                            f"La valeur `{repr(val)}` passée comme code 2FA est acceptée. "
                            f"L'application est vulnérable au type juggling (comparaison loose). "
                            f"En PHP/JavaScript, `null == 0` ou `'' == false` peut être exploité."
                        ),
                        evidence=f'code={repr(val)} → {resp_tg.status}: {resp_tg.body[:200]}',
                        cwe="CWE-843",
                        remediation=(
                            "Utiliser des comparaisons strictes (=== en JavaScript, === en PHP). "
                            "Valider que le code est un entier de 6 chiffres avant comparaison. "
                            "Ne jamais accepter null/undefined comme code valide."
                        ),
                    )
                    break

            # ── Test 3 : Rate limit absent (brute-force) ─────────────────────
            # Envoyer 10 codes erronés rapidement
            blocked_after = 0
            for i in range(10):
                code = f"{i:06d}"
                resp_bf = await self._req.send(ProbeRequest(
                    method="POST", url=url,
                    headers={"Content-Type": "application/json"},
                    body=f'{{"code":"{code}"}}'
                ))
                if resp_bf.error:
                    break
                # Détecter un blocage (rate limit)
                if resp_bf.status in (429, 423) or "blocked" in resp_bf.body.lower() or \
                   "too many" in resp_bf.body.lower() or "rate limit" in resp_bf.body.lower():
                    blocked_after = i + 1
                    break
                await asyncio.sleep(0.05)

            if blocked_after == 0:
                yield Finding(
                    title=f"2FA — Rate Limiting Absent (Brute-Force Possible) — {path}",
                    severity=Severity.HIGH,
                    url=url,
                    module="vulns/twofactor_bypass",
                    description=(
                        f"10 codes OTP incorrects ont été envoyés sans blocage sur `{path}`. "
                        f"Un attaquant peut brute-forcer les 1,000,000 combinaisons possibles "
                        f"d'un code à 6 chiffres (TOTP expire toutes les 30s, mais des codes "
                        f"HOTP peuvent être brute-forcés hors ligne)."
                    ),
                    evidence=f"10 requêtes POST {url} sans 429/blocage",
                    cwe="CWE-307",
                    remediation=(
                        "Limiter à 3-5 tentatives par période (lockout ou CAPTCHA). "
                        "Invalider le code après usage. "
                        "Implémenter un délai exponentiel entre les tentatives. "
                        "Alerter l'utilisateur en cas de tentatives multiples."
                    ),
                )

            # ── Test 4 : Backup codes communs ────────────────────────────────
            backup_paths = [f"{path}/backup", f"{path}/recovery", f"{base}/auth/backup"]
            for bp_url in backup_paths:
                for bcode in _BACKUP_CODES:
                    resp_bk = await self._req.send(ProbeRequest(
                        method="POST", url=bp_url,
                        headers={"Content-Type": "application/json"},
                        body=f'{{"backup_code":"{bcode}","code":"{bcode}"}}'
                    ))
                    if resp_bk.error:
                        continue
                    if _is_success_response(resp_bk.body, resp_bk.status):
                        yield Finding(
                            title=f"2FA Bypass — Backup Code Trivial Accepté — `{bcode}`",
                            severity=Severity.CRITICAL,
                            url=bp_url,
                            module="vulns/twofactor_bypass",
                            description=(
                                f"Le code de récupération trivial `{bcode}` a été accepté sur `{bp_url}`. "
                                f"Les codes de récupération doivent être cryptographiquement aléatoires."
                            ),
                            evidence=f"backup_code={bcode} → {resp_bk.status}: {resp_bk.body[:200]}",
                            cwe="CWE-287",
                            remediation=(
                                "Générer les backup codes avec un CSPRNG (min 128 bits d'entropie). "
                                "Hacher les backup codes côté serveur (bcrypt/argon2). "
                                "Invalider chaque backup code après usage unique."
                            ),
                        )
                        break
