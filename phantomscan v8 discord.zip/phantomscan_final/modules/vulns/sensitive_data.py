"""
PhantomScan — Sensitive Data Exposure Scanner v2.0

v2.0 :
- 30+ patterns de secrets (vs 13 avant) : Stripe, Twilio, SendGrid, Azure, GCP, etc.
- Vérification de l'entropie pour réduire les faux positifs
- Scan des headers de réponse (pas seulement le body)
- Détection de dumps de données (tableaux d'emails, listes d'utilisateurs)
- Test des endpoints de debug/diagnostic automatiquement détectés
- Score de criticité basé sur le type de secret
"""
from __future__ import annotations
import math
import re
from typing import AsyncIterator
from urllib.parse import urlparse
from phantomscan.core.requester import Requester
from phantomscan.config import PhantomConfig
from phantomscan.core.heuristic import HeuristicEngine
from phantomscan.output.reporter import Finding, Severity
from core.fp_filter import FPFilter
from phantomscan.core.scanner_mixin import ScannerMixin

# ── Patterns de secrets classés par criticité ─────────────────────────────────

_CRITICAL_SECRETS: dict[str, re.Pattern] = {
    "AWS Access Key":       re.compile(r"AKIA[0-9A-Z]{16}"),
    "AWS Secret Key":       re.compile(r"(?i)aws.{0,20}secret.{0,20}['\"][0-9a-zA-Z/+]{40}['\"]"),
    "GitHub Token (PAT)":   re.compile(r"ghp_[a-zA-Z0-9]{36}|github_pat_[a-zA-Z0-9_]{82}"),
    "GitHub OAuth":         re.compile(r"gho_[a-zA-Z0-9]{36}"),
    "GitHub Actions":       re.compile(r"ghs_[a-zA-Z0-9]{36}"),
    "OpenAI API Key":       re.compile(r"sk-[a-zA-Z0-9]{48}"),
    "Anthropic API Key":    re.compile(r"sk-ant-[a-zA-Z0-9\-_]{90,}"),
    "Private RSA Key":      re.compile(r"-----BEGIN RSA PRIVATE KEY-----"),
    "Private EC Key":       re.compile(r"-----BEGIN EC PRIVATE KEY-----"),
    "Generic Private Key":  re.compile(r"-----BEGIN PRIVATE KEY-----"),
    "Stripe Secret Key":    re.compile(r"sk_live_[a-zA-Z0-9]{24,}"),
    "Stripe Webhook":       re.compile(r"whsec_[a-zA-Z0-9]{32,}"),
    "Twilio Auth Token":    re.compile(r"(?i)twilio.{0,20}['\"][0-9a-f]{32}['\"]"),
    "SendGrid API Key":     re.compile(r"SG\.[a-zA-Z0-9\-_]{22}\.[a-zA-Z0-9\-_]{43}"),
    "Slack Bot Token":      re.compile(r"xoxb-[0-9]+-[0-9]+-[a-zA-Z0-9]+"),
    "Slack User Token":     re.compile(r"xoxp-[0-9]+-[0-9]+-[0-9]+-[a-zA-Z0-9]+"),
    "Google API Key":       re.compile(r"AIza[0-9A-Za-z\-_]{35}"),
    "Firebase Key":         re.compile(r"AAAA[A-Za-z0-9_-]{7}:[A-Za-z0-9_-]{140}"),
    "Azure Storage Key":    re.compile(r"AccountKey=[a-zA-Z0-9+/]{86}=="),
    "Azure Client Secret":  re.compile(r"(?i)client.{0,10}secret.{0,10}['\"][a-zA-Z0-9~\-_.]{34,}['\"]"),
    "JWT Token":            re.compile(r"eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}"),
    "NPM Token":            re.compile(r"npm_[a-zA-Z0-9]{36}"),
    "PyPI Token":           re.compile(r"pypi-[a-zA-Z0-9\-_]{32,}"),
    "Heroku API Key":       re.compile(r"(?i)heroku.{0,10}[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"),
    "Mailgun API Key":      re.compile(r"key-[0-9a-f]{32}"),
    "Password in JSON":     re.compile(r'"password"\s*:\s*"[^"]{4,}"'),
    "Password in XML":      re.compile(r'<password>[^<]{4,}</password>', re.I),
    "Credit Card":          re.compile(r"\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12})\b"),
}

_HIGH_SECRETS: dict[str, re.Pattern] = {
    "Internal IP":      re.compile(r"\b(?:10\.[0-9]{1,3}|172\.(?:1[6-9]|2[0-9]|3[01])|192\.168)\.[0-9]{1,3}\.[0-9]{1,3}\b"),
    "Stack Trace":      re.compile(r"Traceback \(most recent call last\)|at [A-Za-z]+\.[A-Za-z]+\(|java\.lang\.", re.I),
    "DB Error":         re.compile(r"ORA-[0-9]+|MySQL.*Error|PostgreSQL.*ERROR|MSSQL.*Error", re.I),
    "S3 Bucket Name":   re.compile(r"s3\.amazonaws\.com/[a-z0-9\-]+"),
    "MongoDB URI":      re.compile(r"mongodb(?:\+srv)?://[^\s\"'<>]+"),
    "Redis URI":        re.compile(r"redis://[^\s\"'<>]+"),
    "Connection String": re.compile(r"(?:Server|Data Source)=[^;]+;(?:Database|Initial Catalog)=", re.I),
}

_MEDIUM_SECRETS: dict[str, re.Pattern] = {
    "Email Dump (5+)":   re.compile(r"[a-zA-Z0-9._%+-]{3,}@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"),
    "Debug Info":        re.compile(r"DEBUG\s*=\s*True|__debug__|var_dump\(|print_r\(", re.I),
    "Version Disclosure": re.compile(r"(?:Apache|nginx|IIS|PHP|ASP\.NET)/[0-9]+\.[0-9]+", re.I),
    "Path Disclosure":   re.compile(r"(?:/home/[a-z]+/|/var/www/|C:\\inetpub\\|C:\\Users\\)[^\s\"'<>]+"),
}

_SENSITIVE_PATHS = [
    "/", "/api", "/api/v1", "/api/v2", "/api/v3",
    "/graphql", "/swagger", "/swagger.json", "/openapi.json", "/api-docs",
    "/.env", "/config", "/config.json", "/settings", "/settings.json",
    "/debug", "/health", "/status", "/metrics", "/info", "/actuator",
    "/admin", "/api/users", "/api/user/me", "/api/me", "/api/profile",
    "/api/admin", "/api/config", "/_debug", "/phpinfo.php",
    "/web.config", "/app.config", "/appsettings.json",
]


def _shannon_entropy(s: str) -> float:
    """Calcule l'entropie de Shannon d'une chaîne."""
    if not s:
        return 0.0
    freq: dict[str, int] = {}
    for c in s:
        freq[c] = freq.get(c, 0) + 1
    n = len(s)
    return -sum((f / n) * math.log2(f / n) for f in freq.values())


def _has_enough_entropy(match: str, min_entropy: float = 3.5) -> bool:
    """Vérifie qu'un match n'est pas un placeholder de faible entropie."""
    return _shannon_entropy(match) >= min_entropy


class SensitiveDataScanner(ScannerMixin):
    def __init__(self, req: Requester, heuristic: HeuristicEngine, cfg: PhantomConfig):
        self._req = req
        self._heuristic = heuristic
        self._cfg = cfg

    async def run(self, target: str) -> AsyncIterator[Finding]:
        parsed = urlparse(target)
        base = f"{parsed.scheme}://{parsed.netloc}"
        found_urls: set[str] = set()

        for path in _SENSITIVE_PATHS:
            url = f"{base}{path}"
            resp = await self._req.get(url)

            if resp.error or resp.status not in (200, 201):
                continue
            if FPFilter.is_cloudflare(resp.body):
                continue

            body = resp.body
            # Aussi scanner les headers de réponse
            headers_str = str(resp.headers)
            combined = body + "\n" + headers_str

            # ── Secrets CRITICAL ─────────────────────────────────────────────
            for name, pattern in _CRITICAL_SECRETS.items():
                matches = pattern.findall(combined)
                if not matches:
                    continue
                evidence = str(matches[0])[:200]

                # Vérification d'entropie pour les secrets longs
                if len(evidence) > 20 and not _has_enough_entropy(evidence):
                    continue

                # Anti-FP : ignorer les placeholders connus
                placeholders = {"YOUR_KEY_HERE", "xxx", "placeholder", "changeme", "your_secret"}
                if evidence.lower() in placeholders:
                    continue

                cache_key = f"{url}:{name}"
                if cache_key in found_urls:
                    continue
                found_urls.add(cache_key)

                yield Finding(
                    title=f"Secret Exposé — {name}",
                    severity=Severity.CRITICAL,
                    url=url,
                    module="vulns/sensitive_data",
                    description=(
                        f"Une credential de type **{name}** a été trouvée dans la réponse HTTP de `{path}`. "
                        f"Ce secret doit être révoqué immédiatement car il est exposé publiquement."
                    ),
                    evidence=self._redact(evidence),
                    cwe="CWE-200",
                    remediation=(
                        f"1. Révoquer immédiatement le {name} exposé. "
                        f"2. Auditer les accès récents avec ce credential. "
                        f"3. Utiliser un gestionnaire de secrets (AWS Secrets Manager, HashiCorp Vault, etc.). "
                        f"4. Ne jamais stocker de secrets en dur dans le code ou les réponses HTTP."
                    ),
                )

            # ── Secrets HIGH ─────────────────────────────────────────────────
            for name, pattern in _HIGH_SECRETS.items():
                matches = pattern.findall(combined)
                if not matches:
                    continue
                evidence = str(matches[0])[:200]
                cache_key = f"{url}:{name}"
                if cache_key in found_urls:
                    continue
                found_urls.add(cache_key)

                yield Finding(
                    title=f"Sensitive Data Exposure — {name}",
                    severity=Severity.HIGH,
                    url=url,
                    module="vulns/sensitive_data",
                    description=f"Données sensibles de type '{name}' détectées dans la réponse de `{path}`.",
                    evidence=evidence,
                    cwe="CWE-200",
                    remediation=(
                        f"Supprimer les {name} des réponses HTTP en production. "
                        f"Configurer les niveaux de log/debug correctement."
                    ),
                )

            # ── Email dump (Medium — seulement si 5+ emails) ─────────────────
            pattern_email = _MEDIUM_SECRETS["Email Dump (5+)"]
            email_matches = pattern_email.findall(body)
            # Filtrer les faux positifs (domaines communs dans le code source)
            real_emails = [m for m in email_matches if not any(d in m for d in [
                "example.com", "test.com", "sentry.io", "fonts.google"
            ])]
            if len(real_emails) >= 5:
                cache_key = f"{url}:email_dump"
                if cache_key not in found_urls:
                    found_urls.add(cache_key)
                    yield Finding(
                        title=f"Email Dump — {len(real_emails)} adresses exposées",
                        severity=Severity.MEDIUM,
                        url=url,
                        module="vulns/sensitive_data",
                        description=(
                            f"{len(real_emails)} adresses email ont été trouvées dans la réponse de `{path}`. "
                            f"Cela peut constituer une violation RGPD/CCPA si ces adresses sont personnelles."
                        ),
                        evidence=", ".join(real_emails[:5]) + ("..." if len(real_emails) > 5 else ""),
                        cwe="CWE-200",
                        remediation=(
                            "Restreindre l'accès aux endpoints exposant des données personnelles. "
                            "Implémenter l'authentification et le filtrage des réponses."
                        ),
                    )

            # ── Debug info (Medium) ───────────────────────────────────────────
            for name, pattern in _MEDIUM_SECRETS.items():
                if name == "Email Dump (5+)":
                    continue
                if pattern.search(combined):
                    cache_key = f"{url}:{name}"
                    if cache_key in found_urls:
                        continue
                    found_urls.add(cache_key)
                    yield Finding(
                        title=f"Information Disclosure — {name}",
                        severity=Severity.MEDIUM,
                        url=url,
                        module="vulns/sensitive_data",
                        description=f"Disclosure de type '{name}' sur `{path}`. Peut faciliter la reconnaissance d'un attaquant.",
                        evidence=(pattern.search(combined).group(0) or "")[:150],
                        cwe="CWE-200",
                        remediation="Désactiver le mode debug en production. Masquer les informations de version.",
                    )

    @staticmethod
    def _redact(s: str) -> str:
        """Masque partiellement un secret pour l'evidence (sécurité du rapport)."""
        if len(s) <= 8:
            return "****"
        return s[:4] + "..." + s[-4:]
