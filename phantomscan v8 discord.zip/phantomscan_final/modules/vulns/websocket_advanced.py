"""
PhantomScan — WebSocket Advanced Scanner v2.0
Détecte les vulnérabilités dans les connexions WebSocket.

v2.0 :
- Test d'injection de payloads via HTTP fallback (corps JSON)
- Test Cross-Site WebSocket Hijacking (CSWSH)
- Test Origin spoofing avec multiples variants
- Détection réponses reflétées (XSS/injection dans WS)
- Test d'absence d'auth token sur endpoint WS
"""
from __future__ import annotations
import re
from typing import AsyncIterator
from urllib.parse import urlparse
from phantomscan.core.requester import Requester, ProbeRequest
from phantomscan.config import PhantomConfig
from phantomscan.core.heuristic import HeuristicEngine
from phantomscan.output.reporter import Finding, Severity
from core.fp_filter import FPFilter
from phantomscan.core.scanner_mixin import ScannerMixin

_WS_PATHS = [
    "/ws", "/websocket", "/socket", "/socket.io", "/api/ws",
    "/realtime", "/live", "/stream", "/hub", "/events",
    "/api/v1/ws", "/cable", "/actioncable",
]

_EVIL_ORIGINS = [
    "https://evil.com",
    "https://attacker.com",
    "null",
    "http://localhost",
]

_INJECTION_PAYLOADS = [
    '{"type":"message","data":"<img src=x onerror=alert(1)>"}',
    '{"action":"ping","data":"\' OR 1=1--"}',
    '{"cmd":"{{7*7}}"}',
    '{"event":"subscribe","channel":"../../../etc/passwd"}',
]

_CSWSH_INDICATORS = re.compile(
    r'"message"|"data"|"event"|"channel"|"subscribe"', re.I
)


class WebSocketAdvancedScanner(ScannerMixin):
    def __init__(self, req: Requester, heuristic: HeuristicEngine, cfg: PhantomConfig):
        self._req = req
        self._heuristic = heuristic
        self._cfg = cfg

    async def run(self, target: str) -> AsyncIterator[Finding]:
        parsed = urlparse(target)
        base = f"{parsed.scheme}://{parsed.netloc}"

        for path in _WS_PATHS:
            url = f"{base}{path}"

            # Probe initiale
            resp = await self._req.get(url)
            if resp.error:
                continue
            if FPFilter.is_cloudflare(resp.body):
                continue

            # Détecter si c'est probablement un endpoint WebSocket
            is_ws = (
                resp.status in (101, 200, 400, 426) or
                "websocket" in resp.body.lower() or
                "upgrade" in str(resp.headers).lower() or
                "socket.io" in resp.body.lower()
            )
            if not is_ws:
                continue

            # ── Test 1 : CORS / Origin Spoofing ─────────────────────────────
            for evil_origin in _EVIL_ORIGINS:
                resp_cors = await self._req.send(ProbeRequest(
                    method="GET", url=url,
                    headers={
                        "Origin": evil_origin,
                        "Upgrade": "websocket",
                        "Connection": "Upgrade",
                        "Sec-WebSocket-Key": "dGhlIHNhbXBsZSBub25jZQ==",
                        "Sec-WebSocket-Version": "13",
                    }
                ))
                if resp_cors.error:
                    continue
                if resp_cors.status in (101, 200):
                    allow_origin = str(resp_cors.headers.get("access-control-allow-origin", ""))
                    if evil_origin in allow_origin or allow_origin == "*":
                        yield Finding(
                            title=f"WebSocket CORS Misconfiguration — {path}",
                            severity=Severity.HIGH,
                            url=url,
                            module="vulns/websocket_advanced",
                            description=(
                                f"Le endpoint WebSocket `{path}` accepte les connexions depuis "
                                f"l'origine externe `{evil_origin}`. Un attaquant peut établir "
                                f"une connexion WebSocket depuis son site et intercepter/envoyer des messages."
                            ),
                            evidence=f"Origin: {evil_origin} → Status: {resp_cors.status}, "
                                     f"ACAO: {allow_origin or 'non défini mais connexion acceptée'}",
                            cwe="CWE-346",
                            remediation=(
                                "Valider l'en-tête Origin sur les connexions WebSocket via une whitelist stricte. "
                                "Rejeter les origines inconnues avec HTTP 403. "
                                "Exemple : `if origin not in ALLOWED_ORIGINS: raise 403`"
                            ),
                        )
                        break  # Une seule fois par path

            # ── Test 2 : Cross-Site WebSocket Hijacking (CSWSH) ─────────────
            # Si le WS ne vérifie pas l'origine ET utilise les cookies de session
            resp_no_origin = await self._req.send(ProbeRequest(
                method="GET", url=url,
                headers={
                    "Upgrade": "websocket",
                    "Connection": "Upgrade",
                    "Sec-WebSocket-Key": "x3JJHMbDL1EzLkh9GBhXDw==",
                    "Sec-WebSocket-Version": "13",
                }
            ))
            if not resp_no_origin.error and resp_no_origin.status in (101, 200):
                # Vérifier si la réponse contient des données sensibles
                if _CSWSH_INDICATORS.search(resp_no_origin.body):
                    yield Finding(
                        title=f"Cross-Site WebSocket Hijacking (CSWSH) — {path}",
                        severity=Severity.HIGH,
                        url=url,
                        module="vulns/websocket_advanced",
                        description=(
                            f"Le endpoint `{path}` accepte les connexions WebSocket sans vérification "
                            f"d'origine et retourne des données structurées. Un attaquant peut créer "
                            f"une page malveillante qui se connecte à ce WebSocket via le navigateur "
                            f"de la victime et lit ses données privées."
                        ),
                        evidence=resp_no_origin.body[:300],
                        cwe="CWE-352",
                        remediation=(
                            "Implémenter un token CSRF dans le handshake WebSocket. "
                            "Valider l'en-tête Origin. "
                            "Ne pas se fier uniquement aux cookies pour l'authentification WebSocket."
                        ),
                    )

            # ── Test 3 : Injection via HTTP POST fallback ────────────────────
            for payload in _INJECTION_PAYLOADS:
                resp_inject = await self._req.send(ProbeRequest(
                    method="POST", url=url,
                    headers={"Content-Type": "application/json"},
                    body=payload
                ))
                if resp_inject.error or FPFilter.is_fp(resp_inject.body, resp_inject.status):
                    continue
                # Détecter si le payload est réfléchi
                injected_val = re.search(r'"data"\s*:\s*"([^"]+)"', payload)
                if injected_val and injected_val.group(1) in resp_inject.body:
                    yield Finding(
                        title=f"WebSocket Endpoint — Reflected Input — {path}",
                        severity=Severity.MEDIUM,
                        url=url,
                        module="vulns/websocket_advanced",
                        description=(
                            f"Le endpoint WebSocket `{path}` reflète les données entrantes "
                            f"sans encodage. Potentiellement exploitable pour XSS ou injection."
                        ),
                        evidence=f"Payload: {payload[:100]} → Réfléchi dans: {resp_inject.body[:200]}",
                        cwe="CWE-79",
                        remediation=(
                            "Encoder toutes les données utilisateur avant de les renvoyer via WebSocket. "
                            "Valider et sanitiser les messages entrants côté serveur."
                        ),
                    )
                    break

            # ── Test 4 : Endpoint sans authentification ──────────────────────
            if resp.status == 200 and "auth" not in resp.body.lower() and "unauthorized" not in resp.body.lower():
                # Tester sans cookies/auth headers
                req_no_auth = ProbeRequest(method="GET", url=url, headers={
                    "Upgrade": "websocket", "Connection": "Upgrade",
                    "Sec-WebSocket-Key": "dGhlIHNhbXBsZSBub25jZQ==",
                    "Sec-WebSocket-Version": "13",
                })
                resp_no_auth = await self._req.send(req_no_auth)
                if not resp_no_auth.error and resp_no_auth.status in (101, 200):
                    if len(resp_no_auth.body) > 50:  # A de la substance
                        yield Finding(
                            title=f"WebSocket Unauthenticated Access — {path}",
                            severity=Severity.MEDIUM,
                            url=url,
                            module="vulns/websocket_advanced",
                            description=(
                                f"Le endpoint WebSocket `{path}` est accessible sans authentification "
                                f"et retourne des données non vides."
                            ),
                            evidence=resp_no_auth.body[:200],
                            cwe="CWE-306",
                            remediation=(
                                "Exiger une authentification avant l'établissement de la connexion WebSocket. "
                                "Vérifier le token JWT ou la session dans le handshake HTTP initial."
                            ),
                        )
