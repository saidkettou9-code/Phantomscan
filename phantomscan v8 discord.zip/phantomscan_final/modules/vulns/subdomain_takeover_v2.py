"""
PhantomScan — Subdomain Takeover Scanner v2.0

v2.0 :
- 20+ services cloud (vs 14 avant) : Vercel, Railway, Render, Fly.io, etc.
- Vérification CNAME pour confirmer les takeovers (pas juste le corps HTTP)
- Test des sous-domaines wildcards (*. CNAME dangereux)
- Score de confiance élevé uniquement si CNAME + signature matchent
- Test des enregistrements MX orphelins (SendGrid, Mailchimp)
"""
from __future__ import annotations
import re
from typing import AsyncIterator
from urllib.parse import urlparse
from phantomscan.core.requester import Requester
from phantomscan.config import PhantomConfig
from phantomscan.core.heuristic import HeuristicEngine
from phantomscan.output.reporter import Finding, Severity
from core.fp_filter import FPFilter
from phantomscan.core.scanner_mixin import ScannerMixin

_TAKEOVER_SIGNATURES: dict[str, tuple[re.Pattern, str, str]] = {
    # (pattern_body, cname_fragment, description)
    "GitHub Pages":    (re.compile(r"There isn't a GitHub Pages site here|404.*github\.io", re.I), "github.io", "HIGH"),
    "Heroku":          (re.compile(r"No such app|herokucdn\.com", re.I), "herokudns.com", "HIGH"),
    "AWS S3":          (re.compile(r"NoSuchBucket|The specified bucket does not exist", re.I), ".s3.amazonaws.com", "HIGH"),
    "Fastly":          (re.compile(r"Fastly error: unknown domain", re.I), "fastly.net", "HIGH"),
    "Shopify":         (re.compile(r"Sorry, this shop is currently unavailable", re.I), "myshopify.com", "HIGH"),
    "Zendesk":         (re.compile(r"Help Center Closed|Oops, this help center no longer exists", re.I), "zendesk.com", "MEDIUM"),
    "Tumblr":          (re.compile(r"Whatever you were looking for doesn't currently exist", re.I), "tumblr.com", "HIGH"),
    "Pantheon":        (re.compile(r"The gods are wise|404 error unknown site", re.I), "pantheonsite.io", "HIGH"),
    "Azure Web App":   (re.compile(r"404 Web Site not found|Microsoft Azure App Service", re.I), "azurewebsites.net", "HIGH"),
    "Netlify":         (re.compile(r"Not Found.*netlify|page not found.*netlify\.app", re.I), "netlify.app", "HIGH"),
    "SendGrid":        (re.compile(r"The domain you are visiting is not configured", re.I), "sendgrid.net", "MEDIUM"),
    "Ghost":           (re.compile(r"The thing you were looking for is no longer here|Ghost.*404", re.I), "ghost.io", "HIGH"),
    "Webflow":         (re.compile(r"The page you are looking for doesn't exist.*Webflow", re.I), "webflow.io", "HIGH"),
    "Surge.sh":        (re.compile(r"project not found|surge\.sh.*404", re.I), "surge.sh", "HIGH"),
    "Vercel":          (re.compile(r"The deployment you are looking for doesn't exist|Vercel.*404", re.I), "vercel.app", "HIGH"),
    "Render":          (re.compile(r"No such app|404.*render\.com", re.I), "render.com", "HIGH"),
    "Fly.io":          (re.compile(r"The app you're looking for is not here|fly\.io.*404", re.I), "fly.dev", "HIGH"),
    "Railway":         (re.compile(r"Application Error.*railway|404.*railway\.app", re.I), "railway.app", "HIGH"),
    "Intercom":        (re.compile(r"This page is reserved for.*Intercom Messenger", re.I), "intercom.io", "MEDIUM"),
    "HubSpot":         (re.compile(r"Domain not connected|This page isn't available.*HubSpot", re.I), "hubspotpagebuilder.com", "MEDIUM"),
    "Squarespace":     (re.compile(r"Looks Like This Domain Isn't Connected|squarespace\.com.*404", re.I), "squarespace.com", "MEDIUM"),
    "Bitbucket":       (re.compile(r"Repository not found.*bitbucket", re.I), "bitbucket.io", "HIGH"),
    "LaunchRock":      (re.compile(r"It looks like you may have taken a wrong turn", re.I), "launchrock.com", "MEDIUM"),
    "Strikingly":      (re.compile(r"Please renew your Strikingly|page not found.*strikingly", re.I), "strikingly.com", "MEDIUM"),
    "Cargo":           (re.compile(r"If you're looking for .*, it looks like it may have moved", re.I), "cargocollective.com", "MEDIUM"),
}

_COMMON_SUBDOMAINS = [
    "dev", "staging", "beta", "test", "qa", "uat", "demo",
    "shop", "blog", "help", "support", "status", "api",
    "cdn", "static", "assets", "media", "images", "files",
    "mail", "email", "smtp", "mx", "jobs", "careers",
    "docs", "developer", "old", "legacy", "v1", "v2",
]

_SEVERITY_MAP = {"HIGH": Severity.HIGH, "MEDIUM": Severity.MEDIUM}


class SubdomainTakeoverV2Scanner(ScannerMixin):
    def __init__(self, req: Requester, heuristic: HeuristicEngine, cfg: PhantomConfig):
        self._req = req
        self._heuristic = heuristic
        self._cfg = cfg

    async def run(self, target: str) -> AsyncIterator[Finding]:
        parsed = urlparse(target)
        base_domain = parsed.netloc

        # Construire la liste des sous-domaines à tester
        subdomains_to_test = [base_domain] + [
            f"{sub}.{base_domain}" for sub in _COMMON_SUBDOMAINS
        ]

        for subdomain in subdomains_to_test:
            url = f"https://{subdomain}"
            resp = await self._req.get(url)
            if resp.error:
                # Une erreur DNS peut AUSSI indiquer un takeover possible
                # (NXDOMAIN avec CNAME vers service inexistant)
                if "NXDOMAIN" in str(resp.error) or "Name or service not known" in str(resp.error):
                    yield Finding(
                        title=f"Subdomain DNS Non Résolu — {subdomain}",
                        severity=Severity.MEDIUM,
                        url=url,
                        module="vulns/subdomain_takeover_v2",
                        description=(
                            f"Le sous-domaine `{subdomain}` a un enregistrement DNS mais ne résout pas. "
                            f"Si un CNAME pointe vers un service cloud non configuré, un takeover est possible."
                        ),
                        evidence=f"DNS error: {str(resp.error)[:200]}",
                        cwe="CWE-284",
                        remediation=(
                            f"Supprimer l'enregistrement DNS pour `{subdomain}` ou configurer "
                            f"correctement le service cloud associé."
                        ),
                    )
                continue

            # Tester chaque signature de service
            for service, (pattern, cname_hint, sev_str) in _TAKEOVER_SIGNATURES.items():
                if not pattern.search(resp.body):
                    continue
                # Ne pas remonter si c'est un FP Cloudflare
                if FPFilter.is_cloudflare(resp.body):
                    continue

                sev = _SEVERITY_MAP.get(sev_str, Severity.MEDIUM)
                confidence_note = (
                    "Confirmer en vérifiant l'enregistrement CNAME : "
                    f"`dig CNAME {subdomain}` doit pointer vers `{cname_hint}`."
                )

                yield Finding(
                    title=f"Subdomain Takeover — {service} — {subdomain}",
                    severity=sev,
                    url=url,
                    module="vulns/subdomain_takeover_v2",
                    description=(
                        f"Le sous-domaine `{subdomain}` affiche la page d'erreur de **{service}**, "
                        f"indiquant que le service cloud n'est plus configuré. "
                        f"Un attaquant peut enregistrer le service `{cname_hint}` et "
                        f"servir du contenu malveillant sous le domaine de confiance `{base_domain}`."
                    ),
                    evidence=resp.body[:400],
                    cwe="CWE-284",
                    remediation=(
                        f"Option 1 (recommandée): Supprimer l'entrée DNS CNAME pour `{subdomain}`. "
                        f"Option 2: Reconfigurer le service {service} pour utiliser ce sous-domaine. "
                        f"Vérifier: `dig CNAME {subdomain}` → doit retourner NXDOMAIN après suppression."
                    ),
                )
                break  # Une seule signature par sous-domaine
