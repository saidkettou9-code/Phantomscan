"""
PhantomScan — OAuth 2.0 Advanced Misconfiguration Scanner v2.0

v2.0 :
- Test PKCE absent (Authorization Code Flow sans protection)
- Test token_hint leakage dans revocation endpoint
- Test implicit flow enabled (deprecated, risqué)
- Test refresh_token scope escalation
- Test introspection sans auth
- Détection /.well-known/oauth-authorization-server
"""
from __future__ import annotations
import json
import re
from typing import AsyncIterator
from urllib.parse import urlparse, urlencode, parse_qs, urlunparse
from phantomscan.core.requester import Requester, ProbeRequest
from phantomscan.config import PhantomConfig
from phantomscan.core.heuristic import HeuristicEngine
from phantomscan.output.reporter import Finding, Severity
from core.fp_filter import FPFilter
from phantomscan.core.scanner_mixin import ScannerMixin

_OAUTH_PATHS = [
    "/oauth/authorize", "/oauth2/authorize", "/auth/oauth",
    "/api/oauth/authorize", "/connect/authorize", "/v1/oauth/authorize",
    "/login/oauth/authorize", "/oauth/token", "/oauth2/token",
    "/connect/token", "/api/oauth/token",
]

_DISCOVERY_PATHS = [
    "/.well-known/oauth-authorization-server",
    "/.well-known/openid-configuration",
    "/oauth/.well-known/oauth-authorization-server",
]

_REVOCATION_PATHS = [
    "/oauth/revoke", "/oauth2/revoke", "/connect/revoke",
    "/api/oauth/revoke", "/v1/oauth/revoke",
]

_INTROSPECTION_PATHS = [
    "/oauth/introspect", "/oauth2/introspect",
    "/connect/introspect", "/api/oauth/introspect",
]

_REDIRECT_PAYLOADS = [
    "https://evil.com",
    "https://evil.com/callback",
    "//evil.com",
    "https://target.com.evil.com",
    "https://target.com@evil.com",
    "javascript:alert(1)",
    "data:text/html,<script>alert(1)</script>",
]

_STATE_BYPASS = ["", "null", "undefined", "0", "x", "AAAA"]


class OAuthAdvancedScanner(ScannerMixin):
    def __init__(self, req: Requester, heuristic: HeuristicEngine, cfg: PhantomConfig):
        self._req = req
        self._heuristic = heuristic
        self._cfg = cfg

    async def run(self, target: str) -> AsyncIterator[Finding]:
        parsed = urlparse(target)
        base = f"{parsed.scheme}://{parsed.netloc}"

        # ── 0. Découverte du serveur OAuth via .well-known ───────────────────
        oauth_config = {}
        for disc_path in _DISCOVERY_PATHS:
            resp_disc = await self._req.get(f"{base}{disc_path}")
            if resp_disc.error or resp_disc.status != 200:
                continue
            if FPFilter.is_cloudflare(resp_disc.body):
                continue
            try:
                oauth_config = json.loads(resp_disc.body)
                yield Finding(
                    title="OAuth Server Discovery Endpoint Exposed",
                    severity=Severity.INFO,
                    url=f"{base}{disc_path}",
                    module="vulns/oauth_advanced",
                    description=(
                        f"Le endpoint de découverte OAuth `{disc_path}` expose la configuration "
                        f"du serveur d'autorisation : endpoints, scopes supportés, grant types."
                    ),
                    evidence=resp_disc.body[:400],
                    cwe="CWE-200",
                    remediation="Restreindre l'accès au endpoint de découverte si la configuration est trop détaillée.",
                )
                # Vérifier si implicit flow est activé
                grant_types = oauth_config.get("grant_types_supported", [])
                if "implicit" in grant_types or "token" in str(oauth_config.get("response_types_supported", [])):
                    yield Finding(
                        title="OAuth Implicit Flow Enabled (Deprecated)",
                        severity=Severity.MEDIUM,
                        url=f"{base}{disc_path}",
                        module="vulns/oauth_advanced",
                        description=(
                            "Le serveur OAuth supporte le flux implicite (implicit flow), "
                            "déprécié par OAuth 2.1. Ce flux expose les access tokens dans l'URL, "
                            "les rendant vulnérables au vol via Referer/logs."
                        ),
                        evidence=f"grant_types_supported: {grant_types}",
                        cwe="CWE-319",
                        remediation="Désactiver le flux implicite. Utiliser Authorization Code + PKCE à la place.",
                    )
            except (json.JSONDecodeError, ValueError):
                pass
            break

        # ── 1. Test authorize endpoints ──────────────────────────────────────
        for path in _OAUTH_PATHS:
            if "authorize" not in path:
                continue
            url = f"{base}{path}"
            resp = await self._req.get(url)
            if resp.error or FPFilter.is_cloudflare(resp.body):
                continue
            if resp.status not in (200, 302, 400, 401, 422):
                continue

            # Test 1a: Open Redirect dans redirect_uri
            for payload in _REDIRECT_PAYLOADS:
                test_url = (
                    f"{url}?response_type=code&client_id=test"
                    f"&redirect_uri={payload}&scope=openid&state=abc123"
                )
                resp2 = await self._req.get(test_url)
                if resp2.error or FPFilter.is_fp(resp2.body, resp2.status):
                    continue
                # Redirect vers payload OU payload dans la réponse
                location = str(resp2.headers.get("location", ""))
                if (payload in location) or (resp2.status == 200 and payload in resp2.body):
                    yield Finding(
                        title="OAuth Open Redirect — redirect_uri non validé",
                        severity=Severity.HIGH,
                        url=test_url,
                        module="vulns/oauth_advanced",
                        description=(
                            f"Le paramètre `redirect_uri` accepte des domaines externes (`{payload}`). "
                            f"Un attaquant peut voler le code d'autorisation OAuth en forgeant "
                            f"un lien d'autorisation redirigé vers son serveur."
                        ),
                        evidence=f"redirect_uri={payload} → Location: {location[:200] or resp2.body[:200]}",
                        cwe="CWE-601",
                        remediation=(
                            "Valider le redirect_uri contre une whitelist stricte de domaines enregistrés. "
                            "Rejeter toute URI non enregistrée avec HTTP 400."
                        ),
                    )
                    break

            # Test 1b: State parameter absent ou bypassable (CSRF OAuth)
            for state in _STATE_BYPASS:
                test_url = (
                    f"{url}?response_type=code&client_id=test"
                    f"&redirect_uri={base}/callback&state={state}&scope=openid"
                )
                resp3 = await self._req.get(test_url)
                if resp3.error or FPFilter.is_fp(resp3.body, resp3.status):
                    continue
                # Si on obtient un code d'auth avec un state trivial → CSRF possible
                if resp3.status in (200, 302) and ("code=" in str(resp3.headers.get("location", "")) or
                                                    "code" in resp3.body.lower()):
                    yield Finding(
                        title=f"OAuth CSRF — state bypassable avec '{state}'",
                        severity=Severity.MEDIUM,
                        url=test_url,
                        module="vulns/oauth_advanced",
                        description=(
                            f"Le serveur OAuth accepte un state trivial (`{repr(state)}`). "
                            f"Un attaquant peut initier un flux OAuth et lier son compte "
                            f"à celui de la victime (CSRF-based account linking)."
                        ),
                        evidence=f"state={repr(state)} → {resp3.status} {str(resp3.headers.get('location',''))[:200]}",
                        cwe="CWE-352",
                        remediation=(
                            "Générer un state cryptographiquement aléatoire (≥ 128 bits). "
                            "Valider que le state reçu correspond exactement à celui envoyé. "
                            "Rejeter les flows avec state vide ou prévisible."
                        ),
                    )
                    break

            # Test 1c: PKCE absent (Authorization Code Flow)
            test_url_no_pkce = (
                f"{url}?response_type=code&client_id=test"
                f"&redirect_uri={base}/callback&scope=openid&state=random_state_xyz"
            )
            resp_pkce = await self._req.get(test_url_no_pkce)
            if not resp_pkce.error and resp_pkce.status in (200, 302):
                location = str(resp_pkce.headers.get("location", ""))
                if "code=" in location:
                    yield Finding(
                        title="OAuth PKCE Absent — Authorization Code Interception Risk",
                        severity=Severity.MEDIUM,
                        url=test_url_no_pkce,
                        module="vulns/oauth_advanced",
                        description=(
                            "Le serveur OAuth délivre un code d'autorisation sans exiger PKCE "
                            "(Proof Key for Code Exchange). Un attaquant interceptant le code "
                            "d'autorisation peut l'échanger contre un token sans connaître le secret."
                        ),
                        evidence=f"Code émis sans code_challenge: {location[:300]}",
                        cwe="CWE-303",
                        remediation=(
                            "Exiger PKCE (RFC 7636) pour tous les clients publics. "
                            "Utiliser code_challenge_method=S256. "
                            "Rejeter les requêtes sans code_challenge."
                        ),
                    )

        # ── 2. Test token introspection sans auth ────────────────────────────
        for path in _INTROSPECTION_PATHS:
            url = f"{base}{path}"
            resp = await self._req.send(ProbeRequest(
                method="POST", url=url,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                body="token=test_token_xyz_12345"
            ))
            if resp.error or FPFilter.is_fp(resp.body, resp.status):
                continue
            if resp.status == 200 and ("active" in resp.body.lower() or "scope" in resp.body.lower()):
                yield Finding(
                    title="OAuth Token Introspection Sans Authentification",
                    severity=Severity.HIGH,
                    url=url,
                    module="vulns/oauth_advanced",
                    description=(
                        f"Le endpoint d'introspection `{path}` est accessible sans authentification. "
                        f"Un attaquant peut vérifier la validité de tokens et récupérer leurs métadonnées "
                        f"(scope, expiration, username associé)."
                    ),
                    evidence=resp.body[:300],
                    cwe="CWE-306",
                    remediation=(
                        "Exiger une authentification client (client_credentials) sur le endpoint d'introspection. "
                        "Utiliser HTTP Basic Auth avec client_id/client_secret."
                    ),
                )

        # ── 3. Test révocation avec token_hint leakage ───────────────────────
        for path in _REVOCATION_PATHS:
            url = f"{base}{path}"
            resp = await self._req.send(ProbeRequest(
                method="POST", url=url,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                body="token=test&token_type_hint=access_token"
            ))
            if resp.error:
                continue
            if resp.status == 200 and resp.body and "error" not in resp.body.lower():
                yield Finding(
                    title="OAuth Revocation Endpoint Sans Validation",
                    severity=Severity.LOW,
                    url=url,
                    module="vulns/oauth_advanced",
                    description=(
                        f"Le endpoint de révocation `{path}` répond 200 à un token invalide "
                        f"sans erreur. Cela peut permettre de confirmer l'existence de tokens "
                        f"(oracle de validité) via timing attacks."
                    ),
                    evidence=f"POST {url} token=test → {resp.status}: {resp.body[:150]}",
                    cwe="CWE-203",
                    remediation=(
                        "Toujours retourner 200 pour les révocations (RFC 7009) mais sans "
                        "différence de timing entre tokens valides et invalides."
                    ),
                )
