"""
PhantomScan — GraphQL Advanced Scanner v2.0

v2.0 :
- Test field suggestions enabled (information disclosure)
- Test alias-based query amplification (DoS)
- Test depth/complexity limit bypass
- Test mutation rate limiting
- Test field-level authorization bypass via alias
- Détection de directives dangereuses (@deprecated exposées)
"""
from __future__ import annotations
import json
import re
from typing import AsyncIterator
from urllib.parse import urlparse
from phantomscan.core.requester import Requester, ProbeRequest
from phantomscan.config import PhantomConfig
from phantomscan.core.heuristic import HeuristicEngine
from phantomscan.output.reporter import Finding, Severity
from core.fp_filter import FPFilter
from phantomscan.core.scanner_mixin import ScannerMixin

_GQL_PATHS = [
    "/graphql", "/api/graphql", "/v1/graphql", "/v2/graphql",
    "/gql", "/query", "/api/query", "/graphiql",
    "/playground", "/api/v1/graphql",
]

_INTROSPECTION_QUERY = '{"query":"{__schema{types{name fields{name type{name kind}}}}}"}'
_TYPENAME_QUERY = '{"query":"{__typename}"}'

# Batching avec 10 requêtes pour tester la limite
_BATCHING_QUERY = json.dumps([{"query": "{__typename}"} for _ in range(10)])

# Query profonde pour tester les limites de profondeur
_DEEP_QUERY = '{"query":"{ a { b { c { d { e { f { g { h { __typename }}}}}}}}}}"}'

# Query avec aliases pour amplification
_ALIAS_AMPLIFICATION = '{"query":"{' + " ".join(f"q{i}:__typename" for i in range(50)) + '}"}'

_FIELD_SUGGESTION_PATTERN = re.compile(
    r"Did you mean|suggestions?|similar field|field.*not found", re.I
)
_ERROR_PATTERN = re.compile(r'"errors"\s*:\s*\[', re.I)
_TYPES_PATTERN = re.compile(r'"__schema".*"types"', re.S)


def _gql_post(url: str, body: str) -> ProbeRequest:
    return ProbeRequest(
        method="POST", url=url,
        headers={"Content-Type": "application/json"},
        body=body
    )


class GraphQLAdvancedScanner(ScannerMixin):
    def __init__(self, req: Requester, heuristic: HeuristicEngine, cfg: PhantomConfig):
        self._req = req
        self._heuristic = heuristic
        self._cfg = cfg

    async def run(self, target: str) -> AsyncIterator[Finding]:
        parsed = urlparse(target)
        base = f"{parsed.scheme}://{parsed.netloc}"

        for path in _GQL_PATHS:
            url = f"{base}{path}"

            # Vérifier que l'endpoint existe
            resp_probe = await self._req.send(_gql_post(url, _TYPENAME_QUERY))
            if resp_probe.error:
                continue
            if FPFilter.is_cloudflare(resp_probe.body):
                continue
            if resp_probe.status not in (200, 400):
                continue
            # Vérifier que c'est bien du GraphQL
            is_graphql = (
                '"__typename"' in resp_probe.body or
                '"data"' in resp_probe.body or
                '"errors"' in resp_probe.body
            )
            if not is_graphql:
                continue

            # ── Test 1 : Introspection activée ──────────────────────────────
            resp_intro = await self._req.send(_gql_post(url, _INTROSPECTION_QUERY))
            if not resp_intro.error and _TYPES_PATTERN.search(resp_intro.body):
                # Compter le nombre de types exposés
                type_count = len(re.findall(r'"name"\s*:', resp_intro.body))
                yield Finding(
                    title=f"GraphQL Introspection Activée — {path}",
                    severity=Severity.MEDIUM,
                    url=url,
                    module="vulns/graphql_advanced",
                    description=(
                        f"L'introspection GraphQL est activée en production sur `{path}`. "
                        f"Un attaquant peut cartographier le schéma complet (~{type_count} types/fields), "
                        f"découvrir des queries/mutations cachées et identifier des cibles d'injection."
                    ),
                    evidence=resp_intro.body[:500],
                    cwe="CWE-200",
                    remediation=(
                        "Désactiver l'introspection en production via la configuration du serveur GraphQL. "
                        "Apollo: `introspection: false`. GraphQL-Java: `IntrospectionDisabledRule`. "
                        "Utiliser persisted queries et field whitelisting en remplacement."
                    ),
                )

            # ── Test 2 : Field suggestions (information disclosure) ──────────
            resp_sugg = await self._req.send(_gql_post(
                url, '{"query":"{ userss { id } }"}'  # Faute intentionnelle
            ))
            if not resp_sugg.error and _FIELD_SUGGESTION_PATTERN.search(resp_sugg.body):
                yield Finding(
                    title=f"GraphQL Field Suggestions Activées — {path}",
                    severity=Severity.LOW,
                    url=url,
                    module="vulns/graphql_advanced",
                    description=(
                        f"Le serveur GraphQL `{path}` retourne des suggestions de noms de champs "
                        f"('Did you mean...') quand un champ n'existe pas. "
                        f"Cela permet d'énumérer les champs du schéma sans introspection."
                    ),
                    evidence=resp_sugg.body[:300],
                    cwe="CWE-200",
                    remediation=(
                        "Désactiver les suggestions de champs en production. "
                        "Apollo: `fieldSuggestions: false`. "
                        "GraphQL Helix: utiliser `disableSuggestions: true`."
                    ),
                )

            # ── Test 3 : Query Batching (DoS / rate limit bypass) ────────────
            resp_batch = await self._req.send(_gql_post(url, _BATCHING_QUERY))
            if not resp_batch.error and resp_batch.status == 200:
                count = resp_batch.body.count('"__typename"')
                if count >= 5:
                    yield Finding(
                        title=f"GraphQL Batching Activé — Rate Limit Bypassable — {path}",
                        severity=Severity.MEDIUM,
                        url=url,
                        module="vulns/graphql_advanced",
                        description=(
                            f"Le serveur `{path}` accepte les requêtes GraphQL en batch (10 queries reçues). "
                            f"Un attaquant peut envoyer des milliers de requêtes dans un seul appel HTTP, "
                            f"bypassant les rate limits et provoquant un DoS applicatif."
                        ),
                        evidence=f"10 queries en 1 requête → {count} réponses: {resp_batch.body[:300]}",
                        cwe="CWE-400",
                        remediation=(
                            "Limiter le nombre de requêtes par batch (max 5-10 recommandé). "
                            "Implémenter une analyse de complexité des queries. "
                            "Utiliser des persisted queries pour les clients de confiance."
                        ),
                    )

            # ── Test 4 : Depth limit absent ───────────────────────────────────
            resp_deep = await self._req.send(_gql_post(url, _DEEP_QUERY))
            if not resp_deep.error and resp_deep.status == 200 and '"data"' in resp_deep.body:
                yield Finding(
                    title=f"GraphQL Depth Limit Absent — {path}",
                    severity=Severity.LOW,
                    url=url,
                    module="vulns/graphql_advanced",
                    description=(
                        f"Le serveur `{path}` accepte des queries très imbriquées (8 niveaux). "
                        f"Des queries malformées très profondes peuvent causer des boucles infinies "
                        f"si des cycles existent dans le schéma."
                    ),
                    evidence=f"Query 8 niveaux → {resp_deep.status}: {resp_deep.body[:200]}",
                    cwe="CWE-400",
                    remediation=(
                        "Implémenter une limite de profondeur des queries (recommandé: max 5-7). "
                        "Utiliser graphql-depth-limit ou une validation de complexité."
                    ),
                )

            # ── Test 5 : Alias amplification ─────────────────────────────────
            resp_alias = await self._req.send(_gql_post(url, _ALIAS_AMPLIFICATION))
            if not resp_alias.error and resp_alias.status == 200:
                alias_count = resp_alias.body.count('"__typename"')
                if alias_count >= 20:
                    yield Finding(
                        title=f"GraphQL Alias Amplification — {path}",
                        severity=Severity.MEDIUM,
                        url=url,
                        module="vulns/graphql_advanced",
                        description=(
                            f"Le serveur `{path}` n'applique pas de limite sur les aliases. "
                            f"50 aliases envoyés → {alias_count} réponses. "
                            f"Utilisable pour amplifier la charge serveur et bypasser les rate limits."
                        ),
                        evidence=f"50 aliases → {alias_count} réponses: {resp_alias.body[:200]}",
                        cwe="CWE-400",
                        remediation=(
                            "Limiter le nombre d'aliases par requête. "
                            "Implémenter une analyse de coût/complexité des queries GraphQL."
                        ),
                    )

            # ── Test 6 : Injection dans les arguments ─────────────────────────
            injection_queries = [
                ('{"query":"{ user(id: \\"1 OR 1=1\\") { id email } }"}', "SQL Injection"),
                ('{"query":"{ user(id: {$gt: \\"\\"}) { id email } }"}', "NoSQL Injection"),
                ('{"query":"{ user(id: \\"{{7*7}}\\") { id } }"}', "SSTI"),
            ]
            for inj_body, inj_type in injection_queries:
                resp_inj = await self._req.send(_gql_post(url, inj_body))
                if resp_inj.error or FPFilter.is_fp(resp_inj.body, resp_inj.status):
                    continue
                from core.fp_filter import FPFilter as FP
                if (inj_type == "SQL Injection" and FP.has_real_sqli(resp_inj.body)) or \
                   (inj_type == "NoSQL Injection" and '"email"' in resp_inj.body) or \
                   (inj_type == "SSTI" and "49" in resp_inj.body):
                    yield Finding(
                        title=f"GraphQL {inj_type} — {path}",
                        severity=Severity.CRITICAL,
                        url=url,
                        module="vulns/graphql_advanced",
                        description=f"Injection de type {inj_type} détectée dans un argument GraphQL sur `{path}`.",
                        evidence=resp_inj.body[:400],
                        cwe="CWE-89" if "SQL" in inj_type else "CWE-943",
                        remediation=(
                            "Utiliser des requêtes paramétrées. "
                            "Valider et typer strictement tous les arguments GraphQL. "
                            "Éviter de passer les arguments directement aux requêtes DB."
                        ),
                    )
