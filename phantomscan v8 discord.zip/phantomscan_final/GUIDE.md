# 📖 Guide d'utilisation — PhantomScan v5.21

## C'est quoi PhantomScan ?

PhantomScan est un scanner de vulnérabilités web. Il teste automatiquement un site pour trouver des failles de sécurité que tu peux signaler sur des programmes bug bounty (HackerOne, Bugcrowd) pour être payé.

---

## ⚡ Démarrage rapide

```bash
# Va dans le dossier du scanner
cd /root/Phantomscan/final_v521_complete

# Lance un scan bug bounty sur un site
python3 cli/main.py https://target.com --preset bb --bb-report rapport.md
```

---

## 🎯 Les presets (modes de scan)

| Preset | Commande | Durée | Usage |
|--------|----------|-------|-------|
| **bb** | `--preset bb` | 20-40 min | Bug bounty — le meilleur équilibre |
| **fast** | `--preset fast` | 5-10 min | Test rapide pour voir si ça marche |
| **full** | `--preset full` | 1-2h | Scan complet, tous les modules |
| **stealth** | `--preset stealth` | 1-3h | Discret, lent, évite le ban |
| **recon** | `--preset recon` | 10-20 min | Reconnaissance seulement, pas d'attaque |
| **api** | `--preset api` | 20-40 min | Pour les APIs REST/GraphQL |

---

## 🔧 Options importantes

### Scan de base
```bash
python3 cli/main.py https://target.com --preset bb --bb-report rapport.md
```

### Avec cookies (si tu es connecté sur le site)
```bash
python3 cli/main.py https://target.com --preset bb --cookie "session=abc123; user_id=456"
```
> **Pourquoi ?** Certaines vulns ne sont visibles qu'une fois connecté. Va sur le site, ouvre les DevTools (F12), onglet Application → Cookies, copie les valeurs.

### Avec un token Bearer (APIs)
```bash
python3 cli/main.py https://api.target.com --preset api --header "Authorization: Bearer ton_token_ici"
```

### Scanner seulement certaines vulns
```bash
# Seulement SQLi et XSS
python3 cli/main.py https://target.com --only-vulns sqli,xss --bb-report rapport.md

# Seulement SSRF et LFI
python3 cli/main.py https://target.com --only-vulns ssrf,lfi --bb-report rapport.md
```

### Mode discret (pour éviter d'être banni)
```bash
python3 cli/main.py https://target.com --preset stealth --rate 0.5 --concurrent 2
```
> **rate** = nombre de requêtes par seconde (0.5 = 1 requête toutes les 2 secondes)
> **concurrent** = nombre de requêtes simultanées

### Lancer en arrière-plan (scan de nuit)
```bash
# Lance et oublie — le résultat s'enregistre dans rapport.md
nohup python3 cli/main.py https://target.com --preset bb --bb-report rapport.md > scan.log 2>&1 &

# Voir l'avancement
tail -f scan.log

# Arrêter le scan
kill %1
```

---

## 🐛 Les vulnérabilités détectées

### 🔴 CRITICAL

| Vuln | C'est quoi | Valeur bug bounty |
|------|-----------|-------------------|
| **SSRF** | Le site fait des requêtes vers des serveurs internes | $3000-$15000 |
| **SQLi** | Injection SQL dans la base de données | $2000-$10000 |
| **RCE** | Exécution de code à distance | $5000-$50000 |
| **XXE** | Injection XML externe | $1000-$5000 |
| **SSTI** | Injection dans les templates | $2000-$10000 |
| **2FA Bypass** | Contournement de l'authentification 2 facteurs | $2000-$8000 |

### 🟠 HIGH

| Vuln | C'est quoi | Valeur bug bounty |
|------|-----------|-------------------|
| **Auth Bypass** | Accès à des pages protégées | $500-$3000 |
| **IDOR** | Accès aux données d'autres utilisateurs | $500-$5000 |
| **Sensitive Data** | Secrets/mots de passe exposés | $500-$3000 |
| **JWT Bypass** | Contournement des tokens JWT | $1000-$5000 |
| **Subdomain Takeover** | Prise en main d'un sous-domaine | $500-$2000 |
| **CORS Misconfiguration** | Partage de ressources mal configuré | $500-$2000 |

### 🟡 MEDIUM

| Vuln | C'est quoi | Valeur bug bounty |
|------|-----------|-------------------|
| **XSS** | Injection de code JavaScript | $200-$1000 |
| **CSRF** | Requêtes forgées inter-sites | $200-$500 |
| **Open Redirect** | Redirection vers un site malveillant | $100-$500 |
| **Clickjacking** | Interface utilisateur détournée | $100-$300 |
| **Rate Limit** | Pas de limite sur les tentatives | $100-$500 |

---

## 📋 Comprendre les résultats

### Exemple de finding RÉEL (à soumettre)
```
[CRIT] SSRF — /proxy?url= → AWS IAM
  Endpoint: https://target.com/proxy?url=...
  Evidence: {"ami-id":"ami-0123456","instance-id":"i-0abc123"}
```
> ✅ **Soumettre** — L'évidence contient de vraies données AWS

### Exemple de faux positif (NE PAS soumettre)
```
[CRIT] SSRF — /proxy?url= → AWS IAM
  Evidence: token_retry...botdefense...heatpipe
```
> ❌ **Ne pas soumettre** — C'est du JavaScript Cloudflare, pas une vraie SSRF

---

## ✅ Avant de soumettre un rapport

**Checklist obligatoire :**

1. [ ] Vérifier manuellement dans le navigateur que la vuln existe vraiment
2. [ ] L'évidence contient des données réelles (pas du HTML générique)
3. [ ] Le domaine est dans le scope du programme bug bounty
4. [ ] Pas de doublon (quelqu'un d'autre a peut-être déjà soumis)
5. [ ] Tu as des steps to reproduce clairs

---

## 🏆 Programmes bug bounty recommandés pour débuter

### Sur HackerOne (hackerone.com)
- **GitLab** — Large scope, code source public, bon pour apprendre
- **Uber** — Scope large, bons paiements
- **Twitter/X** — Beaucoup d'endpoints
- **Shopify** — Très généreux sur les paiements

### Sur Bugcrowd (bugcrowd.com)
- **Tesla** — Scope large
- **Atlassian** — Jira, Confluence, nombreux produits

> **Conseil** : Commence par des programmes avec "No automated scanning" = False dans leurs règles. Certains l'interdisent.

---

## 🔍 Exemples de commandes pour les programmes populaires

```bash
# GitLab (scope : gitlab.com et *.gitlab.com)
python3 cli/main.py https://gitlab.com --preset bb --rate 1.0 --concurrent 3 --bb-report gitlab.md

# Uber (scope : *.uber.com)
python3 cli/main.py https://api.uber.com --preset api --rate 1.0 --concurrent 3 --bb-report uber_api.md

# Mode ultra-discret pour les grosses cibles
python3 cli/main.py https://target.com --preset stealth --rate 0.3 --concurrent 1 --bb-report rapport.md
```

---

## ❓ FAQ

**Q: Le scanner plante avec une erreur Python ?**
```bash
pip install aiohttp httpx dnspython beautifulsoup4 tldextract --break-system-packages
```

**Q: Le scan est trop lent ?**
Augmente la concurrence : `--concurrent 10 --rate 5.0`

**Q: Le scan est bloqué par le WAF ?**
Utilise le mode stealth : `--preset stealth` ou ajoute un proxy : `--proxy http://127.0.0.1:8080`

**Q: Comment scanner une API avec authentification ?**
```bash
python3 cli/main.py https://api.target.com --preset api \
  --header "Authorization: Bearer TOKEN" \
  --header "X-API-Key: CLES" \
  --bb-report api_rapport.md
```

**Q: Comment voir la liste de tous les modules ?**
```bash
python3 cli/main.py --list-modules
```

---

*PhantomScan v5.21 — Pour usage légal et éthique uniquement (bug bounty, pentest autorisé)*

---

## 🔔 Notifications Webhook (Discord, Slack, Telegram)

### Discord
```bash
# Crée un webhook dans ton serveur Discord :
# Paramètres du salon → Intégrations → Webhooks → Nouveau webhook

# Utiliser le webhook :
PHANTOMSCAN_WEBHOOK="https://discord.com/api/webhooks/TON_ID/TON_TOKEN" \
python3 cli/main.py https://target.com --preset bb --bb-report rapport.md

# Ou avec le script auto :
PHANTOMSCAN_WEBHOOK="https://discord.com/api/webhooks/..." \
./scan_auto.sh https://target.com bb
```

### Slack
```bash
# Crée un Incoming Webhook sur api.slack.com/apps
PHANTOMSCAN_WEBHOOK="https://hooks.slack.com/services/TON/WEBHOOK/ICI" \
./scan_auto.sh https://target.com bb
```

### Telegram
```bash
# 1. Crée un bot avec @BotFather → copie le TOKEN
# 2. Envoie un message au bot, récupère ton CHAT_ID via :
#    https://api.telegram.org/bot{TOKEN}/getUpdates
PHANTOMSCAN_WEBHOOK="https://api.telegram.org/bot{TOKEN}/sendMessage?chat_id={CHAT_ID}" \
./scan_auto.sh https://target.com bb
```

### Webhook générique (n'importe quelle URL)
```bash
PHANTOMSCAN_WEBHOOK="https://ton-serveur.com/webhook" \
./scan_auto.sh https://target.com bb
```

---

## 🤖 Script automatique scan_auto.sh

```bash
# Scan simple
./scan_auto.sh https://target.com bb

# Avec toutes les options
PHANTOMSCAN_WEBHOOK="https://discord.com/api/webhooks/..."  \
PHANTOMSCAN_COOKIE="session=abc123"                         \
PHANTOMSCAN_RATE="0.5"                                      \
PHANTOMSCAN_CONCURRENT="2"                                  \
PHANTOMSCAN_GIT_PUSH="1"                                    \
./scan_auto.sh https://target.com stealth
```

**Variables d'environnement disponibles :**

| Variable | Description | Exemple |
|----------|-------------|---------|
| `PHANTOMSCAN_WEBHOOK` | URL du webhook | Discord/Slack/Telegram |
| `PHANTOMSCAN_WEBHOOK_MIN_SEVERITY` | Seuil minimum | `HIGH` (défaut) |
| `PHANTOMSCAN_COOKIE` | Cookies d'auth | `session=abc123` |
| `PHANTOMSCAN_HEADER` | Header custom | `Authorization: Bearer TOKEN` |
| `PHANTOMSCAN_RATE` | Requêtes/sec | `1.0` (défaut) |
| `PHANTOMSCAN_CONCURRENT` | Connexions simultanées | `3` (défaut) |
| `PHANTOMSCAN_GIT_PUSH` | Auto-push GitHub | `1` pour activer |

---

## 📊 Score de confiance

Chaque finding a maintenant un score de confiance :

| Score | Label | Action |
|-------|-------|--------|
| 90-100% | ✅ Confirmé | Soumettre directement |
| 70-89% | 🔶 Probable | Vérifier manuellement |
| 50-69% | ⚠️ À vérifier | Tester dans le navigateur |
| 30-49% | ❓ Douteux | Probablement FP |
| 0-29% | ❌ Faux positif | Ne pas soumettre |

---

## 📁 Rapports HackerOne automatiques

Les rapports sont générés directement dans le format HackerOne, prêts à copier-coller :

```bash
./scan_auto.sh https://target.com bb
# → reports/target.com_20260510_143000.md        (rapport complet)
# → reports/target.com_20260510_143000_hackerone/ (un fichier .md par finding)
#   ├── 01_critical_ssrf.md
#   ├── 02_high_auth_bypass.md
#   └── 03_medium_xss.md
```
